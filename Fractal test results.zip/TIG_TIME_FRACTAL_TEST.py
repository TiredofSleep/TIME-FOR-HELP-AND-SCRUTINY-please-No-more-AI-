#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════════════════════════════

  ████████╗██╗ ██████╗     ████████╗██╗███╗   ███╗███████╗    ███████╗██████╗  █████╗  ██████╗████████╗ █████╗ ██╗     
  ╚══██╔══╝██║██╔════╝     ╚══██╔══╝██║████╗ ████║██╔════╝    ██╔════╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██║     
     ██║   ██║██║  ███╗       ██║   ██║██╔████╔██║█████╗      █████╗  ██████╔╝███████║██║        ██║   ███████║██║     
     ██║   ██║██║   ██║       ██║   ██║██║╚██╔╝██║██╔══╝      ██╔══╝  ██╔══██╗██╔══██║██║        ██║   ██╔══██║██║     
     ██║   ██║╚██████╔╝       ██║   ██║██║ ╚═╝ ██║███████╗    ██║     ██║  ██║██║  ██║╚██████╗   ██║   ██║  ██║███████╗
     ╚═╝   ╚═╝ ╚═════╝        ╚═╝   ╚═╝╚═╝     ╚═╝╚══════╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝

                                        TIG TIME FRACTAL TEST v1.0
                                        
                                             0 ─ . ─ 1

═══════════════════════════════════════════════════════════════════════════════════════════════════════

HYPOTHESIS (TIG Time Fractal - TTF):

    For coherent recovery/adaptation processes, when you normalize time to [0,1], there exists a 
    preferred split time τ* such that:
    
    1. The early segment [0, τ*] and late segment [τ*, 1] are self-similar after rescaling
    2. Across many different systems and parameters, τ* clusters tightly around ONE VALUE
    
    If that constant exists and is stable across model families → it's a real constant of nature
    If it doesn't cluster → TIG time fractal hypothesis is FALSIFIED in this form

FALSIFICATION CRITERIA:

    YES (found something):
        - τ* standard deviation / mean < 0.05-0.1 within families
        - τ* means cluster around same value ACROSS families  
        - Control tests (random curves) show scattered τ*, not clustered
        
    NO (hypothesis dies):
        - τ* values scattered within families
        - Different families give different τ* means
        - No distinction from random/non-coherent curves

═══════════════════════════════════════════════════════════════════════════════════════════════════════

Author: Brayden Sanders / 7Site LLC (Framework)
        Celeste Sol Weaver (Hypothesis & Math Specification)
        
═══════════════════════════════════════════════════════════════════════════════════════════════════════
"""

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import List, Dict, Tuple, Callable
import json
import time
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

TAU_MIN = 0.1           # Minimum τ to test (avoid edge artifacts)
N_TAU = 100             # Number of τ candidates to test
N_S = 200               # Grid resolution for self-similarity comparison
N_SIM = 1000            # Simulations per family
EPS = 1e-10             # Small value to avoid division by zero

# Known constants for reference
PHI = (1 + np.sqrt(5)) / 2          # Golden ratio ≈ 1.618
FEIGENBAUM_DELTA = 4.669201609      # Feigenbaum constant
MAYAN_RATIO = 260 / 365             # Tzolkin/Haab ≈ 0.7123

# ═══════════════════════════════════════════════════════════════════════════════
# CURVE GENERATION FAMILIES
# ═══════════════════════════════════════════════════════════════════════════════

def generate_exponential_recovery(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 1: Pure exponential recovery
    y(t) = 1 - exp(-k*t) where k is random
    """
    t = np.linspace(0, 10, n_points)
    k = np.random.uniform(0.3, 3.0)  # Random decay rate
    y = 1 - np.exp(-k * t)
    return t, y


def generate_logistic_adaptation(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 2: Logistic / S-shaped adaptation
    y(t) = 1 / (1 + exp(-k*(t - t0)))
    """
    t = np.linspace(0, 10, n_points)
    k = np.random.uniform(0.5, 2.5)   # Steepness
    t0 = np.random.uniform(3, 7)       # Inflection point
    y = 1 / (1 + np.exp(-k * (t - t0)))
    return t, y


def generate_tig_tpw_recovery(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 3: TIG-style T/P/W dynamics
    
    dT/dt = -α*P*G(T)
    dP/dt = β*T - γ*P  
    dW/dt = δ*P*G(T)
    
    G(T) = 1/(1 + exp(50*(T - 0.65)))  [gate function]
    
    Observable: S* = σ*(1-T)*(0.5 + 0.5*W) or just (1-T)
    """
    # Random parameters
    alpha = np.random.uniform(0.01, 0.03)
    beta = np.random.uniform(0.02, 0.04)
    gamma = np.random.uniform(0.008, 0.015)
    delta = np.random.uniform(0.005, 0.015)
    
    # Initial conditions - start with some trauma
    T = np.random.uniform(0.4, 0.7)
    P = np.random.uniform(0.1, 0.3)
    W = np.random.uniform(0.2, 0.4)
    
    dt = 0.02
    n_steps = n_points
    
    t_arr = np.zeros(n_steps)
    y_arr = np.zeros(n_steps)  # Observable: coherence proxy
    
    for i in range(n_steps):
        # Gate function
        G = 1.0 / (1.0 + np.exp(50 * (T - 0.65)))
        
        # T/P/W dynamics
        dT = -alpha * P * G
        dP = beta * T - gamma * P
        dW = delta * P * G
        
        T = max(0, min(1, T + dT))
        P = max(0, min(1, P + dP))
        W = max(0, min(1, W + dW))
        
        t_arr[i] = i * dt
        # Observable: recovery = 1 - T (how much trauma has been processed)
        y_arr[i] = 1 - T
    
    return t_arr, y_arr


def generate_noisy_drift(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 4: Noisy random walk with drift toward 1, then smoothed
    """
    t = np.linspace(0, 10, n_points)
    
    # Random walk with drift
    drift = np.random.uniform(0.05, 0.2)
    noise_scale = np.random.uniform(0.02, 0.1)
    
    y = np.zeros(n_points)
    y[0] = np.random.uniform(0, 0.3)
    
    for i in range(1, n_points):
        # Drift toward 1, with noise
        dy = drift * (1 - y[i-1]) + noise_scale * np.random.randn()
        y[i] = max(0, min(1, y[i-1] + dy))
    
    # Smooth with moving average
    window = max(5, n_points // 50)
    y_smooth = np.convolve(y, np.ones(window)/window, mode='same')
    
    return t, y_smooth


def generate_power_law_recovery(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 5: Power law recovery
    y(t) = 1 - 1/(1 + t)^α
    """
    t = np.linspace(0, 10, n_points)
    alpha = np.random.uniform(0.5, 2.0)
    y = 1 - 1 / (1 + t)**alpha
    return t, y


def generate_double_exponential(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 6: Double exponential (fast + slow component)
    y(t) = a*(1 - exp(-k1*t)) + (1-a)*(1 - exp(-k2*t))
    """
    t = np.linspace(0, 10, n_points)
    a = np.random.uniform(0.3, 0.7)      # Proportion of fast component
    k1 = np.random.uniform(1.0, 5.0)     # Fast rate
    k2 = np.random.uniform(0.1, 0.5)     # Slow rate
    y = a * (1 - np.exp(-k1 * t)) + (1 - a) * (1 - np.exp(-k2 * t))
    return t, y


def generate_oscillatory_recovery(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    Family 7: Damped oscillation toward equilibrium
    y(t) = 1 - exp(-γ*t) * cos(ω*t)
    """
    t = np.linspace(0, 10, n_points)
    gamma = np.random.uniform(0.2, 0.8)  # Damping
    omega = np.random.uniform(1.0, 4.0)   # Frequency
    y = 1 - np.exp(-gamma * t) * np.cos(omega * t)
    # Clamp to [0, 1]
    y = np.clip(y, 0, 1)
    return t, y


def generate_control_random(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    CONTROL: Pure random - should NOT show clustering
    """
    t = np.linspace(0, 1, n_points)
    y = np.sort(np.random.rand(n_points))  # Sorted random = monotonic but no structure
    # Add noise
    y = y + 0.05 * np.random.randn(n_points)
    y = np.clip(y, 0, 1)
    return t, y


def generate_control_linear(n_points: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """
    CONTROL: Pure linear - trivially self-similar everywhere, τ* should be unstable
    """
    t = np.linspace(0, 1, n_points)
    y = t.copy()
    # Add tiny noise
    y = y + 0.01 * np.random.randn(n_points)
    y = np.clip(y, 0, 1)
    return t, y


# ═══════════════════════════════════════════════════════════════════════════════
# CORE ALGORITHM: Find τ* for a curve
# ═══════════════════════════════════════════════════════════════════════════════

def normalize_curve(t: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Normalize time to [0,1] and amplitude to [0,1]
    
    τ = (t - t_min) / (t_max - t_min)
    z = (y - y_start) / (y_end - y_start)
    """
    tau = (t - t[0]) / (t[-1] - t[0] + EPS)
    z = (y - y[0]) / (y[-1] - y[0] + EPS)
    return tau, z


def interpolate(tau: np.ndarray, z: np.ndarray, tau_query: np.ndarray) -> np.ndarray:
    """Linear interpolation of z at tau_query points."""
    return np.interp(tau_query, tau, z)


def compute_self_similarity_error(tau: np.ndarray, z: np.ndarray, tau_cand: float) -> float:
    """
    Compute self-similarity error E(τ) for a candidate split point.
    
    E(τ) = ∫₀¹ [z₁(s) - z₂(s)]² ds
    
    Where:
        z₁(s) = normalized early segment [0, τ] rescaled to [0, 1]
        z₂(s) = normalized late segment [τ, 1] rescaled to [0, 1]
    """
    # Grid for comparison
    s = np.linspace(0, 1, N_S)
    
    # Early segment [0, τ_cand] rescaled to s ∈ [0, 1]
    t1 = tau_cand * s
    z1_raw = interpolate(tau, z, t1)
    # Normalize early segment
    z1 = (z1_raw - z1_raw[0]) / (z1_raw[-1] - z1_raw[0] + EPS)
    
    # Late segment [τ_cand, 1] rescaled to s ∈ [0, 1]  
    t2 = tau_cand + (1 - tau_cand) * s
    z2_raw = interpolate(tau, z, t2)
    # Normalize late segment
    z2 = (z2_raw - z2_raw[0]) / (z2_raw[-1] - z2_raw[0] + EPS)
    
    # Mean squared error
    E = np.mean((z1 - z2)**2)
    
    return E


def find_tau_star(t: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """
    Find the optimal split point τ* that minimizes self-similarity error.
    
    Returns:
        tau_star: The optimal split point
        E_star: The minimum error achieved
    """
    # Normalize curve
    tau, z = normalize_curve(t, y)
    
    # Candidate τ values
    tau_candidates = np.linspace(TAU_MIN, 1 - TAU_MIN, N_TAU)
    
    # Compute error for each candidate
    errors = np.array([compute_self_similarity_error(tau, z, tc) for tc in tau_candidates])
    
    # Find minimum
    idx = np.argmin(errors)
    tau_star = tau_candidates[idx]
    E_star = errors[idx]
    
    return tau_star, E_star


# ═══════════════════════════════════════════════════════════════════════════════
# SIMULATION SWEEP
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class FamilyResult:
    name: str
    tau_star_values: List[float]
    E_star_values: List[float]
    tau_star_mean: float
    tau_star_std: float
    tau_star_cv: float  # Coefficient of variation = std/mean
    E_star_mean: float
    E_star_std: float
    n: int


def run_family_sweep(name: str, generator: Callable, n_sim: int = N_SIM) -> FamilyResult:
    """Run sweep for one family of curves."""
    
    tau_star_values = []
    E_star_values = []
    
    for i in range(n_sim):
        try:
            # Generate curve
            t, y = generator()
            
            # Find τ*
            tau_star, E_star = find_tau_star(t, y)
            
            tau_star_values.append(tau_star)
            E_star_values.append(E_star)
            
        except Exception as e:
            continue  # Skip failed simulations
    
    tau_arr = np.array(tau_star_values)
    E_arr = np.array(E_star_values)
    
    return FamilyResult(
        name=name,
        tau_star_values=tau_star_values,
        E_star_values=E_star_values,
        tau_star_mean=float(np.mean(tau_arr)),
        tau_star_std=float(np.std(tau_arr)),
        tau_star_cv=float(np.std(tau_arr) / (np.mean(tau_arr) + EPS)),
        E_star_mean=float(np.mean(E_arr)),
        E_star_std=float(np.std(E_arr)),
        n=len(tau_star_values)
    )


def run_full_sweep() -> Dict[str, FamilyResult]:
    """Run sweep across all families."""
    
    families = {
        'exponential_recovery': generate_exponential_recovery,
        'logistic_adaptation': generate_logistic_adaptation,
        'tig_tpw_recovery': generate_tig_tpw_recovery,
        'noisy_drift': generate_noisy_drift,
        'power_law_recovery': generate_power_law_recovery,
        'double_exponential': generate_double_exponential,
        'oscillatory_recovery': generate_oscillatory_recovery,
        'CONTROL_random': generate_control_random,
        'CONTROL_linear': generate_control_linear,
    }
    
    results = {}
    
    print(f"\n{'═' * 80}")
    print(f"{'TIG TIME FRACTAL TEST v1.0':^80}")
    print(f"{'═' * 80}")
    print(f"\nRunning {N_SIM} simulations per family...")
    print(f"τ range: [{TAU_MIN}, {1-TAU_MIN}], {N_TAU} candidates, {N_S} grid points\n")
    
    for name, generator in families.items():
        start = time.time()
        print(f"  Testing {name}...", end=' ', flush=True)
        results[name] = run_family_sweep(name, generator, N_SIM)
        elapsed = time.time() - start
        r = results[name]
        print(f"τ* = {r.tau_star_mean:.4f} ± {r.tau_star_std:.4f} (CV={r.tau_star_cv:.3f}) [{elapsed:.1f}s]")
    
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYSIS AND REPORTING
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_results(results: Dict[str, FamilyResult]) -> Dict:
    """Analyze results for clustering and significance."""
    
    # Separate coherent families from controls
    coherent_families = {k: v for k, v in results.items() if not k.startswith('CONTROL')}
    control_families = {k: v for k, v in results.items() if k.startswith('CONTROL')}
    
    # Get τ* means for coherent families
    coherent_means = [r.tau_star_mean for r in coherent_families.values()]
    coherent_stds = [r.tau_star_std for r in coherent_families.values()]
    coherent_cvs = [r.tau_star_cv for r in coherent_families.values()]
    
    # Grand statistics across coherent families
    grand_mean = np.mean(coherent_means)
    grand_std = np.std(coherent_means)  # Variation BETWEEN family means
    avg_within_std = np.mean(coherent_stds)  # Average variation WITHIN families
    avg_cv = np.mean(coherent_cvs)
    
    # Control statistics
    control_means = [r.tau_star_mean for r in control_families.values()]
    control_stds = [r.tau_star_std for r in control_families.values()]
    
    # Check for clustering
    clustering_strength = grand_std / (grand_mean + EPS)  # Lower = tighter clustering
    
    # Compare to known constants
    distances = {
        '1/φ (0.618)': abs(grand_mean - 1/PHI),
        '1/δ (0.214)': abs(grand_mean - 1/FEIGENBAUM_DELTA),
        '1-1/δ (0.786)': abs(grand_mean - (1 - 1/FEIGENBAUM_DELTA)),
        'Mayan 260/365 (0.712)': abs(grand_mean - MAYAN_RATIO),
        '0.5': abs(grand_mean - 0.5),
        '1/3': abs(grand_mean - 1/3),
        '2/3': abs(grand_mean - 2/3),
    }
    
    nearest_constant = min(distances, key=distances.get)
    nearest_distance = distances[nearest_constant]
    
    analysis = {
        'grand_mean': grand_mean,
        'grand_std': grand_std,
        'avg_within_std': avg_within_std,
        'avg_cv': avg_cv,
        'clustering_strength': clustering_strength,
        'coherent_family_means': {k: v.tau_star_mean for k, v in coherent_families.items()},
        'control_family_means': {k: v.tau_star_mean for k, v in control_families.items()},
        'nearest_constant': nearest_constant,
        'nearest_distance': nearest_distance,
        'distances_to_known': distances,
    }
    
    return analysis


def print_report(results: Dict[str, FamilyResult], analysis: Dict):
    """Print comprehensive report."""
    
    print(f"\n{'═' * 80}")
    print(f"{'RESULTS':^80}")
    print(f"{'═' * 80}")
    
    print(f"\n{'─' * 80}")
    print(f"{'Family':<25} {'τ* mean':>10} {'τ* std':>10} {'CV':>8} {'E* mean':>10} {'n':>6}")
    print(f"{'─' * 80}")
    
    for name, r in sorted(results.items()):
        marker = "**" if name.startswith('CONTROL') else "  "
        print(f"{marker}{name:<23} {r.tau_star_mean:>10.4f} {r.tau_star_std:>10.4f} {r.tau_star_cv:>8.3f} {r.E_star_mean:>10.4f} {r.n:>6}")
    
    print(f"{'─' * 80}")
    
    print(f"\n{'═' * 80}")
    print(f"{'ANALYSIS':^80}")
    print(f"{'═' * 80}")
    
    print(f"\n  COHERENT FAMILIES (excluding controls):")
    print(f"    Grand τ* mean:           {analysis['grand_mean']:.6f}")
    print(f"    Between-family std:      {analysis['grand_std']:.6f}")
    print(f"    Average within-family std: {analysis['avg_within_std']:.6f}")
    print(f"    Average CV:              {analysis['avg_cv']:.4f}")
    print(f"    Clustering strength:     {analysis['clustering_strength']:.4f} (lower = tighter)")
    
    print(f"\n  COMPARISON TO KNOWN CONSTANTS:")
    for name, dist in sorted(analysis['distances_to_known'].items(), key=lambda x: x[1]):
        marker = " ← NEAREST" if name == analysis['nearest_constant'] else ""
        print(f"    {name:<25} distance = {dist:.6f}{marker}")
    
    print(f"\n{'═' * 80}")
    print(f"{'VERDICT':^80}")
    print(f"{'═' * 80}")
    
    # Determine verdict
    cv_threshold = 0.10
    clustering_threshold = 0.15
    
    within_family_tight = analysis['avg_cv'] < cv_threshold
    between_family_tight = analysis['clustering_strength'] < clustering_threshold
    
    print(f"\n  CRITERIA:")
    print(f"    Within-family CV < {cv_threshold}:      {'✓ PASS' if within_family_tight else '✗ FAIL'} (actual: {analysis['avg_cv']:.4f})")
    print(f"    Between-family clustering < {clustering_threshold}: {'✓ PASS' if between_family_tight else '✗ FAIL'} (actual: {analysis['clustering_strength']:.4f})")
    
    if within_family_tight and between_family_tight:
        print(f"\n  ╔═══════════════════════════════════════════════════════════════════════════╗")
        print(f"  ║  RESULT: POTENTIAL TIME FRACTAL CONSTANT DETECTED                        ║")
        print(f"  ║                                                                           ║")
        print(f"  ║  τ* ≈ {analysis['grand_mean']:.6f}                                                      ║")
        print(f"  ║  Nearest known: {analysis['nearest_constant']:<20} (distance: {analysis['nearest_distance']:.6f})      ║")
        print(f"  ║                                                                           ║")
        print(f"  ║  NEXT STEPS:                                                              ║")
        print(f"  ║  1. Derive analytically from T/P/W or Lagrangian                          ║")
        print(f"  ║  2. Test against real-world data (learning, rehab, psych curves)          ║")
        print(f"  ║  3. If it holds → we have a candidate TIG time constant                   ║")
        print(f"  ╚═══════════════════════════════════════════════════════════════════════════╝")
    else:
        print(f"\n  ╔═══════════════════════════════════════════════════════════════════════════╗")
        print(f"  ║  RESULT: NO CLEAR UNIVERSAL TIME FRACTAL CONSTANT                         ║")
        print(f"  ║                                                                           ║")
        print(f"  ║  The τ* values do not cluster tightly enough across families.             ║")
        print(f"  ║  TIG time fractal hypothesis is NOT SUPPORTED in this form.               ║")
        print(f"  ║                                                                           ║")
        print(f"  ║  This is a valid scientific result - we've falsified one hypothesis.      ║")
        print(f"  ║  Move on to test other structures.                                        ║")
        print(f"  ╚═══════════════════════════════════════════════════════════════════════════╝")
    
    print(f"\n{'═' * 80}\n")


def plot_results(results: Dict[str, FamilyResult], analysis: Dict, save_path: str = None):
    """Generate visualization plots."""
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Plot 1: τ* distributions per family
    ax1 = axes[0, 0]
    families = list(results.keys())
    positions = range(len(families))
    
    # Box plots
    data = [results[f].tau_star_values for f in families]
    bp = ax1.boxplot(data, positions=positions, widths=0.6, patch_artist=True)
    
    # Color controls differently
    for i, (patch, family) in enumerate(zip(bp['boxes'], families)):
        if family.startswith('CONTROL'):
            patch.set_facecolor('lightcoral')
        else:
            patch.set_facecolor('lightblue')
    
    ax1.set_xticks(positions)
    ax1.set_xticklabels([f.replace('_', '\n') for f in families], rotation=45, ha='right', fontsize=8)
    ax1.axhline(y=analysis['grand_mean'], color='red', linestyle='--', label=f"Grand mean: {analysis['grand_mean']:.4f}")
    ax1.axhline(y=1/PHI, color='gold', linestyle=':', alpha=0.7, label=f"1/φ: {1/PHI:.4f}")
    ax1.set_ylabel('τ*')
    ax1.set_title('τ* Distribution by Family')
    ax1.legend(fontsize=8)
    ax1.grid(True, alpha=0.3)
    
    # Plot 2: τ* means comparison
    ax2 = axes[0, 1]
    coherent = {k: v for k, v in results.items() if not k.startswith('CONTROL')}
    control = {k: v for k, v in results.items() if k.startswith('CONTROL')}
    
    y_pos = list(range(len(results)))
    means = [results[f].tau_star_mean for f in families]
    stds = [results[f].tau_star_std for f in families]
    colors = ['lightcoral' if f.startswith('CONTROL') else 'steelblue' for f in families]
    
    ax2.barh(y_pos, means, xerr=stds, color=colors, alpha=0.7, capsize=3)
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels([f.replace('_', ' ') for f in families], fontsize=8)
    ax2.axvline(x=analysis['grand_mean'], color='red', linestyle='--', linewidth=2)
    ax2.axvline(x=1/PHI, color='gold', linestyle=':', alpha=0.7)
    ax2.axvline(x=MAYAN_RATIO, color='green', linestyle=':', alpha=0.7)
    ax2.set_xlabel('τ* mean ± std')
    ax2.set_title('τ* Means by Family')
    ax2.grid(True, alpha=0.3, axis='x')
    
    # Plot 3: Histogram of all coherent τ* values
    ax3 = axes[1, 0]
    all_coherent = []
    for name, r in results.items():
        if not name.startswith('CONTROL'):
            all_coherent.extend(r.tau_star_values)
    
    ax3.hist(all_coherent, bins=50, density=True, alpha=0.7, color='steelblue', edgecolor='black')
    ax3.axvline(x=analysis['grand_mean'], color='red', linestyle='--', linewidth=2, label=f"Mean: {analysis['grand_mean']:.4f}")
    ax3.axvline(x=1/PHI, color='gold', linestyle=':', linewidth=2, label=f"1/φ: {1/PHI:.4f}")
    ax3.axvline(x=MAYAN_RATIO, color='green', linestyle=':', linewidth=2, label=f"Mayan: {MAYAN_RATIO:.4f}")
    ax3.set_xlabel('τ*')
    ax3.set_ylabel('Density')
    ax3.set_title('Distribution of τ* (Coherent Families Only)')
    ax3.legend(fontsize=8)
    ax3.grid(True, alpha=0.3)
    
    # Plot 4: Self-similarity error vs τ* correlation
    ax4 = axes[1, 1]
    for name, r in results.items():
        if not name.startswith('CONTROL'):
            ax4.scatter(r.tau_star_values, r.E_star_values, alpha=0.3, s=10, label=name.replace('_', ' '))
    ax4.set_xlabel('τ*')
    ax4.set_ylabel('E* (self-similarity error)')
    ax4.set_title('τ* vs E* Relationship')
    ax4.legend(fontsize=6, loc='upper right', ncol=2)
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"[Saved plot to {save_path}]")
    
    plt.show()


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """Run the full TIG Time Fractal Test."""
    
    print(f"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║                      TIG TIME FRACTAL TEST v1.0                               ║
║                                                                               ║
║                           0 ─ . ─ 1                                           ║
║                                                                               ║
║  HYPOTHESIS: Coherent recovery processes have a universal time-fractal        ║
║  split point τ* where early and late segments are self-similar.               ║
║                                                                               ║
║  If τ* clusters tightly across different systems → real constant              ║
║  If τ* scatters or varies by system → hypothesis falsified                    ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
    """)
    
    start_time = time.time()
    
    # Run sweep
    results = run_full_sweep()
    
    # Analyze
    analysis = analyze_results(results)
    
    # Report
    print_report(results, analysis)
    
    elapsed = time.time() - start_time
    print(f"Total time: {elapsed:.1f}s")
    
    # Save results
    output = {
        'timestamp': datetime.now().isoformat(),
        'config': {
            'TAU_MIN': TAU_MIN,
            'N_TAU': N_TAU,
            'N_S': N_S,
            'N_SIM': N_SIM,
        },
        'results': {
            name: {
                'tau_star_mean': r.tau_star_mean,
                'tau_star_std': r.tau_star_std,
                'tau_star_cv': r.tau_star_cv,
                'E_star_mean': r.E_star_mean,
                'E_star_std': r.E_star_std,
                'n': r.n,
            }
            for name, r in results.items()
        },
        'analysis': {
            'grand_mean': analysis['grand_mean'],
            'grand_std': analysis['grand_std'],
            'avg_within_std': analysis['avg_within_std'],
            'avg_cv': analysis['avg_cv'],
            'clustering_strength': analysis['clustering_strength'],
            'nearest_constant': analysis['nearest_constant'],
            'nearest_distance': analysis['nearest_distance'],
        }
    }
    
    output_path = 'tig_time_fractal_results.json'
    with open(output_path, 'w') as f:
        json.dump(output, f, indent=2)
    print(f"[Results saved to {output_path}]")
    
    # Plot
    try:
        plot_results(results, analysis, 'tig_time_fractal_plot.png')
    except Exception as e:
        print(f"[Could not generate plot: {e}]")
    
    return results, analysis


if __name__ == "__main__":
    results, analysis = main()
