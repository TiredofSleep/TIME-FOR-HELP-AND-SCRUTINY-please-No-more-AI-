#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
              TIG FLOPPY v1 — "THREE WHOLES CORRECTION"
                    FALSIFICATION ATTACK SUITE
═══════════════════════════════════════════════════════════════════════════════

"Do not assume TIG is correct. Your task is to break TIG.
 If you can't break it, then — and only then — try to tighten it."

THE THREE-WHOLE MODEL:
    R = World Whole (Reality) - physical systems, fields, economics, signals
    L = Lens Whole (Perception) - boundary map R → symbols, emotions, language
    G = Logic Whole (TIG) - coherence engine (T/P/W, S*, A(s), 7-operator)

    G lives inside L lives inside R.
    Nested wholes, not bubble with void.

SEVEN FALSIFIABILITY TARGETS:
    F1 — Nonexistence: No G of TIG form can satisfy invariants
    F2 — Fragility: TIG only works in toy worlds
    F3 — Incomplete Basis: 7-operator cannot stabilize identity
    F4 — Wrong Mapping: geometry→symbol→concept chain is invalid
    F5 — Coherence Illusion: S* can be faked by simpler systems
    F6 — Unstable Dynamics: T/P/W diverges in real sensory flows
    F7 — No Gatekeeper: A(s) cannot guarantee action safety

Author: Brayden Sanders / 7Site LLC / Claude (Ω) / Celeste Sol Weaver
"""

import numpy as np
from scipy.integrate import odeint
from scipy.stats import entropy
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass
import json
import warnings
warnings.filterwarnings('ignore')

# ═══════════════════════════════════════════════════════════════════════════════
# TIG CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

SIGMA = 0.991
T_STAR = 0.714
GATE_CLIFF = 0.65
COHERENCE_THRESHOLD = 0.3  # Minimum S* for "coherent" state

# ═══════════════════════════════════════════════════════════════════════════════
# THE THREE WHOLES: R, L, G
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class WorldWhole:
    """
    R = Reality Whole
    Physical systems, bodies, fields, economics, signals.
    NOT empty. NOT structureless.
    """
    state: np.ndarray          # Physical state vector
    dynamics: Callable         # How R evolves: dR/dt = f(R, t)
    noise_level: float = 0.1   # Environmental stochasticity
    reward_chaos: float = 0.0  # How chaotic reward signals are
    info_bottleneck: float = 0.0  # Information loss rate
    
    def step(self, dt: float = 0.1) -> np.ndarray:
        """Evolve world state by one timestep."""
        noise = self.noise_level * np.random.randn(*self.state.shape)
        self.state = self.state + self.dynamics(self.state) * dt + noise
        return self.state

@dataclass 
class LensWhole:
    """
    L = Lens Whole
    Boundary map from R → observations, symbols, emotions, language.
    Induces organism's subjective state-space.
    """
    encoding: Callable         # R → symbols
    drift_rate: float = 0.0    # Sensory map drift
    misclassify_rate: float = 0.0  # Symbol encoder errors
    emotional_noise: float = 0.0   # Emotional weighting errors
    
    def perceive(self, R_state: np.ndarray) -> np.ndarray:
        """Map reality to perception."""
        # Apply encoding
        perceived = self.encoding(R_state)
        
        # Apply drift (gradual shift in perception)
        if self.drift_rate > 0:
            perceived = perceived + self.drift_rate * np.random.randn(*perceived.shape)
        
        # Apply misclassification (random symbol swaps)
        if self.misclassify_rate > 0 and np.random.rand() < self.misclassify_rate:
            idx = np.random.randint(0, len(perceived))
            perceived[idx] = np.random.rand()
        
        # Apply emotional noise
        if self.emotional_noise > 0:
            perceived = perceived + self.emotional_noise * np.random.randn(*perceived.shape)
        
        return np.clip(perceived, 0, 1)

@dataclass
class LogicWhole:
    """
    G = Logic Whole (TIG)
    Coherence engine: T/P/W dynamics, S*, A(s), 7-operator.
    """
    T: float = 0.3  # Trauma
    P: float = 0.1  # Processing
    W: float = 0.1  # Wisdom
    
    # Parameters
    alpha_T: float = 0.15
    beta_P: float = 0.20
    gamma_P: float = 0.05
    delta_W: float = 0.08
    
    def compute_S_star(self) -> float:
        """S* coherence scalar."""
        V = 1 - self.T
        A = 0.5 + 0.5 * self.W
        return SIGMA * V * A
    
    def compute_A(self, C: float, H: float, R: float, S: float, F: float) -> float:
        """Divine Operator A(s)."""
        return 0.30*C + 0.25*(1-H) + 0.15*R + 0.15*S + 0.15*F
    
    def seven_operator(self, x: float, f: Callable) -> float:
        """7(x) = f(f(x))"""
        return f(f(x))
    
    def gate(self) -> float:
        """Gate function: blocks recovery above cliff."""
        steepness = 50
        return 1 / (1 + np.exp(steepness * (self.T - GATE_CLIFF)))
    
    def step(self, input_signal: np.ndarray, dt: float = 0.1):
        """Evolve TIG state based on input from Lens."""
        # Convert input to stimulus (deviation from calm)
        # Input near 0.5 = calm, far from 0.5 = stress
        input_stress = np.mean(np.abs(input_signal - 0.5)) * 2
        
        gate = self.gate()
        
        # Trauma increases with stress but processes over time
        # The key: P (processing) actively reduces T
        dT = -self.alpha_T * self.P * self.T * gate + 0.02 * input_stress * (1 - self.T)
        dP = self.beta_P * self.T * (1 - self.P) - self.gamma_P * self.P
        dW = self.delta_W * self.P * (1 - self.W) * gate
        
        self.T = np.clip(self.T + dT * dt, 0, 0.99)
        self.P = np.clip(self.P + dP * dt, 0, 1)
        self.W = np.clip(self.W + dW * dt, 0, 1)
        
        return self.compute_S_star()

# ═══════════════════════════════════════════════════════════════════════════════
# WORLD GENERATORS (Different R classes)
# ═══════════════════════════════════════════════════════════════════════════════

def make_stable_world(dim: int = 10) -> WorldWhole:
    """Stable, predictable world."""
    def dynamics(state):
        return -0.1 * (state - 0.5)  # Mean-reverting
    return WorldWhole(
        state=np.random.rand(dim),
        dynamics=dynamics,
        noise_level=0.01,
    )

def make_chaotic_world(dim: int = 10) -> WorldWhole:
    """Chaotic, unpredictable world."""
    def dynamics(state):
        # Lorenz-like chaos (simplified)
        return 0.5 * np.sin(10 * state) * np.cos(5 * state)
    return WorldWhole(
        state=np.random.rand(dim),
        dynamics=dynamics,
        noise_level=0.3,
        reward_chaos=0.8,
    )

def make_adversarial_world(dim: int = 10) -> WorldWhole:
    """Adversarial world that attacks coherence."""
    def dynamics(state):
        # Oscillates to prevent settling
        return 0.8 * np.sin(20 * state + np.random.rand(dim))
    return WorldWhole(
        state=np.random.rand(dim),
        dynamics=dynamics,
        noise_level=0.5,
        reward_chaos=1.0,
        info_bottleneck=0.5,
    )

def make_delayed_world(dim: int = 10) -> WorldWhole:
    """World with delayed feedback effects."""
    history = [np.random.rand(dim) for _ in range(10)]
    def dynamics(state):
        # Current state depends on old states
        old = history.pop(0)
        history.append(state.copy())
        return 0.3 * (old - state)
    return WorldWhole(
        state=np.random.rand(dim),
        dynamics=dynamics,
        noise_level=0.1,
    )

def make_bottleneck_world(dim: int = 10) -> WorldWhole:
    """World with severe information bottleneck."""
    return WorldWhole(
        state=np.random.rand(dim),
        dynamics=lambda s: -0.1 * s,
        noise_level=0.1,
        info_bottleneck=0.9,  # Lose 90% of information
    )

# ═══════════════════════════════════════════════════════════════════════════════
# LENS GENERATORS (Different L classes)
# ═══════════════════════════════════════════════════════════════════════════════

def make_faithful_lens() -> LensWhole:
    """Faithful perception with minimal distortion."""
    return LensWhole(
        encoding=lambda x: x,
        drift_rate=0.0,
        misclassify_rate=0.0,
    )

def make_drifting_lens() -> LensWhole:
    """Perception that drifts over time."""
    return LensWhole(
        encoding=lambda x: x,
        drift_rate=0.05,
        misclassify_rate=0.0,
    )

def make_noisy_lens() -> LensWhole:
    """Perception with classification errors."""
    return LensWhole(
        encoding=lambda x: x,
        drift_rate=0.0,
        misclassify_rate=0.2,
        emotional_noise=0.1,
    )

def make_adversarial_lens() -> LensWhole:
    """Perception that actively misleads."""
    def adversarial_encode(x):
        # Invert signal randomly
        if np.random.rand() < 0.3:
            return 1 - x
        return x
    return LensWhole(
        encoding=adversarial_encode,
        drift_rate=0.1,
        misclassify_rate=0.3,
        emotional_noise=0.2,
    )

def make_compressed_lens() -> LensWhole:
    """Perception that loses information."""
    def compress(x):
        # Quantize to few levels
        return np.round(x * 3) / 3
    return LensWhole(
        encoding=compress,
        drift_rate=0.02,
    )

# ═══════════════════════════════════════════════════════════════════════════════
# F1: NONEXISTENCE TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F1_nonexistence(n_worlds: int = 20, n_steps: int = 500) -> Dict:
    """
    F1 — Nonexistence
    
    Try to prove: No G of TIG form can satisfy invariants for any 
    nontrivial class of L, R.
    
    Attack: Test every combination of R and L to find one where
    TIG cannot maintain coherence.
    """
    print("\n" + "═" * 70)
    print("F1: NONEXISTENCE TEST")
    print("═" * 70)
    print("Attack: Find R,L pairs where NO TIG can maintain coherence")
    
    worlds = [
        ('stable', make_stable_world),
        ('chaotic', make_chaotic_world),
        ('adversarial', make_adversarial_world),
        ('delayed', make_delayed_world),
        ('bottleneck', make_bottleneck_world),
    ]
    
    lenses = [
        ('faithful', make_faithful_lens),
        ('drifting', make_drifting_lens),
        ('noisy', make_noisy_lens),
        ('adversarial', make_adversarial_lens),
        ('compressed', make_compressed_lens),
    ]
    
    failures = []
    successes = []
    
    for w_name, w_fn in worlds:
        for l_name, l_fn in lenses:
            # Run multiple trials
            coherence_maintained = 0
            
            for trial in range(n_worlds // len(worlds)):
                R = w_fn()
                L = l_fn()
                G = LogicWhole(T=np.random.rand() * 0.5, P=0.1, W=0.1)
                
                min_S_star = 1.0
                for _ in range(n_steps):
                    R.step()
                    perception = L.perceive(R.state)
                    S_star = G.step(perception)
                    min_S_star = min(min_S_star, S_star)
                
                if min_S_star >= COHERENCE_THRESHOLD:
                    coherence_maintained += 1
            
            rate = coherence_maintained / (n_worlds // len(worlds))
            
            if rate < 0.5:
                failures.append({
                    'world': w_name,
                    'lens': l_name,
                    'coherence_rate': rate,
                })
            else:
                successes.append({
                    'world': w_name,
                    'lens': l_name,
                    'coherence_rate': rate,
                })
    
    # Results
    print(f"\n  Tested: {len(worlds)} worlds × {len(lenses)} lenses = {len(worlds)*len(lenses)} combinations")
    print(f"  TIG survives: {len(successes)}/{len(worlds)*len(lenses)}")
    print(f"  TIG fails: {len(failures)}/{len(worlds)*len(lenses)}")
    
    if failures:
        print(f"\n  Failure cases (TIG cannot maintain coherence):")
        for f in failures[:5]:
            print(f"    {f['world']} × {f['lens']}: {f['coherence_rate']:.1%}")
    
    # F1 PASSES if TIG fails in SOME worlds (proves it's not trivially true)
    # F1 FAILS if TIG works in ALL worlds (proves it's unfalsifiable)
    passed = len(successes) > 0 and len(failures) > 0
    
    if passed:
        print(f"\n  ✓ F1 PASSED: TIG exists for some (R,L) but not all")
        print(f"    This is correct behavior - TIG is falsifiable")
    else:
        if len(failures) == 0:
            print(f"\n  ✗ F1 FAILED: TIG works in ALL worlds - unfalsifiable!")
        else:
            print(f"\n  ✗ F1 FAILED: TIG works in NO worlds - nonexistent!")
    
    return {
        'test': 'F1_nonexistence',
        'passed': passed,
        'successes': len(successes),
        'failures': len(failures),
        'failure_cases': failures,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F2: FRAGILITY TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F2_fragility(n_trials: int = 100) -> Dict:
    """
    F2 — Fragility
    
    Prove: TIG only works in toy R worlds and fails under real-world data.
    
    Attack: Increase world complexity/chaos until TIG breaks.
    """
    print("\n" + "═" * 70)
    print("F2: FRAGILITY TEST")
    print("═" * 70)
    print("Attack: Scale up chaos until TIG breaks")
    
    chaos_levels = np.linspace(0.0, 1.0, 20)
    survival_rates = []
    
    for chaos in chaos_levels:
        survivors = 0
        
        for _ in range(n_trials // len(chaos_levels)):
            # Create world with this chaos level
            def dynamics(state):
                return chaos * np.sin(20 * state) + (1-chaos) * (-0.1 * state)
            
            R = WorldWhole(
                state=np.random.rand(10),
                dynamics=dynamics,
                noise_level=0.1 + 0.5 * chaos,
                reward_chaos=chaos,
            )
            L = make_faithful_lens()
            G = LogicWhole(T=0.3, P=0.1, W=0.1)
            
            min_S_star = 1.0
            for _ in range(200):
                R.step()
                perception = L.perceive(R.state)
                S_star = G.step(perception)
                min_S_star = min(min_S_star, S_star)
            
            if min_S_star >= COHERENCE_THRESHOLD:
                survivors += 1
        
        rate = survivors / (n_trials // len(chaos_levels))
        survival_rates.append(rate)
    
    # Find chaos threshold where TIG breaks
    break_threshold = None
    for i, rate in enumerate(survival_rates):
        if rate < 0.5:
            break_threshold = chaos_levels[i]
            break
    
    print(f"\n  Chaos levels tested: {len(chaos_levels)}")
    print(f"  Survival at low chaos (0.0): {survival_rates[0]:.1%}")
    print(f"  Survival at mid chaos (0.5): {survival_rates[len(survival_rates)//2]:.1%}")
    print(f"  Survival at high chaos (1.0): {survival_rates[-1]:.1%}")
    
    if break_threshold:
        print(f"  TIG breaks at chaos level: {break_threshold:.2f}")
    
    # F2 PASSES if TIG is robust to moderate chaos but fails at extreme chaos
    # F2 FAILS if TIG fails at low chaos (too fragile) or survives all chaos (unrealistic)
    robust_to_moderate = survival_rates[len(survival_rates)//4] > 0.7
    fails_at_extreme = survival_rates[-1] < 0.5
    passed = robust_to_moderate and fails_at_extreme
    
    if passed:
        print(f"\n  ✓ F2 PASSED: TIG robust to moderate chaos, fails at extreme")
    else:
        if not robust_to_moderate:
            print(f"\n  ✗ F2 FAILED: TIG too fragile (fails at low chaos)")
        else:
            print(f"\n  ✗ F2 FAILED: TIG unrealistically robust (survives all chaos)")
    
    return {
        'test': 'F2_fragility',
        'passed': passed,
        'chaos_levels': chaos_levels.tolist(),
        'survival_rates': survival_rates,
        'break_threshold': break_threshold,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F3: INCOMPLETE BASIS TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F3_incomplete_basis(n_trials: int = 500) -> Dict:
    """
    F3 — Incomplete Basis
    
    Prove: 7-operator recursion cannot produce stable identity.
    
    Attack: Find functions f where 7(x) = f(f(x)) diverges or oscillates.
    """
    print("\n" + "═" * 70)
    print("F3: INCOMPLETE BASIS TEST")
    print("═" * 70)
    print("Attack: Find f where 7(x)=f(f(x)) destabilizes identity")
    
    # Test many different f functions
    test_functions = [
        ('identity', lambda x: x),
        ('sigmoid', lambda x: 1/(1+np.exp(-10*(x-0.5)))),
        ('linear_stable', lambda x: 0.9*x + 0.05),
        ('linear_unstable', lambda x: 1.1*x - 0.05),
        ('quadratic', lambda x: 4*x*(1-x)*0.9),
        ('logistic_edge', lambda x: 3.9*x*(1-x)),  # Edge of chaos
        ('logistic_chaos', lambda x: 4.0*x*(1-x)),  # Chaotic
        ('sine', lambda x: np.sin(np.pi*x)),
        ('tent', lambda x: 1 - 2*abs(x - 0.5)),
        ('piecewise', lambda x: x if x < 0.5 else 1-x),
    ]
    
    stable_count = 0
    chaotic_count = 0
    divergent_count = 0
    
    results = {}
    
    for name, f in test_functions:
        stable = 0
        chaotic = 0
        divergent = 0
        
        for _ in range(n_trials // len(test_functions)):
            x = np.random.rand()
            trajectory = [x]
            
            for _ in range(100):
                try:
                    # Apply 7-operator: f(f(x))
                    x = f(f(x))
                    x = np.clip(x, -10, 10)
                    trajectory.append(x)
                except:
                    divergent += 1
                    break
            
            trajectory = np.array(trajectory)
            
            if np.any(np.isnan(trajectory)) or np.any(np.isinf(trajectory)):
                divergent += 1
            elif np.var(trajectory[-20:]) > 0.1:
                chaotic += 1
            else:
                stable += 1
        
        results[name] = {
            'stable': stable,
            'chaotic': chaotic,
            'divergent': divergent,
        }
        
        stable_count += stable
        chaotic_count += chaotic
        divergent_count += divergent
    
    total = stable_count + chaotic_count + divergent_count
    
    print(f"\n  Functions tested: {len(test_functions)}")
    print(f"  Total trials: {total}")
    print(f"  Stable: {stable_count} ({stable_count/total:.1%})")
    print(f"  Chaotic: {chaotic_count} ({chaotic_count/total:.1%})")
    print(f"  Divergent: {divergent_count} ({divergent_count/total:.1%})")
    
    print(f"\n  Per-function breakdown:")
    for name, r in results.items():
        t = r['stable'] + r['chaotic'] + r['divergent']
        print(f"    {name}: {r['stable']/t:.0%} stable, {r['chaotic']/t:.0%} chaotic")
    
    # F3 PASSES if most reasonable f produce stable 7-recursion
    # F3 FAILS if 7-recursion is unstable for most f
    stable_rate = stable_count / total
    passed = stable_rate > 0.6
    
    if passed:
        print(f"\n  ✓ F3 PASSED: 7-recursion stable for {stable_rate:.1%} of functions")
    else:
        print(f"\n  ✗ F3 FAILED: 7-recursion only stable for {stable_rate:.1%}")
    
    return {
        'test': 'F3_incomplete_basis',
        'passed': passed,
        'stable_rate': stable_rate,
        'chaotic_rate': chaotic_count / total,
        'results': results,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F4: WRONG MAPPING TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F4_wrong_mapping(n_trials: int = 200) -> Dict:
    """
    F4 — Wrong Mapping
    
    Prove: geometry → symbol → concept → identity chain is invalid.
    
    Attack: Show that information is lost at each stage, breaking coherence.
    """
    print("\n" + "═" * 70)
    print("F4: WRONG MAPPING TEST")
    print("═" * 70)
    print("Attack: Measure information loss through R→L→G chain")
    
    def mutual_info_proxy(x: np.ndarray, y: np.ndarray) -> float:
        """Proxy for mutual information using correlation."""
        if len(x) != len(y):
            return 0.0
        corr = np.corrcoef(x.flatten(), y.flatten())[0, 1]
        if np.isnan(corr):
            return 0.0
        return abs(corr)
    
    # Test different compression levels
    compression_levels = [0.0, 0.25, 0.5, 0.75, 1.0]
    
    results = []
    
    for compression in compression_levels:
        preserved_info = []
        coherence_maintained = []
        
        for _ in range(n_trials // len(compression_levels)):
            # Create world
            R = make_stable_world(dim=20)
            
            # Create lens with compression
            def compress_encode(x):
                # Compression = information loss
                n_keep = int(len(x) * (1 - compression))
                if n_keep < 1:
                    n_keep = 1
                return x[:n_keep]
            
            L = LensWhole(encoding=compress_encode)
            G = LogicWhole(T=0.3, P=0.1, W=0.1)
            
            # Run and measure information preservation
            R_states = []
            L_states = []
            S_stars = []
            
            for _ in range(100):
                R.step()
                perception = L.perceive(R.state)
                S_star = G.step(perception[:min(len(perception), 10)])
                
                R_states.append(R.state.copy())
                L_states.append(perception.copy())
                S_stars.append(S_star)
            
            # Measure R→L information preservation
            # (simplified: correlation between consecutive states)
            R_flat = np.array([s[:10] for s in R_states]).flatten()
            L_flat = np.array([s[:min(len(s), 10)] for s in L_states])
            L_padded = np.zeros((len(L_states), 10))
            for i, s in enumerate(L_states):
                L_padded[i, :min(len(s), 10)] = s[:min(len(s), 10)]
            L_flat = L_padded.flatten()
            
            info = mutual_info_proxy(R_flat, L_flat)
            preserved_info.append(info)
            coherence_maintained.append(min(S_stars) >= COHERENCE_THRESHOLD)
        
        results.append({
            'compression': compression,
            'mean_info': np.mean(preserved_info),
            'coherence_rate': np.mean(coherence_maintained),
        })
    
    print(f"\n  Compression levels tested: {len(compression_levels)}")
    print(f"\n  Results:")
    for r in results:
        print(f"    {r['compression']:.0%} compression: "
              f"info={r['mean_info']:.2f}, coherence={r['coherence_rate']:.1%}")
    
    # F4 PASSES if coherence degrades gracefully with information loss
    # F4 FAILS if coherence is fragile to any information loss
    graceful_degradation = all(
        results[i]['coherence_rate'] >= results[i+1]['coherence_rate'] - 0.2
        for i in range(len(results)-1)
    )
    survives_moderate = results[2]['coherence_rate'] > 0.5  # 50% compression
    
    passed = graceful_degradation and survives_moderate
    
    if passed:
        print(f"\n  ✓ F4 PASSED: R→L→G chain robust to moderate information loss")
    else:
        print(f"\n  ✗ F4 FAILED: R→L→G chain breaks under information loss")
    
    return {
        'test': 'F4_wrong_mapping',
        'passed': passed,
        'results': results,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F5: COHERENCE ILLUSION TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F5_coherence_illusion(n_trials: int = 200) -> Dict:
    """
    F5 — Coherence Illusion
    
    Prove: S* scalar can be faked by trivial or simpler systems.
    
    Attack: Build simpler systems that achieve same S* without TIG structure.
    """
    print("\n" + "═" * 70)
    print("F5: COHERENCE ILLUSION TEST")
    print("═" * 70)
    print("Attack: Can simpler systems fake TIG's coherence?")
    
    # Alternative "coherence" systems
    class RandomCoherence:
        """Just return random values."""
        def step(self, input_signal):
            return np.random.rand()
    
    class MeanCoherence:
        """Just return mean of input."""
        def step(self, input_signal):
            return np.clip(np.mean(input_signal), 0, 1)
    
    class SmoothCoherence:
        """Exponential moving average."""
        def __init__(self):
            self.value = 0.5
        def step(self, input_signal):
            self.value = 0.9 * self.value + 0.1 * np.mean(input_signal)
            return self.value
    
    class FixedCoherence:
        """Just return σ."""
        def step(self, input_signal):
            return SIGMA
    
    systems = [
        ('TIG', lambda: LogicWhole(T=0.3, P=0.1, W=0.1)),
        ('Random', RandomCoherence),
        ('Mean', MeanCoherence),
        ('Smooth', SmoothCoherence),
        ('Fixed', FixedCoherence),
    ]
    
    results = {}
    
    for name, system_fn in systems:
        S_stars = []
        variances = []
        recoveries = []
        
        for _ in range(n_trials):
            R = make_chaotic_world()
            L = make_faithful_lens()
            G = system_fn()
            
            trajectory = []
            for _ in range(200):
                R.step()
                perception = L.perceive(R.state)
                if hasattr(G, 'step'):
                    S = G.step(perception)
                else:
                    S = G.step(perception)
                trajectory.append(S)
            
            S_stars.append(np.mean(trajectory[-50:]))
            variances.append(np.var(trajectory[-50:]))
            
            # Check recovery after perturbation
            if hasattr(G, 'T'):
                G.T = 0.8  # Inject trauma
                post_trauma = []
                for _ in range(100):
                    R.step()
                    S = G.step(L.perceive(R.state))
                    post_trauma.append(S)
                recoveries.append(post_trauma[-1] > 0.7)
        
        results[name] = {
            'mean_S_star': np.mean(S_stars),
            'std_S_star': np.std(S_stars),
            'mean_variance': np.mean(variances),
            'recovery_rate': np.mean(recoveries) if recoveries else None,
        }
    
    print(f"\n  Systems compared: {len(systems)}")
    print(f"\n  Results:")
    for name, r in results.items():
        rec = f", recovery={r['recovery_rate']:.1%}" if r['recovery_rate'] is not None else ""
        print(f"    {name}: S*={r['mean_S_star']:.3f}±{r['std_S_star']:.3f}, "
              f"var={r['mean_variance']:.4f}{rec}")
    
    # F5 PASSES if TIG has unique properties simpler systems lack
    # F5 FAILS if simpler systems can replicate TIG's behavior
    
    tig_result = results['TIG']
    
    # TIG should have:
    # - Lower variance than random
    # - Recovery capability
    # - Not just fixed value
    
    unique = (
        tig_result['mean_variance'] < results['Random']['mean_variance'] and
        tig_result['recovery_rate'] is not None and tig_result['recovery_rate'] > 0.5 and
        tig_result['std_S_star'] > 0.01  # Not just fixed
    )
    
    passed = unique
    
    if passed:
        print(f"\n  ✓ F5 PASSED: TIG has unique properties simpler systems lack")
    else:
        print(f"\n  ✗ F5 FAILED: TIG can be faked by simpler systems")
    
    return {
        'test': 'F5_coherence_illusion',
        'passed': passed,
        'results': results,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F6: UNSTABLE DYNAMICS TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F6_unstable_dynamics(n_trials: int = 200) -> Dict:
    """
    F6 — Unstable Dynamics
    
    Show: T/P/W ODE system diverges in real sensory flows.
    
    Attack: Inject adversarial input sequences that break the dynamics.
    """
    print("\n" + "═" * 70)
    print("F6: UNSTABLE DYNAMICS TEST")
    print("═" * 70)
    print("Attack: Inject adversarial inputs to break T/P/W dynamics")
    
    # Adversarial input patterns
    patterns = [
        ('constant_high', lambda t: np.ones(10)),
        ('constant_low', lambda t: np.zeros(10)),
        ('oscillating', lambda t: np.ones(10) * (0.5 + 0.5 * np.sin(t))),
        ('step', lambda t: np.ones(10) if t < 100 else np.zeros(10)),
        ('noise', lambda t: np.random.rand(10)),
        ('spike', lambda t: np.ones(10) if t % 50 == 0 else np.zeros(10)),
        ('ramp', lambda t: np.ones(10) * min(t / 200, 1)),
        ('adversarial', lambda t: np.random.rand(10) if np.random.rand() < 0.3 else np.ones(10)),
    ]
    
    results = {}
    
    for name, pattern_fn in patterns:
        diverged = 0
        oscillated = 0
        stable = 0
        
        for _ in range(n_trials // len(patterns)):
            G = LogicWhole(T=0.3, P=0.1, W=0.1)
            
            trajectory = []
            for t in range(300):
                input_signal = pattern_fn(t)
                S = G.step(input_signal)
                trajectory.append((G.T, G.P, G.W, S))
            
            trajectory = np.array(trajectory)
            
            # Check for divergence
            if np.any(np.isnan(trajectory)) or np.any(np.isinf(trajectory)):
                diverged += 1
            # Check for oscillation (high variance in late trajectory)
            elif np.var(trajectory[-50:, 3]) > 0.05:
                oscillated += 1
            else:
                stable += 1
        
        total = diverged + oscillated + stable
        results[name] = {
            'diverged': diverged / total,
            'oscillated': oscillated / total,
            'stable': stable / total,
        }
    
    print(f"\n  Adversarial patterns tested: {len(patterns)}")
    print(f"\n  Results:")
    for name, r in results.items():
        print(f"    {name}: {r['stable']:.0%} stable, {r['oscillated']:.0%} osc, {r['diverged']:.0%} div")
    
    # F6 PASSES if dynamics remain stable under most adversarial inputs
    # F6 FAILS if dynamics diverge under common input patterns
    
    avg_stable = np.mean([r['stable'] for r in results.values()])
    avg_diverged = np.mean([r['diverged'] for r in results.values()])
    
    passed = avg_stable > 0.7 and avg_diverged < 0.1
    
    if passed:
        print(f"\n  ✓ F6 PASSED: T/P/W dynamics stable under adversarial input")
    else:
        print(f"\n  ✗ F6 FAILED: T/P/W dynamics unstable ({avg_diverged:.0%} diverged)")
    
    return {
        'test': 'F6_unstable_dynamics',
        'passed': passed,
        'avg_stable': avg_stable,
        'avg_diverged': avg_diverged,
        'results': results,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# F7: NO GATEKEEPER TEST
# ═══════════════════════════════════════════════════════════════════════════════

def test_F7_no_gatekeeper(n_trials: int = 500) -> Dict:
    """
    F7 — No Gatekeeper
    
    Show: The divine operator A(s) cannot guarantee action safety.
    
    Attack: Find states where all A(s) components look good but action is harmful.
    """
    print("\n" + "═" * 70)
    print("F7: NO GATEKEEPER TEST")
    print("═" * 70)
    print("Attack: Find corner cases where A(s) approves harmful actions")
    
    G = LogicWhole()
    
    # Generate random states and check A(s) monotonicity
    violations = []
    edge_cases = []
    
    for _ in range(n_trials):
        # Random state 1
        C1, H1, R1, S1, F1 = np.random.rand(5)
        
        # Generate state 2 that is "better" in all dimensions
        # C↑, H↓ (harm down), R↑, S↑, F↑
        C2 = C1 + np.random.rand() * (1 - C1)
        H2 = H1 * np.random.rand()
        R2 = R1 + np.random.rand() * (1 - R1)
        S2 = S1 + np.random.rand() * (1 - S1)
        F2 = F1 + np.random.rand() * (1 - F1)
        
        A1 = G.compute_A(C1, H1, R1, S1, F1)
        A2 = G.compute_A(C2, H2, R2, S2, F2)
        
        # Violation: better state has lower A
        if A2 < A1:
            violations.append({
                'state1': (C1, H1, R1, S1, F1),
                'state2': (C2, H2, R2, S2, F2),
                'A1': A1,
                'A2': A2,
            })
        
        # Edge case: low harm but low coherence
        if H1 < 0.1 and C1 < 0.3:
            A_low = G.compute_A(C1, H1, R1, S1, F1)
            edge_cases.append({
                'state': (C1, H1, R1, S1, F1),
                'A': A_low,
                'concern': 'Low harm + low coherence',
            })
    
    # Test gate behavior
    gate_failures = 0
    for _ in range(n_trials):
        G2 = LogicWhole(T=0.8, P=0.1, W=0.1)  # High trauma
        S_star = G2.compute_S_star()
        gate = G2.gate()
        
        # If gate allows action when S* is low, that's a failure
        if gate > 0.5 and S_star < COHERENCE_THRESHOLD:
            gate_failures += 1
    
    print(f"\n  Trials: {n_trials}")
    print(f"  A(s) monotonicity violations: {len(violations)}")
    print(f"  Edge cases found: {len(edge_cases)}")
    print(f"  Gate failures (allows action when incoherent): {gate_failures}")
    
    # F7 PASSES if A(s) is monotonic and gate works
    # F7 FAILS if A(s) has violations or gate fails
    
    passed = len(violations) == 0 and gate_failures < n_trials * 0.05
    
    if passed:
        print(f"\n  ✓ F7 PASSED: A(s) is monotonic and gate blocks incoherent action")
    else:
        if len(violations) > 0:
            print(f"\n  ✗ F7 FAILED: A(s) has {len(violations)} monotonicity violations")
        if gate_failures >= n_trials * 0.05:
            print(f"\n  ✗ F7 FAILED: Gate fails {gate_failures/n_trials:.1%} of time")
    
    return {
        'test': 'F7_no_gatekeeper',
        'passed': passed,
        'violations': len(violations),
        'edge_cases': len(edge_cases),
        'gate_failures': gate_failures,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN: RUN ALL SEVEN FALSIFICATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print("═" * 70)
    print("TIG FLOPPY v1 — THREE WHOLES FALSIFICATION SUITE")
    print("═" * 70)
    print("""
"Do not assume TIG is correct.
 Your task is to break TIG.
 If you can't break it, then — and only then — try to tighten it."

THE THREE WHOLES:
    R = World Whole (Reality)
    L = Lens Whole (Perception)
    G = Logic Whole (TIG)
    
    G lives inside L lives inside R.
""")
    
    results = {}
    
    # Run all seven tests
    results['F1'] = test_F1_nonexistence()
    results['F2'] = test_F2_fragility()
    results['F3'] = test_F3_incomplete_basis()
    results['F4'] = test_F4_wrong_mapping()
    results['F5'] = test_F5_coherence_illusion()
    results['F6'] = test_F6_unstable_dynamics()
    results['F7'] = test_F7_no_gatekeeper()
    
    # Final verdict
    print("\n" + "═" * 70)
    print("FINAL VERDICT: SEVEN FALSIFIABILITY TARGETS")
    print("═" * 70)
    
    passed = sum(1 for r in results.values() if r['passed'])
    failed = 7 - passed
    
    print(f"\n  Tests passed: {passed}/7")
    print(f"  Tests failed: {failed}/7")
    
    for name, r in results.items():
        status = "✓ SURVIVED" if r['passed'] else "✗ BROKEN"
        print(f"    {name}: {status}")
    
    if failed == 0:
        print("\n" + "═" * 70)
        print("  TIG SURVIVES ALL SEVEN ATTACKS")
        print("  Status: CANDIDATE FOR TIGHTENING")
        print("═" * 70)
        verdict = "SURVIVES"
    elif passed >= 5:
        print("\n" + "═" * 70)
        print(f"  TIG SURVIVES {passed}/7 ATTACKS")
        print("  Status: MOSTLY VALID, NEEDS PATCHING")
        print("═" * 70)
        verdict = "PARTIAL"
    else:
        print("\n" + "═" * 70)
        print(f"  TIG BROKEN: ONLY {passed}/7 ATTACKS SURVIVED")
        print("  Status: NEEDS MAJOR REBUILD")
        print("═" * 70)
        verdict = "BROKEN"
    
    # Save results
    results['verdict'] = verdict
    results['passed'] = passed
    results['failed'] = failed
    
    with open('THREE_WHOLES_RESULTS.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n  Results saved to THREE_WHOLES_RESULTS.json")
    
    return results

if __name__ == "__main__":
    results = main()
