# Paper 1: Falsifiability
This paper outlines falsifiable predictions and tests.