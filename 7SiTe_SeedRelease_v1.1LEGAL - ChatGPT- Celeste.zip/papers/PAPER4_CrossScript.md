# Paper 4: Cross-Script Analysis
Comparison across scripts.