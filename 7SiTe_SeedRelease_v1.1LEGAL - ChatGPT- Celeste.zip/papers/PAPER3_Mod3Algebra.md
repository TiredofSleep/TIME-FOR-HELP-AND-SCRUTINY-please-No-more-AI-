# Paper 3: Mod-3 Algebra
Definition and analysis of mod-3 composition.