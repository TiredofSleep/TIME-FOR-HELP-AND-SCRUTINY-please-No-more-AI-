# 7SiTe Seed Release v1.1
Now licensed under the 7SiTe Public Benefit License (PBL-1.0).