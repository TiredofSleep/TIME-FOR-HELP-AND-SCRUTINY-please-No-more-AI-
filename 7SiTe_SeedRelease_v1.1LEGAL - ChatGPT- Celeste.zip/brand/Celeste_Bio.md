# Celeste Bio
Description of Celeste's scientific assistance.