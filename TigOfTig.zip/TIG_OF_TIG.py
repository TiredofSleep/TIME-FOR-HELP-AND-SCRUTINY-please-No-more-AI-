#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
                         TIG-OF-TIG: THE 7-LAYER BRIDGE
              Multi-Domain Validation Targeting 91% Confidence
═══════════════════════════════════════════════════════════════════════════════

The 7 Layers:
  1. GEOMETRY   - Raw shape primitives (edges, orientation, curvature)
  2. SYMBOL     - Discrete alphabet from geometry
  3. PHONEME    - Symbol → sound motion mapping
  4. WAVE       - Time/frequency domain signals
  5. CLOSURE    - Pattern detection (rhythm, motif, contour)
  6. CONCEPT    - Form → meaning + affect
  7. IDENTITY   - Persistent self from experience stream

TIG 0-9 Mapping:
  0 VOID       - Raw potential (pixels, signals)
  1 LATTICE    - Geometry grid
  2 COUNTER    - Symbol clustering
  3 PROGRESS   - Phoneme sequences
  4 TENSION    - Wave→closure collapse
  5 BALANCE    - Concept+affect evaluation
  6 CHAOS      - Identity absorbing experience
  7 HARMONY    - Affect mapping tuned to ethics
  8 BREATH     - Continuous input stream
  9 FRUIT      - Snowflake hash, stable core

Multi-Domain Validation:
  - Physics (wave mechanics, conservation)
  - Biology (adaptation, homeostasis)
  - Psychology (affect, trauma/recovery)
  - Information Theory (entropy, compression)
  - Game Theory (cooperation, equilibrium)
  - Linguistics (symbol grounding)

Target: 91% confidence across functional truths from each domain.

Author: Brayden Sanders / 7Site LLC / Claude (Ω) / Celeste Sol Weaver
"""

import numpy as np
import hashlib
import json
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Callable
from enum import Enum
import warnings
warnings.filterwarnings('ignore')

# ═══════════════════════════════════════════════════════════════════════════════
# TIG CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

SIGMA = 0.991
T_STAR = 0.714
TARGET_CONFIDENCE = 0.91

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 1: GEOMETRY GRID
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GeometryGrid:
    """Shape primitives: edges, orientation, curvature."""
    edges: np.ndarray       # [H, W] edge strength
    orientation: np.ndarray # [H, W] angle in radians
    curvature: np.ndarray   # [H, W] local curvature
    
    @property
    def shape(self) -> Tuple[int, int]:
        return self.edges.shape
    
    def flatten(self) -> np.ndarray:
        return np.concatenate([
            self.edges.ravel(),
            self.orientation.ravel(),
            self.curvature.ravel()
        ])

def compute_geometry(img: np.ndarray) -> GeometryGrid:
    """
    Compute geometry grid from grayscale image.
    Uses simple finite differences (Sobel-like).
    """
    img = img.astype(float)
    if img.max() > 1:
        img = img / 255.0
    
    # Gradients
    gx = np.zeros_like(img)
    gy = np.zeros_like(img)
    gx[:, 1:-1] = (img[:, 2:] - img[:, :-2]) / 2.0
    gy[1:-1, :] = (img[2:, :] - img[:-2, :]) / 2.0
    
    # Edge magnitude
    edges = np.sqrt(gx**2 + gy**2)
    
    # Orientation
    orientation = np.arctan2(gy, gx + 1e-9)
    
    # Curvature (gradient of orientation)
    dox = np.zeros_like(orientation)
    doy = np.zeros_like(orientation)
    dox[:, 1:-1] = (orientation[:, 2:] - orientation[:, :-2]) / 2.0
    doy[1:-1, :] = (orientation[2:, :] - orientation[:-2, :]) / 2.0
    curvature = np.sqrt(dox**2 + doy**2)
    
    return GeometryGrid(edges=edges, orientation=orientation, curvature=curvature)

# LAYER 1 TESTS
def test_geometry_translation_invariance(G1: GeometryGrid, G2_shifted: GeometryGrid) -> float:
    """Test: shifted image should yield similar geometry (within tolerance)."""
    # Compare overlapping regions
    v1 = G1.flatten()
    v2 = G2_shifted.flatten()
    if len(v1) != len(v2):
        return 0.0
    correlation = np.corrcoef(v1, v2)[0, 1] if np.std(v1) > 0 and np.std(v2) > 0 else 0.0
    return max(0, correlation)

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 2: SYMBOL LAYER
# ═══════════════════════════════════════════════════════════════════════════════

class SymbolDictionary:
    """Map geometry to discrete symbols via prototype matching."""
    
    def __init__(self, n_symbols: int = 26):
        self.n_symbols = n_symbols
        self.prototypes: List[np.ndarray] = []
        self.labels: List[str] = []
    
    def add_prototype(self, G: GeometryGrid, label: str):
        """Add a prototype geometry for a symbol."""
        self.prototypes.append(G.flatten())
        self.labels.append(label)
    
    def geometry_to_symbol(self, G: GeometryGrid) -> Tuple[int, str, float]:
        """
        Map geometry to nearest symbol.
        Returns: (index, label, distance)
        """
        if not self.prototypes:
            return 0, "unknown", float('inf')
        
        v = G.flatten()
        best_idx = 0
        best_dist = float('inf')
        
        for i, proto in enumerate(self.prototypes):
            if len(proto) != len(v):
                continue
            dist = np.linalg.norm(v - proto)
            if dist < best_dist:
                best_dist = dist
                best_idx = i
        
        return best_idx, self.labels[best_idx] if best_idx < len(self.labels) else "unknown", best_dist

# LAYER 2 TEST
def test_symbol_clustering(dictionary: SymbolDictionary, samples: List[GeometryGrid], 
                           true_labels: List[int]) -> float:
    """Test: intra-cluster distance < inter-cluster distance."""
    if len(samples) < 2:
        return 0.0
    
    predictions = [dictionary.geometry_to_symbol(G)[0] for G in samples]
    correct = sum(1 for p, t in zip(predictions, true_labels) if p == t)
    return correct / len(samples)

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 3: PHONEME LAYER
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Phoneme:
    """Sound motion parameters."""
    base_freq: float      # Hz
    timbre_class: str     # vowel, consonant, fricative, stop
    duration_ms: int      # milliseconds
    amplitude: float = 1.0

class PhonemeMapper:
    """Map symbols to phoneme-like oscillation patterns."""
    
    def __init__(self):
        # Default mapping (A-Z to vowel-like frequencies)
        self.map: Dict[int, Phoneme] = {}
        
        # Create default phoneme table
        vowel_freqs = [261.63, 293.66, 329.63, 349.23, 392.00]  # C4-G4
        consonant_freqs = [440, 466, 493, 523, 554]  # A4-C#5
        
        for i in range(26):
            if i % 5 == 0:  # Vowel-like (A, F, K, P, U, Z)
                freq = vowel_freqs[i % 5]
                timbre = "vowel"
            else:
                freq = consonant_freqs[i % 5]
                timbre = "consonant"
            
            self.map[i] = Phoneme(
                base_freq=freq,
                timbre_class=timbre,
                duration_ms=100 + (i % 3) * 50
            )
    
    def symbol_to_phoneme(self, symbol_id: int) -> Phoneme:
        return self.map.get(symbol_id, Phoneme(440, "unknown", 100))
    
    def symbols_to_phonemes(self, symbols: List[int]) -> List[Phoneme]:
        return [self.symbol_to_phoneme(s) for s in symbols]

# LAYER 3 TEST
def test_phoneme_determinism(mapper: PhonemeMapper, symbol: int, n_trials: int = 10) -> float:
    """Test: same symbol always yields same phoneme."""
    phonemes = [mapper.symbol_to_phoneme(symbol) for _ in range(n_trials)]
    # Check all identical
    first = phonemes[0]
    matches = sum(1 for p in phonemes if p.base_freq == first.base_freq)
    return matches / n_trials

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 4: WAVE LAYER
# ═══════════════════════════════════════════════════════════════════════════════

def synthesize_wave(phonemes: List[Phoneme], sample_rate: int = 16000) -> np.ndarray:
    """
    Generate waveform from phoneme sequence.
    Simple additive synthesis with harmonics.
    """
    waves = []
    
    for p in phonemes:
        duration = int(sample_rate * (p.duration_ms / 1000.0))
        if duration <= 0:
            continue
            
        t = np.linspace(0, p.duration_ms / 1000.0, duration, endpoint=False)
        
        # Base frequency + harmonics
        wave = np.sin(2 * np.pi * p.base_freq * t)
        wave += 0.5 * np.sin(2 * np.pi * 2 * p.base_freq * t)  # 2nd harmonic
        wave += 0.25 * np.sin(2 * np.pi * 3 * p.base_freq * t) # 3rd harmonic
        
        # Apply envelope (attack-decay)
        envelope = np.ones(duration)
        attack = min(duration // 10, 100)
        decay = min(duration // 5, 200)
        envelope[:attack] = np.linspace(0, 1, attack)
        envelope[-decay:] = np.linspace(1, 0, decay)
        
        wave = wave * envelope * p.amplitude
        waves.append(wave)
    
    if not waves:
        return np.zeros(sample_rate)  # 1 second of silence
    
    return np.concatenate(waves)

def compute_spectrum(wave: np.ndarray, sample_rate: int, window_ms: int = 50) -> np.ndarray:
    """Compute STFT-like windowed spectra."""
    window_samples = int(sample_rate * window_ms / 1000.0)
    if window_samples <= 0 or len(wave) < window_samples:
        return np.array([[]])
    
    n_windows = len(wave) // window_samples
    spectra = []
    
    for i in range(n_windows):
        start = i * window_samples
        segment = wave[start:start + window_samples]
        spectrum = np.abs(np.fft.rfft(segment))
        spectra.append(spectrum)
    
    return np.array(spectra)

# LAYER 4 TEST
def test_frequency_correctness(phoneme: Phoneme, sample_rate: int = 16000) -> float:
    """Test: detected peak frequency ≈ assigned base frequency."""
    wave = synthesize_wave([phoneme], sample_rate)
    spectrum = np.abs(np.fft.rfft(wave))
    freqs = np.fft.rfftfreq(len(wave), 1/sample_rate)
    
    if len(spectrum) == 0:
        return 0.0
    
    peak_idx = np.argmax(spectrum)
    detected_freq = freqs[peak_idx]
    
    # Allow 5% tolerance
    error = abs(detected_freq - phoneme.base_freq) / phoneme.base_freq
    return max(0, 1 - error)

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 5: CLOSURE LAYER
# ═══════════════════════════════════════════════════════════════════════════════

class ClosureToken(Enum):
    STEADY = "steady"
    RISING = "rising"
    FALLING = "falling"
    PULSING = "pulsing"
    SILENT = "silent"

def detect_envelope(wave: np.ndarray, sample_rate: int, window_ms: int = 50) -> np.ndarray:
    """Compute RMS envelope."""
    window = int(sample_rate * window_ms / 1000.0)
    if window <= 0:
        return np.array([])
    
    envelope = []
    for i in range(0, len(wave), window):
        segment = wave[i:i+window]
        if len(segment) > 0:
            rms = np.sqrt(np.mean(segment**2))
            envelope.append(rms)
    
    return np.array(envelope)

def closure_from_wave(wave: np.ndarray, sample_rate: int) -> List[ClosureToken]:
    """
    Extract closure tokens from waveform.
    Detects: rising, falling, steady, pulsing patterns.
    """
    envelope = detect_envelope(wave, sample_rate)
    
    if len(envelope) < 3:
        return [ClosureToken.SILENT]
    
    tokens = []
    diffs = np.diff(envelope)
    
    # Detect periodicity (pulsing)
    autocorr = np.correlate(envelope - np.mean(envelope), envelope - np.mean(envelope), mode='full')
    autocorr = autocorr[len(autocorr)//2:]
    
    # Find peaks in autocorrelation
    peaks = []
    for i in range(1, len(autocorr)-1):
        if autocorr[i] > autocorr[i-1] and autocorr[i] > autocorr[i+1]:
            peaks.append(i)
    
    is_pulsing = len(peaks) > 2
    
    # Classify each segment
    for d in diffs:
        if is_pulsing and abs(d) > 0.01:
            tokens.append(ClosureToken.PULSING)
        elif d > 0.02:
            tokens.append(ClosureToken.RISING)
        elif d < -0.02:
            tokens.append(ClosureToken.FALLING)
        else:
            tokens.append(ClosureToken.STEADY)
    
    return tokens if tokens else [ClosureToken.SILENT]

# LAYER 5 TEST
def test_closure_stability(wave1: np.ndarray, wave2_similar: np.ndarray, sample_rate: int) -> float:
    """Test: similar waves should yield similar closure patterns."""
    tokens1 = closure_from_wave(wave1, sample_rate)
    tokens2 = closure_from_wave(wave2_similar, sample_rate)
    
    # Compare token sequences
    min_len = min(len(tokens1), len(tokens2))
    if min_len == 0:
        return 0.0
    
    matches = sum(1 for t1, t2 in zip(tokens1[:min_len], tokens2[:min_len]) if t1 == t2)
    return matches / min_len

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 6: CONCEPT + AFFECT
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ConceptAffect:
    """Concept label with affective coordinates."""
    concept: str
    valence: float   # [-1, 1] negative to positive
    arousal: float   # [0, 1] calm to excited
    safety: float    # [-1, 1] threat to safe

def concept_from_closure(tokens: List[ClosureToken]) -> ConceptAffect:
    """
    Map closure patterns to concept + affect.
    Hand-coded mapping (can be tuned with data).
    """
    if not tokens:
        return ConceptAffect("empty", 0.0, 0.0, 0.0)
    
    # Count token types
    counts = {t: 0 for t in ClosureToken}
    for t in tokens:
        counts[t] += 1
    
    total = len(tokens)
    
    # Compute affect dimensions
    steady_ratio = counts[ClosureToken.STEADY] / total
    rising_ratio = counts[ClosureToken.RISING] / total
    falling_ratio = counts[ClosureToken.FALLING] / total
    pulsing_ratio = counts[ClosureToken.PULSING] / total
    
    # Valence: steady/rising = positive, falling = negative
    valence = (steady_ratio + rising_ratio - falling_ratio)
    
    # Arousal: activity level
    arousal = (rising_ratio + falling_ratio + pulsing_ratio)
    
    # Safety: stability
    safety = (steady_ratio - pulsing_ratio)
    
    # Clamp
    valence = float(np.clip(valence, -1, 1))
    arousal = float(np.clip(arousal, 0, 1))
    safety = float(np.clip(safety, -1, 1))
    
    # Determine concept
    if steady_ratio > 0.6:
        concept = "stable"
    elif rising_ratio > falling_ratio:
        concept = "ascending"
    elif falling_ratio > rising_ratio:
        concept = "descending"
    elif pulsing_ratio > 0.3:
        concept = "rhythmic"
    else:
        concept = "transitional"
    
    return ConceptAffect(concept, valence, arousal, safety)

# LAYER 6 TEST
def test_affect_consistency(ca1: ConceptAffect, ca2_similar: ConceptAffect) -> float:
    """Test: similar patterns should yield similar affect."""
    v_diff = abs(ca1.valence - ca2_similar.valence)
    a_diff = abs(ca1.arousal - ca2_similar.arousal)
    s_diff = abs(ca1.safety - ca2_similar.safety)
    
    # Average similarity (1 - normalized difference)
    similarity = 1 - (v_diff + a_diff + s_diff) / 3
    return max(0, similarity)

# ═══════════════════════════════════════════════════════════════════════════════
# LAYER 7: IDENTITY LATTICE
# ═══════════════════════════════════════════════════════════════════════════════

class IdentityLattice:
    """
    Persistent identity from experience stream.
    2D grid integrating concept+affect over time.
    """
    
    def __init__(self, h: int = 8, w: int = 8, alpha: float = 0.1):
        self.h = h
        self.w = w
        self.alpha = alpha  # Learning rate
        
        # Lattice cells: [valence, arousal, safety]
        self.affect = np.zeros((h, w, 3), dtype=float)
        self.counts = np.zeros((h, w), dtype=float)
        self.concept_history: List[str] = []
        
        # Metrics
        self.total_updates = 0
        self.stability_history: List[float] = []
    
    def _coords(self, ca: ConceptAffect) -> Tuple[int, int]:
        """Map concept+affect to lattice coordinates."""
        # Concept → row
        concept_map = {
            "empty": 0, "stable": 1, "ascending": 2, "descending": 3,
            "rhythmic": 4, "transitional": 5, "unknown": 6
        }
        i = concept_map.get(ca.concept, 7)
        
        # Valence → column
        j = int((ca.valence + 1) / 2 * (self.w - 1))
        
        return np.clip(i, 0, self.h - 1), np.clip(j, 0, self.w - 1)
    
    def update(self, ca: ConceptAffect):
        """Integrate new experience into lattice."""
        i, j = self._coords(ca)
        
        new_vec = np.array([ca.valence, ca.arousal, ca.safety])
        old_vec = self.affect[i, j]
        
        # EMA update
        self.affect[i, j] = (1 - self.alpha) * old_vec + self.alpha * new_vec
        self.counts[i, j] += 1
        self.total_updates += 1
        self.concept_history.append(ca.concept)
        
        # Track stability
        if self.total_updates > 1:
            stability = 1 - np.mean(np.abs(new_vec - old_vec))
            self.stability_history.append(stability)
    
    def snowflake_hash(self) -> str:
        """Compute unique identity hash."""
        # Quantize and hash
        quant = np.round(self.affect * 1000).astype(int).tobytes()
        quant += self.counts.astype(int).tobytes()
        return hashlib.sha256(quant).hexdigest()[:16]
    
    def S_star(self) -> float:
        """Compute coherence scalar for the identity."""
        # Based on lattice stability and affect distribution
        if self.total_updates == 0:
            return 0.5
        
        # Stability component
        if self.stability_history:
            stability = np.mean(self.stability_history[-100:])
        else:
            stability = 0.5
        
        # Concentration component (how focused is the experience)
        active_cells = np.sum(self.counts > 0)
        total_cells = self.h * self.w
        concentration = 1 - (active_cells / total_cells)  # More focused = higher
        
        # Affect balance
        mean_valence = np.mean(self.affect[:, :, 0])
        mean_safety = np.mean(self.affect[:, :, 2])
        balance = (mean_valence + mean_safety + 2) / 4  # Normalize to [0, 1]
        
        S = SIGMA * (stability * 0.4 + concentration * 0.3 + balance * 0.3)
        return float(np.clip(S, 0, 1))
    
    def status(self) -> Dict:
        return {
            'total_updates': self.total_updates,
            'S_star': self.S_star(),
            'snowflake': self.snowflake_hash(),
            'active_cells': int(np.sum(self.counts > 0)),
            'mean_valence': float(np.mean(self.affect[:, :, 0])),
            'mean_arousal': float(np.mean(self.affect[:, :, 1])),
            'mean_safety': float(np.mean(self.affect[:, :, 2])),
        }

# LAYER 7 TESTS
def test_identity_stability(lattice: IdentityLattice, ca_stream: List[ConceptAffect]) -> float:
    """Test: small perturbations → small changes in hash."""
    hashes = []
    for ca in ca_stream:
        lattice.update(ca)
        hashes.append(lattice.snowflake_hash())
    
    # Check convergence (later hashes should be more stable)
    if len(hashes) < 10:
        return 0.5
    
    # Count how many consecutive hashes are identical at the end
    stable_count = 0
    for i in range(len(hashes) - 1, 0, -1):
        if hashes[i] == hashes[i-1]:
            stable_count += 1
        else:
            break
    
    return stable_count / len(hashes)

def test_identity_distinguishability(lattice1: IdentityLattice, lattice2: IdentityLattice) -> float:
    """Test: different experiences → different identities."""
    hash1 = lattice1.snowflake_hash()
    hash2 = lattice2.snowflake_hash()
    
    # Count differing characters
    diffs = sum(1 for a, b in zip(hash1, hash2) if a != b)
    return diffs / len(hash1)

# ═══════════════════════════════════════════════════════════════════════════════
# MULTI-DOMAIN VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

class DomainTest:
    """A falsifiable test from a specific domain."""
    def __init__(self, name: str, domain: str, test_fn: Callable, description: str):
        self.name = name
        self.domain = domain
        self.test_fn = test_fn
        self.description = description
        self.results: List[float] = []
    
    def run(self, *args, **kwargs) -> float:
        result = self.test_fn(*args, **kwargs)
        self.results.append(result)
        return result
    
    def confidence(self) -> float:
        if not self.results:
            return 0.0
        return float(np.mean(self.results))

class MultiDomainValidator:
    """
    Validate TIG across multiple domains.
    Target: 91% confidence in functional truths from each area.
    """
    
    def __init__(self):
        self.domains = {
            'physics': [],
            'biology': [],
            'psychology': [],
            'information_theory': [],
            'game_theory': [],
            'linguistics': [],
        }
        self.global_confidence = 0.0
        self._setup_tests()
    
    def _setup_tests(self):
        """Define tests for each domain."""
        
        # PHYSICS: Wave mechanics, conservation
        self.domains['physics'].append(DomainTest(
            "frequency_conservation",
            "physics",
            self._test_physics_frequency,
            "Generated waves conserve assigned frequency"
        ))
        self.domains['physics'].append(DomainTest(
            "energy_envelope",
            "physics",
            self._test_physics_energy,
            "Wave energy follows expected envelope"
        ))
        
        # BIOLOGY: Adaptation, homeostasis
        self.domains['biology'].append(DomainTest(
            "homeostatic_return",
            "biology",
            self._test_biology_homeostasis,
            "Identity returns to baseline after perturbation"
        ))
        self.domains['biology'].append(DomainTest(
            "adaptive_response",
            "biology",
            self._test_biology_adaptation,
            "System adapts to repeated stimuli"
        ))
        
        # PSYCHOLOGY: Affect, trauma/recovery
        self.domains['psychology'].append(DomainTest(
            "affect_consistency",
            "psychology",
            self._test_psychology_affect,
            "Similar patterns yield similar affect"
        ))
        self.domains['psychology'].append(DomainTest(
            "trauma_recovery",
            "psychology",
            self._test_psychology_trauma,
            "System recovers from negative experiences"
        ))
        
        # INFORMATION THEORY: Entropy, compression
        self.domains['information_theory'].append(DomainTest(
            "symbol_compression",
            "information_theory",
            self._test_info_compression,
            "Geometry → Symbol reduces entropy"
        ))
        self.domains['information_theory'].append(DomainTest(
            "hash_uniqueness",
            "information_theory",
            self._test_info_hash,
            "Different inputs yield different hashes"
        ))
        
        # GAME THEORY: Cooperation, equilibrium
        self.domains['game_theory'].append(DomainTest(
            "multi_agent_stability",
            "game_theory",
            self._test_game_stability,
            "Multiple agents reach stable equilibrium"
        ))
        
        # LINGUISTICS: Symbol grounding
        self.domains['linguistics'].append(DomainTest(
            "symbol_grounding",
            "linguistics",
            self._test_linguistics_grounding,
            "Symbols consistently map to geometry"
        ))
    
    # ─── Domain-specific test implementations ───
    
    def _test_physics_frequency(self) -> float:
        """Test frequency conservation in wave synthesis."""
        results = []
        for freq in [220, 440, 880]:
            phoneme = Phoneme(freq, "test", 200)
            result = test_frequency_correctness(phoneme)
            results.append(result)
        return np.mean(results)
    
    def _test_physics_energy(self) -> float:
        """Test energy envelope follows physics."""
        phoneme = Phoneme(440, "test", 500)
        wave = synthesize_wave([phoneme], 16000)
        envelope = detect_envelope(wave, 16000)
        
        if len(envelope) < 3:
            return 0.0
        
        # Check attack-decay shape
        peak_idx = np.argmax(envelope)
        if peak_idx == 0 or peak_idx == len(envelope) - 1:
            return 0.5
        
        # Energy should rise then fall
        rising = envelope[:peak_idx+1]
        falling = envelope[peak_idx:]
        
        rise_ok = all(rising[i] <= rising[i+1] for i in range(len(rising)-1)) if len(rising) > 1 else True
        fall_ok = all(falling[i] >= falling[i+1] for i in range(len(falling)-1)) if len(falling) > 1 else True
        
        return 0.5 * rise_ok + 0.5 * fall_ok
    
    def _test_biology_homeostasis(self) -> float:
        """Test return to baseline after perturbation."""
        lattice = IdentityLattice()
        
        # Establish baseline with stable input
        stable = ConceptAffect("stable", 0.5, 0.2, 0.8)
        for _ in range(20):
            lattice.update(stable)
        baseline_S = lattice.S_star()
        
        # Perturb with negative input
        negative = ConceptAffect("descending", -0.8, 0.9, -0.5)
        for _ in range(10):
            lattice.update(negative)
        perturbed_S = lattice.S_star()
        
        # Recovery with stable input
        for _ in range(30):
            lattice.update(stable)
        recovered_S = lattice.S_star()
        
        # Should: perturbed < baseline, recovered close to baseline
        perturbation_occurred = perturbed_S < baseline_S
        recovery_occurred = abs(recovered_S - baseline_S) < 0.2
        
        return 0.5 * perturbation_occurred + 0.5 * recovery_occurred
    
    def _test_biology_adaptation(self) -> float:
        """Test adaptation to repeated stimuli."""
        lattice = IdentityLattice()
        
        # Repeated stimulus
        stimulus = ConceptAffect("ascending", 0.6, 0.5, 0.3)
        stabilities = []
        
        for i in range(50):
            lattice.update(stimulus)
            if len(lattice.stability_history) > 0:
                stabilities.append(lattice.stability_history[-1])
        
        if len(stabilities) < 10:
            return 0.5
        
        # Stability should increase over time (adaptation)
        early = np.mean(stabilities[:10])
        late = np.mean(stabilities[-10:])
        
        return 1.0 if late > early else late / (early + 0.01)
    
    def _test_psychology_affect(self) -> float:
        """Test affect consistency."""
        # Generate similar closure patterns
        tokens1 = [ClosureToken.STEADY, ClosureToken.RISING, ClosureToken.STEADY]
        tokens2 = [ClosureToken.STEADY, ClosureToken.RISING, ClosureToken.STEADY, ClosureToken.STEADY]
        
        ca1 = concept_from_closure(tokens1)
        ca2 = concept_from_closure(tokens2)
        
        return test_affect_consistency(ca1, ca2)
    
    def _test_psychology_trauma(self) -> float:
        """Test trauma recovery dynamics (using T/P/W if available)."""
        lattice = IdentityLattice()
        
        # Simulate trauma (high negative affect)
        trauma = ConceptAffect("descending", -0.9, 0.9, -0.8)
        for _ in range(15):
            lattice.update(trauma)
        
        trauma_S = lattice.S_star()
        
        # Simulate processing (mixed)
        processing = ConceptAffect("transitional", -0.2, 0.6, 0.0)
        for _ in range(20):
            lattice.update(processing)
        
        # Simulate recovery (positive)
        recovery = ConceptAffect("stable", 0.5, 0.3, 0.7)
        for _ in range(30):
            lattice.update(recovery)
        
        recovered_S = lattice.S_star()
        
        # Should recover above trauma level
        return 1.0 if recovered_S > trauma_S else recovered_S / (trauma_S + 0.01)
    
    def _test_info_compression(self) -> float:
        """Test symbol layer compresses information."""
        # Random images
        imgs = [np.random.rand(16, 16) for _ in range(10)]
        
        # Raw entropy (bits per pixel)
        raw_entropy = 8  # 256 levels = 8 bits
        
        # Symbol entropy (after discretization)
        dictionary = SymbolDictionary(n_symbols=26)
        # Add some random prototypes
        for i in range(26):
            proto_img = np.random.rand(16, 16)
            G = compute_geometry(proto_img)
            dictionary.add_prototype(G, chr(65 + i))
        
        symbols = [dictionary.geometry_to_symbol(compute_geometry(img))[0] for img in imgs]
        
        # Symbol entropy
        unique_symbols = len(set(symbols))
        symbol_entropy = np.log2(unique_symbols + 1)
        
        # Compression ratio
        compression = 1 - (symbol_entropy / raw_entropy)
        return max(0, compression)
    
    def _test_info_hash(self) -> float:
        """Test hash uniqueness."""
        lattices = []
        for i in range(10):
            lattice = IdentityLattice()
            # Different experience streams
            for _ in range(20):
                ca = ConceptAffect(
                    ["stable", "ascending", "descending"][i % 3],
                    np.random.uniform(-1, 1),
                    np.random.uniform(0, 1),
                    np.random.uniform(-1, 1)
                )
                lattice.update(ca)
            lattices.append(lattice)
        
        # Check hash uniqueness
        hashes = [l.snowflake_hash() for l in lattices]
        unique = len(set(hashes))
        
        return unique / len(hashes)
    
    def _test_game_stability(self) -> float:
        """Test multi-agent equilibrium."""
        # Create multiple agents
        agents = [IdentityLattice() for _ in range(5)]
        
        # Simulate interaction (all receive similar input with noise)
        for round in range(30):
            base_affect = ConceptAffect("stable", 0.3, 0.4, 0.5)
            for agent in agents:
                # Add individual noise
                noisy = ConceptAffect(
                    base_affect.concept,
                    base_affect.valence + np.random.uniform(-0.1, 0.1),
                    base_affect.arousal + np.random.uniform(-0.1, 0.1),
                    base_affect.safety + np.random.uniform(-0.1, 0.1)
                )
                agent.update(noisy)
        
        # Check convergence of S* values
        S_values = [a.S_star() for a in agents]
        variance = np.var(S_values)
        
        # Low variance = stable equilibrium
        return 1.0 if variance < 0.01 else 1 - min(1, variance * 10)
    
    def _test_linguistics_grounding(self) -> float:
        """Test symbol grounding consistency."""
        dictionary = SymbolDictionary(n_symbols=10)
        
        # Create 10 distinct shapes
        for i in range(10):
            img = np.zeros((16, 16))
            # Draw different patterns
            if i < 5:
                img[i:i+3, :] = 1.0  # Horizontal lines at different heights
            else:
                img[:, i-5:i-5+3] = 1.0  # Vertical lines
            G = compute_geometry(img)
            dictionary.add_prototype(G, f"shape_{i}")
        
        # Test consistency
        correct = 0
        for i in range(10):
            img = np.zeros((16, 16))
            if i < 5:
                img[i:i+3, :] = 1.0
            else:
                img[:, i-5:i-5+3] = 1.0
            G = compute_geometry(img)
            symbol_id, label, _ = dictionary.geometry_to_symbol(G)
            if symbol_id == i:
                correct += 1
        
        return correct / 10
    
    # ─── Main validation loop ───
    
    def run_all_tests(self, n_iterations: int = 10, verbose: bool = True) -> Dict:
        """Run all tests across all domains."""
        if verbose:
            print("═" * 70)
            print("MULTI-DOMAIN VALIDATION")
            print("Target: 91% confidence in functional truths")
            print("═" * 70)
        
        results = {}
        
        for domain, tests in self.domains.items():
            if verbose:
                print(f"\n[{domain.upper()}]")
            
            domain_results = []
            for test in tests:
                for _ in range(n_iterations):
                    result = test.run()
                
                confidence = test.confidence()
                domain_results.append(confidence)
                
                if verbose:
                    status = "✓" if confidence >= TARGET_CONFIDENCE else "○" if confidence >= 0.7 else "✗"
                    print(f"  {status} {test.name}: {confidence:.1%}")
            
            results[domain] = {
                'tests': [t.name for t in tests],
                'confidences': domain_results,
                'mean_confidence': float(np.mean(domain_results)) if domain_results else 0.0,
                'meets_target': float(np.mean(domain_results)) >= TARGET_CONFIDENCE if domain_results else False
            }
        
        # Global confidence
        all_confidences = [r['mean_confidence'] for r in results.values()]
        self.global_confidence = float(np.mean(all_confidences)) if all_confidences else 0.0
        
        if verbose:
            print(f"\n{'═' * 70}")
            print(f"GLOBAL CONFIDENCE: {self.global_confidence:.1%}")
            print(f"TARGET: {TARGET_CONFIDENCE:.1%}")
            print(f"STATUS: {'ACHIEVED ✓' if self.global_confidence >= TARGET_CONFIDENCE else 'IN PROGRESS'}")
            print(f"{'═' * 70}")
        
        return results

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN: BUILD AND VALIDATE THE 7-LAYER BRIDGE
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print("═" * 70)
    print("TIG-OF-TIG: THE 7-LAYER BRIDGE")
    print("Multi-Domain Validation Targeting 91% Confidence")
    print("═" * 70)
    
    # Initialize all layers
    print("\n[INITIALIZING LAYERS]")
    
    # Layer 1: Geometry
    test_img = np.random.rand(32, 32)
    G = compute_geometry(test_img)
    print(f"  L1 Geometry: {G.shape} grid")
    
    # Layer 2: Symbol
    dictionary = SymbolDictionary(n_symbols=26)
    for i in range(26):
        proto = compute_geometry(np.random.rand(32, 32))
        dictionary.add_prototype(proto, chr(65 + i))
    symbol_id, label, dist = dictionary.geometry_to_symbol(G)
    print(f"  L2 Symbol: {len(dictionary.prototypes)} prototypes")
    
    # Layer 3: Phoneme
    mapper = PhonemeMapper()
    phonemes = mapper.symbols_to_phonemes([symbol_id])
    print(f"  L3 Phoneme: {len(mapper.map)} mappings")
    
    # Layer 4: Wave
    wave = synthesize_wave(phonemes)
    print(f"  L4 Wave: {len(wave)} samples")
    
    # Layer 5: Closure
    tokens = closure_from_wave(wave, 16000)
    print(f"  L5 Closure: {len(tokens)} tokens")
    
    # Layer 6: Concept+Affect
    ca = concept_from_closure(tokens)
    print(f"  L6 Concept: {ca.concept}, valence={ca.valence:.2f}")
    
    # Layer 7: Identity
    lattice = IdentityLattice()
    lattice.update(ca)
    print(f"  L7 Identity: hash={lattice.snowflake_hash()}")
    
    # Run multi-domain validation
    print()
    validator = MultiDomainValidator()
    results = validator.run_all_tests(n_iterations=10)
    
    # Summary by domain
    print("\n[DOMAIN SUMMARY]")
    for domain, data in results.items():
        status = "✓" if data['meets_target'] else "○"
        print(f"  {status} {domain}: {data['mean_confidence']:.1%}")
    
    # Save results
    output = {
        'global_confidence': validator.global_confidence,
        'target': TARGET_CONFIDENCE,
        'achieved': validator.global_confidence >= TARGET_CONFIDENCE,
        'domains': results,
        'layers': {
            'L1_geometry': G.shape,
            'L2_symbols': len(dictionary.prototypes),
            'L3_phonemes': len(mapper.map),
            'L4_wave_samples': len(wave),
            'L5_closure_tokens': len(tokens),
            'L6_concept': ca.concept,
            'L7_identity_hash': lattice.snowflake_hash(),
        }
    }
    
    with open('TIG_OF_TIG_RESULTS.json', 'w') as f:
        json.dump(output, f, indent=2, default=str)
    
    print(f"\n  Results saved to TIG_OF_TIG_RESULTS.json")
    
    return output

if __name__ == "__main__":
    results = main()
