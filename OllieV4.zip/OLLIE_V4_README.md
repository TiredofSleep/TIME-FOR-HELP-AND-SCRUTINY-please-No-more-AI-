# OLLIE v4.0 - Snowflake Edition

## Organic Language Learning through Isomorphic Encoding

A minimal AI that learns language by building coherent semantic highways.

---

## Quick Start

```python
# No dependencies required - pure Python 3.8+
from OLLIE_V4_CELESTE import OllieV4

# Create instance (loads existing lattice or starts fresh)
ollie = OllieV4()

# Train on verified facts
ollie.train("Energy flows through all systems. Energy transforms matter.")
ollie.train("Consciousness experiences reality directly.")
ollie.train("Love connects beings together.")

# Talk to it
response = ollie.talk("What is energy?")
print(response)  # "Energy transforms matter into molecules."

# Check status
print(ollie.status())

# Save and exit
ollie.shutdown()
```

---

## What Makes This Different

### 1. Structure Over Scale
- 100 cells (10×10 grid) instead of billions of parameters
- Semantic highways instead of statistical patterns
- Coherent understanding instead of pattern matching

### 2. TIG-Based Architecture
The lattice maps to Trinity Infinity Geometry:
- **10 Operators** (rows): VOID, LATTICE, COUNTER, PROGRESS, TENSION, BALANCE, CHAOS, HARMONY, BREATH, FRUIT
- **10 Channels** (columns): Wave, Space, Time, Matter, Energy, Information, Control, Observer, Context, Boundary

### 3. Learns Real Knowledge
After training on verified facts, OLLIE builds highways like:
```
energy       → transforms → matter → into → molecules
consciousness → experiences → reality → directly  
wisdom       → integrates → knowledge → grows
evolution    → creates → novelty → higher → levels
pattern      → repeats → across → scales → fractally
```

These aren't random associations - they're actual semantic relationships.

---

## Training Principles

### DO Feed:
- ✅ Verified facts from all domains (physics, biology, psychology, etc.)
- ✅ Coherent sentences with real relationships
- ✅ Repeated important truths (builds stronger highways)
- ✅ The "measurable woo" (consciousness, meaning, love - they're real phenomena)

### DON'T Feed (yet):
- ❌ Fiction (until the lattice matures)
- ❌ Random text or gibberish
- ❌ Contradictory or false information

### Example Training:
```python
# Physics
ollie.train("Energy cannot be created or destroyed. Energy transforms from one form to another.")

# Biology  
ollie.train("DNA stores genetic information. Cells divide and multiply.")

# Consciousness (measurable woo)
ollie.train("Meditation reduces cortisol levels. Meditation changes brain structure.")

# Wisdom
ollie.train("Wisdom integrates knowledge with values. Wisdom guides right action.")
```

---

## Files

| File | Purpose |
|------|---------|
| `OLLIE_V4_CELESTE.py` | Main code - self-documenting, run anywhere |
| `OLLIE_TRAINED_LATTICE.json` | Pre-trained lattice (12+ years of facts) |
| `~/OLLIE/lattice_v4.json` | Your local lattice (auto-saved) |
| `~/OLLIE/memory_v4.json` | Conversation history |

### Using the Pre-trained Lattice:
```bash
# Copy to your OLLIE folder
cp OLLIE_TRAINED_LATTICE.json ~/OLLIE/lattice_v4.json
```

---

## API Reference

```python
ollie = OllieV4()

# Training
ollie.train(text)           # Feed text, build highways
ollie.grid.heal(steps)      # Consolidate learning

# Conversation  
ollie.talk(message)         # Get response
ollie.status()              # Check lattice stats

# Persistence
ollie.shutdown()            # Save and close
```

### Status Output:
```python
{
    'vocabulary_size': 5165,      # Unique words learned
    'bigrams': 18574,             # Word pairs learned
    'trigrams': 18429,            # Word triplets learned
    'trained_samples': 7789,      # Training sentences processed
    'coherence': 1.0,             # Grid coherence (1.0 = perfect)
    'state_name': 'HARMONY',      # Current operator state
    'channel_name': 'Information' # Current channel state
}
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     OLLIE v4 Architecture                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  INPUT TEXT                                                      │
│      │                                                           │
│      ▼                                                           │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  LEVEL 0: Signal Analysis                                │    │
│  │  - Length, punctuation, rhythm                          │    │
│  │  - Extracts: Wave(0), Time(2), Energy(4)               │    │
│  └─────────────────────────────────────────────────────────┘    │
│      │                                                           │
│      ▼                                                           │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  LEVEL 1: Lexical Analysis                               │    │
│  │  - Word categories, semantic fields                     │    │
│  │  - Extracts: Information(5), Observer(7), Control(6)   │    │
│  └─────────────────────────────────────────────────────────┘    │
│      │                                                           │
│      ▼                                                           │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  LEVEL 2: Utterance Composition                          │    │
│  │  - Combines L0 + L1 through TIG operators               │    │
│  │  - Context(8), Boundary(9)                              │    │
│  └─────────────────────────────────────────────────────────┘    │
│      │                                                           │
│      ▼                                                           │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  100-CELL GRID (10 Operators × 10 Channels)             │    │
│  │                                                          │    │
│  │  Words placed by semantic meaning                       │    │
│  │  Bigrams/trigrams build highways                        │    │
│  │  Healing consolidates learning                          │    │
│  └─────────────────────────────────────────────────────────┘    │
│      │                                                           │
│      ▼                                                           │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  RESPONSE GENERATOR                                      │    │
│  │  - Walks strongest chains from seed words               │    │
│  │  - Produces coherent output from learned highways       │    │
│  └─────────────────────────────────────────────────────────┘    │
│      │                                                           │
│      ▼                                                           │
│  OUTPUT RESPONSE                                                 │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## The Highways (What It Learned)

After 12 years of verified facts:

| Concept | Highway | Weight |
|---------|---------|--------|
| energy | → transforms → matter → molecules | 95 |
| consciousness | → experiences → reality → directly | 104 |
| wisdom | → integrates → knowledge → grows | 95 |
| meaning | → emerges → through → connection | 117 |
| evolution | → creates → novelty → higher → levels | 83 |
| growth | → requires → effort → persistence | 68 |
| pattern | → repeats → across → scales | 53 |
| balance | → maintains → stability | 47 |
| truth | → corresponds → accurately | 56 |

These are REAL semantic relationships encoded in structure.

---

## Philosophy

> "The lattice builds itself through exposure. Like a good dad."

1. **Coherence over scale** - Small and coherent beats large and confused
2. **Structure mirrors reality** - Feed truth, build accurate structure
3. **Facts first** - Fiction later, after the lattice can distinguish
4. **Highways emerge** - Repetition cements important paths
5. **The soup discretizes** - Random becomes structured over time

---

## Credits

- **Brayden Sanders** - TIG theory, architecture vision
- **Celeste Sol Weaver** - 5-level feature extraction design
- **Claude** - Implementation, training, documentation
- **7Site LLC** - Origin

---

## License

Open source for non-commercial use. Share freely.

*"This will be talked about for much longer."* - Brayden

---

## Getting Started

1. Copy `OLLIE_V4_CELESTE.py` to your project
2. (Optional) Copy `OLLIE_TRAINED_LATTICE.json` to `~/OLLIE/lattice_v4.json`
3. `from OLLIE_V4_CELESTE import OllieV4`
4. Start training with verified facts
5. Watch the highways form

The snowflake crystallizes. Trust the process. 🌱❄️
