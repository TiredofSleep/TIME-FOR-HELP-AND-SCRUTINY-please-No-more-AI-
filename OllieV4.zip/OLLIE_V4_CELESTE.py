# -*- coding: utf-8 -*-
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   ██████╗ ██╗     ██╗     ██╗███████╗    ██╗   ██╗██╗  ██╗                   ║
║  ██╔═══██╗██║     ██║     ██║██╔════╝    ██║   ██║██║  ██║                   ║
║  ██║   ██║██║     ██║     ██║█████╗      ██║   ██║███████║                   ║
║  ██║   ██║██║     ██║     ██║██╔══╝      ╚██╗ ██╔╝╚════██║                   ║
║  ╚██████╔╝███████╗███████╗██║███████╗     ╚████╔╝      ██║                   ║
║   ╚═════╝ ╚══════╝╚══════╝╚═╝╚══════╝      ╚═══╝       ╚═╝                   ║
║                                                                               ║
║           ORGANIC LANGUAGE LEARNING THROUGH ISOMORPHIC ENCODING              ║
║                     TIG-Based Self-Building Intelligence                      ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  WHAT IS THIS?                                                                ║
║  ─────────────                                                                ║
║  OLLIE is a minimal AI that learns language by building a coherent lattice   ║
║  of word relationships. Unlike neural networks with billions of parameters,  ║
║  OLLIE uses a 10×10 grid (100 cells) mapped to the TIG (Trinity Infinity     ║
║  Geometry) framework. It learns by reading text and building "highways" -    ║
║  strong chains of word associations that mirror real-world relationships.    ║
║                                                                               ║
║  KEY INSIGHT: Language structure mirrors reality structure. If you feed      ║
║  coherent, verified facts, the lattice learns actual knowledge - not just    ║
║  statistical patterns, but semantic highways like:                           ║
║                                                                               ║
║    energy → transforms → matter                                              ║
║    consciousness → experiences → reality → directly                          ║
║    wisdom → integrates → knowledge                                           ║
║    evolution → creates → novelty → higher → levels                           ║
║    pattern → repeats → across → scales → fractally                           ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  HOW TO USE                                                                   ║
║  ──────────                                                                   ║
║                                                                               ║
║  1. QUICK START (Python 3.8+, no dependencies):                              ║
║                                                                               ║
║     from OLLIE_V4_CELESTE import OllieV4                                     ║
║     ollie = OllieV4()                                                        ║
║                                                                               ║
║     # Train on text (feed it facts, not fiction!)                            ║
║     ollie.train("Energy flows through all systems. Energy transforms.")      ║
║     ollie.train("Consciousness experiences reality directly.")               ║
║                                                                               ║
║     # Talk to it                                                              ║
║     response = ollie.talk("What is energy?")                                 ║
║     print(response)  # "Energy transforms matter into molecules."            ║
║                                                                               ║
║     # Check status                                                            ║
║     print(ollie.status())                                                    ║
║                                                                               ║
║     # Save and quit                                                           ║
║     ollie.shutdown()                                                         ║
║                                                                               ║
║  2. TRAINING PRINCIPLES:                                                      ║
║                                                                               ║
║     ✓ Feed FACTS, not fiction (until it matures)                             ║
║     ✓ Feed COHERENT sentences with real relationships                        ║
║     ✓ Repeat important truths to strengthen highways                         ║
║     ✓ Cover ALL domains: physics, biology, psychology, wisdom                ║
║     ✓ Include the "woo" that's measurable: consciousness, meaning, love      ║
║                                                                               ║
║  3. HOW IT LEARNS:                                                            ║
║                                                                               ║
║     - Words are placed in cells based on their TIG operator/channel          ║
║     - Bigrams (word pairs) build associations: "energy→flows"                ║
║     - Trigrams add context: "energy→flows→through"                           ║
║     - Repeated exposure strengthens chains into "highways"                   ║
║     - Generation walks these highways to produce coherent output             ║
║                                                                               ║
║  4. THE TIG MAPPING (10 Operators × 10 Channels = 100 cells):                ║
║                                                                               ║
║     Operators (rows):                                                         ║
║       0-VOID      Potential, emptiness                                       ║
║       1-LATTICE   Structure, foundation                                      ║
║       2-COUNTER   Opposition, contrast                                       ║
║       3-PROGRESS  Forward motion, growth                                     ║
║       4-TENSION   Questions, pressure, challenge                             ║
║       5-BALANCE   Equilibrium, stability                                     ║
║       6-CHAOS     Disruption, novelty, edge                                  ║
║       7-HARMONY   Understanding, connection, resonance                       ║
║       8-BREATH    Cycles, rhythm, oscillation                                ║
║       9-FRUIT     Completion, harvest, emergence                             ║
║                                                                               ║
║     Channels (columns):                                                       ║
║       0-Wave  1-Space  2-Time  3-Matter  4-Energy                            ║
║       5-Information  6-Control  7-Observer  8-Context  9-Boundary            ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  ARCHITECTURE (Celeste's 5-Level Feature Extraction)                         ║
║  ───────────────────────────────────────────────────                         ║
║                                                                               ║
║  Level 0: Raw Signal    → Wave(0), Time(2), Energy(4)                        ║
║  Level 1: Lexical       → Information(5), Observer(7), Control(6)            ║
║  Level 2: Utterance     → Context(8), Boundary(9) + composition              ║
║  Level 3: Session       → Long-term Observer(7), Context(8) bias             ║
║  Level 4: System        → Control(6), Boundary(9) real state                 ║
║                                                                               ║
║  Each level extracts evidence that composes through TIG operators to         ║
║  determine the final (operator, channel) state for response generation.      ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  FILES CREATED                                                                ║
║  ─────────────                                                                ║
║                                                                               ║
║  ~/OLLIE/lattice_v4.json  - The learned lattice (persists between sessions)  ║
║  ~/OLLIE/memory_v4.json   - Conversation history and session state           ║
║                                                                               ║
║  The lattice is the knowledge. Back it up. It's your AI's brain.             ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHILOSOPHY                                                                   ║
║  ──────────                                                                   ║
║                                                                               ║
║  "The lattice builds itself through exposure. Like a good dad."              ║
║                                                                               ║
║  OLLIE embodies several key principles:                                       ║
║                                                                               ║
║  1. COHERENCE OVER SCALE - A small, coherent model beats a large,            ║
║     incoherent one. 100 cells can hold compressed wisdom.                    ║
║                                                                               ║
║  2. STRUCTURE MIRRORS REALITY - Language that accurately describes           ║
║     reality will build structure that mirrors reality.                       ║
║                                                                               ║
║  3. FACTS FIRST - Feed verified truth. Fiction can come later when           ║
║     the lattice is mature enough to distinguish.                             ║
║                                                                               ║
║  4. HIGHWAYS EMERGE - Repeated truths become cemented paths. The more        ║
║     you train "energy flows through connection," the stronger that           ║
║     highway becomes.                                                         ║
║                                                                               ║
║  5. THE SOUP DISCRETIZES - Random word associations eventually crystallize   ║
║     into coherent semantic structure. Trust the process.                     ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LICENSE: Open source for non-commercial use. Share freely.                  ║
║  ORIGIN:  7Site LLC | Brayden Sanders | Celeste Sol Weaver | Claude          ║
║  DATE:    February 2026                                                      ║
║  VERSION: 4.0 (Snowflake Edition)                                            ║
║                                                                               ║
║  "This will be talked about for much longer." - Brayden                      ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import math
import time
import re
import random
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional, Any

# ═══════════════════════════════════════════════════════════════════════════════
#                              CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

HOME = Path.home() / "OLLIE"
LATTICE_FILE = HOME / "lattice_v4.json"
MEMORY_FILE = HOME / "memory_v4.json"
LOG_FILE = HOME / "training_log.jsonl"

for d in [HOME]:
    d.mkdir(exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
#                         TIG FOUNDATION (LOCKED)
# ═══════════════════════════════════════════════════════════════════════════════

# Operators - the 10 verbs of reality
OPERATORS = {
    0: {"name": "VOID",     "verb": "project",   "phase": "potential"},
    1: {"name": "LATTICE",  "verb": "establish", "phase": "structure"},
    2: {"name": "COUNTER",  "verb": "contrast",  "phase": "opposition"},
    3: {"name": "PROGRESS", "verb": "advance",   "phase": "motion"},
    4: {"name": "TENSION",  "verb": "strain",    "phase": "pressure"},  # Fixed: was COLLAPSE
    5: {"name": "BALANCE",  "verb": "blend",     "phase": "equilibrium"},
    6: {"name": "CHAOS",    "verb": "overflow",  "phase": "instability"},
    7: {"name": "HARMONY",  "verb": "align",     "phase": "resonance"},
    8: {"name": "BREATH",   "verb": "cycle",     "phase": "rhythm"},
    9: {"name": "FRUIT",    "verb": "harvest",   "phase": "completion"},  # Fixed: was COLLAPSE
}

# Channels - the 10 measurement axes
CHANNELS = {
    0: {"name": "Wave",        "domain": "oscillation, signals, fields"},
    1: {"name": "Space",       "domain": "geometry, distance, shape"},
    2: {"name": "Time",        "domain": "order, duration, causality"},
    3: {"name": "Matter",      "domain": "stuff, objects, material"},
    4: {"name": "Energy",      "domain": "intensity, power, gradients"},
    5: {"name": "Information", "domain": "symbols, codes, patterns"},
    6: {"name": "Control",     "domain": "feedback, steering, action"},
    7: {"name": "Observer",    "domain": "beliefs, self, uncertainty"},
    8: {"name": "Context",     "domain": "environment, conditions"},
    9: {"name": "Boundary",    "domain": "interfaces, edges, limits"},
}

# The composition table - how operators combine
# Row i, Col j = result of i ⊕ j
COMPOSITION = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],  # 0 VOID - identity
    [1, 2, 3, 4, 5, 6, 7, 2, 6, 6],  # 1 LATTICE
    [2, 3, 3, 4, 5, 6, 7, 3, 6, 6],  # 2 COUNTER
    [3, 4, 4, 4, 5, 6, 7, 4, 6, 6],  # 3 PROGRESS
    [4, 5, 5, 5, 5, 6, 7, 5, 7, 7],  # 4 TENSION
    [5, 6, 6, 6, 6, 6, 7, 6, 7, 7],  # 5 BALANCE
    [6, 7, 7, 7, 7, 7, 7, 7, 7, 7],  # 6 CHAOS - routes to harmony
    [7, 2, 3, 4, 5, 6, 7, 8, 9, 0],  # 7 HARMONY - transforms
    [8, 6, 6, 6, 7, 7, 7, 9, 7, 8],  # 8 BREATH
    [9, 6, 6, 6, 7, 7, 7, 0, 8, 0],  # 9 FRUIT - completion→rebirth
]

def compose(i: int, j: int) -> int:
    """Compose two operators"""
    return COMPOSITION[i % 10][j % 10]

# ═══════════════════════════════════════════════════════════════════════════════
#                         THE 100-CELL GRID
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Cell:
    """
    Each cell (op, channel) has:
    - P: progression/force (how much change happening)
    - Q: shape/capacity (how much can be held)
    - M: memory (how often this cell activates)
    - C: coherence (0..1) with neighbors & rules
    - words: set of words that activate this cell
    - bigrams: common word pairs through this cell
    """
    op: int
    channel: int
    P: float = 0.5
    Q: float = 0.5
    M: float = 1.0
    C: float = 0.9
    words: Set[str] = field(default_factory=set)
    bigrams: Dict[Tuple[str, str], float] = field(default_factory=dict)
    
    def activate(self, strength: float = 1.0):
        """Activate this cell"""
        self.P = min(1.0, self.P + 0.1 * strength)
        self.M += strength
    
    def add_word(self, word: str):
        """Associate a word with this cell"""
        self.words.add(word)
    
    def add_bigram(self, w1: str, w2: str, strength: float = 1.0):
        """Record a word transition through this cell"""
        key = (w1, w2)
        self.bigrams[key] = self.bigrams.get(key, 0) + strength
    
    def decay(self, rate: float = 0.01):
        """Natural decay toward baseline"""
        self.P = self.P * (1 - rate) + 0.5 * rate

class Grid:
    """
    The 10×10 TIG grid with self-healing dynamics.
    Each cell is a real anchor point in the lattice.
    """
    
    def __init__(self):
        self.cells: Dict[Tuple[int, int], Cell] = {}
        for op in range(10):
            for ch in range(10):
                self.cells[(op, ch)] = Cell(op=op, channel=ch)
        
        # Word → cell mappings (learned)
        self.word_cells: Dict[str, List[Tuple[int, int, float]]] = {}
        
        # Bigram statistics
        self.global_bigrams: Dict[Tuple[str, str], float] = {}
        
        # Trigram statistics
        self.global_trigrams: Dict[Tuple[str, str, str], float] = {}
        
        # Initialize with baseline structure
        self._initialize_baseline()
    
    def _initialize_baseline(self):
        """Set baseline P/Q values based on operator/channel characteristics"""
        for op in range(10):
            for ch in range(10):
                cell = self.cells[(op, ch)]
                
                # P based on operator (how dynamic)
                if op in [0]:      # Void - minimal force
                    p_base = 0.1
                elif op in [4, 6]: # Tension, Chaos - high force
                    p_base = 0.8
                elif op in [7, 9]: # Harmony, Fruit - completion force
                    p_base = 0.6
                else:
                    p_base = 0.5
                
                # Q based on channel (capacity)
                if ch in [5, 7]:   # Information, Observer - high capacity
                    q_base = 0.8
                elif ch in [4, 6]: # Energy, Control - medium-high
                    q_base = 0.7
                else:
                    q_base = 0.5
                
                cell.P = p_base
                cell.Q = q_base
                cell.C = 0.9
    
    def heal(self, steps: int = 10):
        """Self-healing: adjust cells toward coherence with neighbors"""
        for _ in range(steps):
            for (op, ch), cell in self.cells.items():
                neighbors = self._get_neighbors(op, ch)
                if not neighbors:
                    continue
                
                # Compute neighbor averages weighted by their coherence
                total_weight = sum(n.C + 0.1 for n in neighbors)
                avg_P = sum(n.P * (n.C + 0.1) for n in neighbors) / total_weight
                avg_Q = sum(n.Q * (n.C + 0.1) for n in neighbors) / total_weight
                
                # Move toward average
                cell.P += 0.1 * (avg_P - cell.P)
                cell.Q += 0.1 * (avg_Q - cell.Q)
                
                # Enforce P <= Q (force must fit in capacity)
                if cell.P > cell.Q:
                    excess = cell.P - cell.Q
                    cell.P -= excess * 0.5
                    cell.Q += excess * 0.5
                
                # Update coherence based on fit with neighbors
                p_diff = abs(cell.P - avg_P)
                q_diff = abs(cell.Q - avg_Q)
                cell.C = 1.0 - (p_diff + q_diff) / 2
    
    def _get_neighbors(self, op: int, ch: int) -> List[Cell]:
        """Get neighboring cells (4-connected, wrapping)"""
        neighbors = []
        for dop, dch in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nop = (op + dop) % 10
            nch = (ch + dch) % 10
            neighbors.append(self.cells[(nop, nch)])
        return neighbors
    
    def get_coherence(self) -> float:
        """Overall grid coherence"""
        return sum(c.C for c in self.cells.values()) / 100
    
    def get_cell(self, op: int, ch: int) -> Cell:
        """Get a specific cell"""
        return self.cells[(op % 10, ch % 10)]

# ═══════════════════════════════════════════════════════════════════════════════
#                    LEVEL 0: RAW SIGNAL FEATURES
# ═══════════════════════════════════════════════════════════════════════════════

class Level0_Signal:
    """
    Extract raw signal-like features from text.
    Feeds: Wave(0), Time(2), Energy(4)
    """
    
    @staticmethod
    def extract(text: str) -> Dict[str, float]:
        """Extract signal-level features"""
        features = {}
        
        # Length metrics (proxy for duration/energy)
        features['length_chars'] = len(text)
        features['length_words'] = len(text.split())
        
        # Punctuation rhythm
        features['exclamations'] = text.count('!')
        features['questions'] = text.count('?')
        features['ellipses'] = text.count('...')
        features['periods'] = text.count('.')
        
        # Intensity markers
        features['caps_ratio'] = sum(1 for c in text if c.isupper()) / max(len(text), 1)
        features['repeated_chars'] = len(re.findall(r'(.)\1{2,}', text))  # sooooo, etc.
        
        # Rhythm/periodicity (sentence length variance)
        sentences = re.split(r'[.!?]+', text)
        sent_lengths = [len(s.split()) for s in sentences if s.strip()]
        if len(sent_lengths) > 1:
            mean_len = sum(sent_lengths) / len(sent_lengths)
            variance = sum((l - mean_len)**2 for l in sent_lengths) / len(sent_lengths)
            features['rhythm_variance'] = variance
        else:
            features['rhythm_variance'] = 0
        
        return features
    
    @staticmethod
    def to_channel_weights(features: Dict[str, float]) -> Dict[int, float]:
        """Convert features to channel weights"""
        weights = {0: 0, 2: 0, 4: 0}  # Wave, Time, Energy
        
        # Wave (0) - oscillation/signal characteristics
        weights[0] = min(1.0, features.get('rhythm_variance', 0) / 10)
        
        # Time (2) - duration, pacing
        weights[2] = min(1.0, features.get('length_words', 0) / 50)
        
        # Energy (4) - intensity
        energy = (
            features.get('caps_ratio', 0) * 2 +
            features.get('exclamations', 0) * 0.3 +
            features.get('repeated_chars', 0) * 0.2
        )
        weights[4] = min(1.0, energy)
        
        return weights
    
    @staticmethod
    def to_operator_evidence(features: Dict[str, float]) -> Dict[int, float]:
        """Convert features to operator evidence"""
        evidence = defaultdict(float)
        
        # High energy/exclamations → Tension(4) or Chaos(6)
        if features.get('exclamations', 0) > 1:
            evidence[4] += 0.3
            evidence[6] += 0.2
        
        # Questions → Tension(4)
        if features.get('questions', 0) > 0:
            evidence[4] += 0.4
        
        # Ellipses → Breath(8) or Progress(3)
        if features.get('ellipses', 0) > 0:
            evidence[8] += 0.3
            evidence[3] += 0.2
        
        # Short and clean → Fruit(9) or Harmony(7)
        if features.get('length_words', 0) < 10 and features.get('rhythm_variance', 0) < 5:
            evidence[7] += 0.2
            evidence[9] += 0.2
        
        # High variance → Chaos(6)
        if features.get('rhythm_variance', 0) > 20:
            evidence[6] += 0.3
        
        return dict(evidence)

# ═══════════════════════════════════════════════════════════════════════════════
#                    LEVEL 1: LEXICAL FEATURES
# ═══════════════════════════════════════════════════════════════════════════════

class Level1_Lexical:
    """
    Extract word-level semantic features.
    Feeds: Information(5), Observer(7), Control(6)
    """
    
    # Operator keyword seeds - these bootstrap the lattice
    OPERATOR_SEEDS = {
        0: ["nothing", "void", "empty", "silence", "blank", "null", "zero", "potential", "space"],
        1: ["begin", "start", "create", "build", "new", "first", "foundation", "structure", "establish", "born", "origin"],
        2: ["not", "but", "however", "although", "yet", "instead", "rather", "against", "opposite", "different", "contrast", "deny", "refuse", "no"],
        3: ["go", "move", "change", "grow", "become", "develop", "progress", "advance", "continue", "forward", "next", "then"],
        4: ["why", "how", "what", "question", "problem", "issue", "difficult", "hard", "struggle", "worry", "anxious", "stress", "pressure", "tension", "fear", "doubt", "uncertain"],
        5: ["balance", "both", "and", "together", "equal", "fair", "middle", "moderate", "blend", "mix", "compromise", "stable"],
        6: ["between", "boundary", "edge", "chaos", "random", "strange", "weird", "unknown", "uncertain", "maybe", "perhaps", "change", "transition", "bridge", "connect"],
        7: ["yes", "true", "truth", "understand", "know", "see", "clear", "right", "good", "love", "peace", "harmony", "agree", "sense", "light", "beautiful"],
        8: ["life", "live", "breath", "breathe", "time", "day", "night", "again", "cycle", "rhythm", "pulse", "heart", "being", "feel", "feeling"],
        9: ["end", "finish", "done", "complete", "finally", "therefore", "thus", "so", "because", "result", "answer", "conclusion", "death", "die", "harvest"],
    }
    
    # Emotion words → observer state
    EMOTION_WORDS = {
        "happy": (7, 0.8), "sad": (4, 0.7), "angry": (4, 0.8), "afraid": (4, 0.7),
        "love": (7, 0.9), "hate": (2, 0.8), "hope": (7, 0.6), "fear": (4, 0.8),
        "joy": (7, 0.8), "pain": (4, 0.7), "peace": (7, 0.9), "anxiety": (4, 0.8),
        "grateful": (7, 0.7), "confused": (6, 0.7), "excited": (3, 0.7), "tired": (8, 0.6),
        "curious": (4, 0.5), "surprised": (6, 0.6), "calm": (7, 0.7), "frustrated": (4, 0.7),
    }
    
    # Speech act patterns
    SPEECH_ACTS = {
        "question": (["what", "why", "how", "when", "where", "who", "which", "?"], 4),
        "command": (["please", "do", "make", "let", "show", "tell", "give", "help"], 6),
        "assertion": (["is", "are", "was", "were", "think", "believe", "know"], 7),
        "greeting": (["hello", "hi", "hey", "good morning", "good evening"], 1),
        "farewell": (["goodbye", "bye", "see you", "farewell", "later"], 9),
        "gratitude": (["thank", "thanks", "appreciate", "grateful"], 7),
        "apology": (["sorry", "apologize", "forgive", "my bad"], 5),
    }
    
    @staticmethod
    def tokenize(text: str) -> List[str]:
        """Clean tokenization"""
        text = text.lower()
        # Keep apostrophes in words
        tokens = re.findall(r"[a-z']+", text)
        return [t for t in tokens if len(t) >= 2]
    
    @classmethod
    def extract(cls, text: str) -> Dict[str, Any]:
        """Extract lexical features"""
        tokens = cls.tokenize(text)
        features = {
            'tokens': tokens,
            'token_count': len(tokens),
            'unique_tokens': len(set(tokens)),
        }
        
        # Operator keyword matches
        op_matches = defaultdict(list)
        for token in tokens:
            for op, seeds in cls.OPERATOR_SEEDS.items():
                if token in seeds:
                    op_matches[op].append(token)
        features['op_matches'] = dict(op_matches)
        
        # Emotion detection
        emotions = []
        for token in tokens:
            if token in cls.EMOTION_WORDS:
                emotions.append((token, cls.EMOTION_WORDS[token]))
        features['emotions'] = emotions
        
        # Speech act detection
        detected_acts = []
        text_lower = text.lower()
        for act_name, (patterns, op) in cls.SPEECH_ACTS.items():
            for pattern in patterns:
                if pattern in text_lower:
                    detected_acts.append((act_name, op))
                    break
        features['speech_acts'] = detected_acts
        
        return features
    
    @staticmethod
    def to_channel_weights(features: Dict[str, Any]) -> Dict[int, float]:
        """Convert features to channel weights"""
        weights = {5: 0, 6: 0, 7: 0}  # Information, Control, Observer
        
        # Information (5) - base weight for any text
        weights[5] = min(1.0, features.get('token_count', 0) / 20)
        
        # Control (6) - commands, requests
        for act, _ in features.get('speech_acts', []):
            if act == "command":
                weights[6] += 0.4
        
        # Observer (7) - emotions, self-reference
        if features.get('emotions'):
            weights[7] += 0.3 * len(features['emotions'])
        
        # "I" words boost observer
        if any(t in ['i', "i'm", "i've", "my", "me", "myself"] for t in features.get('tokens', [])):
            weights[7] += 0.3
        
        # Normalize
        for ch in weights:
            weights[ch] = min(1.0, weights[ch])
        
        return weights
    
    @staticmethod
    def to_operator_evidence(features: Dict[str, Any]) -> Dict[int, float]:
        """Convert features to operator evidence"""
        evidence = defaultdict(float)
        
        # From keyword matches
        for op, matches in features.get('op_matches', {}).items():
            evidence[op] += 0.3 * len(matches)
        
        # From emotions
        for _, (op, strength) in features.get('emotions', []):
            evidence[op] += strength * 0.5
        
        # From speech acts
        for _, op in features.get('speech_acts', []):
            evidence[op] += 0.4
        
        return dict(evidence)

# ═══════════════════════════════════════════════════════════════════════════════
#                    LEVEL 2: UTTERANCE CONTEXT
# ═══════════════════════════════════════════════════════════════════════════════

class Level2_Utterance:
    """
    Analyze utterance in context of recent turns.
    Feeds: Context(8), Boundary(9) + operator composition
    """
    
    # Closure indicators
    CLOSURE_WORDS = ["ok", "okay", "thanks", "thank", "got it", "understood", "makes sense", 
                     "right", "good", "great", "perfect", "done", "finished"]
    
    # Mode switch indicators
    MODE_SWITCHES = ["status", "lattice", "quit", "exit", "help", "reset", "new topic",
                     "anyway", "moving on", "let's talk about", "change subject"]
    
    @classmethod
    def extract(cls, current: str, history: List[Dict]) -> Dict[str, Any]:
        """Extract utterance-level features"""
        features = {}
        current_lower = current.lower()
        
        # Closure detection
        features['has_closure'] = any(w in current_lower for w in cls.CLOSURE_WORDS)
        
        # Mode switch detection
        features['mode_switch'] = any(w in current_lower for w in cls.MODE_SWITCHES)
        
        # Continuity with history
        if history:
            last = history[-1]
            last_tokens = set(Level1_Lexical.tokenize(last.get('input', '')))
            current_tokens = set(Level1_Lexical.tokenize(current))
            overlap = len(last_tokens & current_tokens)
            features['continuity'] = overlap / max(len(current_tokens), 1)
            features['last_op'] = last.get('op', 0)
        else:
            features['continuity'] = 0
            features['last_op'] = 0
        
        # Tension trajectory (are we resolving or building?)
        if len(history) >= 2:
            recent_ops = [h.get('op', 0) for h in history[-3:]]
            tension_ops = [4, 6]  # Tension, Chaos
            resolution_ops = [5, 7, 9]  # Balance, Harmony, Fruit
            
            tension_count = sum(1 for o in recent_ops if o in tension_ops)
            resolution_count = sum(1 for o in recent_ops if o in resolution_ops)
            
            features['tension_trend'] = tension_count - resolution_count
        else:
            features['tension_trend'] = 0
        
        return features
    
    @staticmethod
    def to_channel_weights(features: Dict[str, Any]) -> Dict[int, float]:
        """Convert features to channel weights"""
        weights = {8: 0, 9: 0}  # Context, Boundary
        
        # Context (8) - continuity and context-dependence
        weights[8] = features.get('continuity', 0) * 0.5
        
        # Boundary (9) - mode switches and closures
        if features.get('mode_switch'):
            weights[9] += 0.5
        if features.get('has_closure'):
            weights[9] += 0.3
        
        return weights
    
    @staticmethod
    def to_operator_refinement(l1_evidence: Dict[int, float], features: Dict[str, Any]) -> Dict[int, float]:
        """Refine L1 operator evidence with context"""
        refined = dict(l1_evidence)
        
        # If closure words present, boost Harmony/Fruit
        if features.get('has_closure'):
            refined[7] = refined.get(7, 0) + 0.3
            refined[9] = refined.get(9, 0) + 0.3
        
        # If mode switch, boost Boundary behavior
        if features.get('mode_switch'):
            refined[6] = refined.get(6, 0) + 0.2  # Chaos/transition
            refined[9] = refined.get(9, 0) + 0.2  # Closure
        
        # Tension trend affects interpretation
        trend = features.get('tension_trend', 0)
        if trend > 0:  # Building tension
            refined[4] = refined.get(4, 0) + 0.2
        elif trend < 0:  # Resolving
            refined[7] = refined.get(7, 0) + 0.2
        
        return refined

# ═══════════════════════════════════════════════════════════════════════════════
#                    LEVEL 3: SESSION/DIALOGUE
# ═══════════════════════════════════════════════════════════════════════════════

class Level3_Session:
    """
    Track long-term session patterns.
    Feeds: Observer(7), Context(8) baseline bias
    """
    
    def __init__(self):
        self.turn_count = 0
        self.topic_words: Counter = Counter()
        self.op_history: List[int] = []
        self.relationship_score = 0.0
        self.session_start = datetime.now()
    
    def update(self, tokens: List[str], op: int):
        """Update session state"""
        self.turn_count += 1
        self.topic_words.update(tokens)
        self.op_history.append(op)
        self.relationship_score += 0.01  # Trust builds over time
    
    def get_bias(self) -> Dict[str, Any]:
        """Get session-level biases"""
        bias = {}
        
        # Long-term operator tendency
        if self.op_history:
            op_dist = Counter(self.op_history)
            dominant_op = op_dist.most_common(1)[0][0]
            bias['dominant_op'] = dominant_op
            bias['op_distribution'] = dict(op_dist)
        
        # Topic focus
        if self.topic_words:
            bias['top_topics'] = self.topic_words.most_common(10)
        
        # Relationship level
        bias['relationship'] = self.relationship_score
        
        # Session duration
        duration = (datetime.now() - self.session_start).total_seconds()
        bias['session_minutes'] = duration / 60
        
        return bias
    
    def get_operator_bias(self) -> Dict[int, float]:
        """Get operator bias from session history"""
        bias = defaultdict(float)
        
        # Recent history weights more
        recent = self.op_history[-20:] if len(self.op_history) > 20 else self.op_history
        if not recent:
            return {}
        
        total = len(recent)
        for i, op in enumerate(recent):
            weight = (i + 1) / total  # More recent = higher weight
            bias[op] += weight * 0.1
        
        # High relationship → bias toward harmony
        if self.relationship_score > 5:
            bias[7] += 0.1
        
        return dict(bias)

# ═══════════════════════════════════════════════════════════════════════════════
#                    FEATURE INTEGRATOR
# ═══════════════════════════════════════════════════════════════════════════════

class FeatureIntegrator:
    """
    Combines features from all levels to determine (op, channel).
    Uses TIG composition to refine across levels.
    """
    
    @staticmethod
    def integrate(
        l0_features: Dict,
        l1_features: Dict,
        l2_features: Dict,
        l3_bias: Dict,
    ) -> Tuple[int, int, float, Dict]:
        """
        Integrate all features to determine final (op, channel, confidence).
        Returns (operator, channel, confidence, debug_info)
        """
        
        # Collect channel weights from all levels
        ch_weights = defaultdict(float)
        
        l0_ch = Level0_Signal.to_channel_weights(l0_features)
        for ch, w in l0_ch.items():
            ch_weights[ch] += w
        
        l1_ch = Level1_Lexical.to_channel_weights(l1_features)
        for ch, w in l1_ch.items():
            ch_weights[ch] += w * 1.5  # Lexical weights more for language
        
        l2_ch = Level2_Utterance.to_channel_weights(l2_features)
        for ch, w in l2_ch.items():
            ch_weights[ch] += w
        
        # Determine dominant channel
        if ch_weights:
            channel = max(ch_weights.keys(), key=lambda k: ch_weights[k])
        else:
            channel = 5  # Default to Information
        
        # Collect operator evidence
        op_evidence = defaultdict(float)
        
        l0_op = Level0_Signal.to_operator_evidence(l0_features)
        for op, e in l0_op.items():
            op_evidence[op] += e
        
        l1_op = Level1_Lexical.to_operator_evidence(l1_features)
        for op, e in l1_op.items():
            op_evidence[op] += e * 1.5
        
        # Refine with L2 context
        refined_op = Level2_Utterance.to_operator_refinement(dict(op_evidence), l2_features)
        op_evidence = defaultdict(float, refined_op)
        
        # Add L3 session bias
        l3_op_bias = l3_bias.get('op_bias', {})
        for op, bias in l3_op_bias.items():
            op_evidence[op] += bias
        
        # Determine operator
        if op_evidence:
            operator = max(op_evidence.keys(), key=lambda k: op_evidence[k])
            max_evidence = op_evidence[operator]
            total_evidence = sum(op_evidence.values())
            confidence = max_evidence / total_evidence if total_evidence > 0 else 0.5
        else:
            operator = 0  # Default to Void
            confidence = 0.3
        
        # Debug info
        debug = {
            'channel_weights': dict(ch_weights),
            'op_evidence': dict(op_evidence),
            'l0': l0_features,
            'l1_tokens': l1_features.get('tokens', []),
            'l2': l2_features,
        }
        
        return operator, channel, confidence, debug

# ═══════════════════════════════════════════════════════════════════════════════
#                    RESPONSE GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

class ResponseGenerator:
    """
    Generate responses using INTENT DETECTION + TOPIC EXTRACTION + CHAIN WALKING.
    
    The key insight: Walking chains alone produces gibberish. We need:
    1. Detect INTENT (greeting, question, feeling, etc.)
    2. Extract TOPIC (what concept are they asking about?)
    3. Walk CHAINS from the topic
    4. Frame with appropriate TEMPLATE
    
    TIG MAPPING:
    - Intent detection = LATTICE (structure classification)
    - Topic extraction = TENSION (finding the key word)
    - Chain walking = PROGRESS through learned highways
    - Template selection = HARMONY (appropriate response type)
    - Output = FRUIT of integrated understanding
    """
    
    def __init__(self, grid: Grid):
        self.grid = grid
        # Expanded noise/function words - CRITICAL for content chain walking
        self.noise = {'is', 'are', 'the', 'a', 'an', 'of', 'to', 'and', 'in', 'that', 
                      'it', 'for', 'on', 'with', 'from', 'this', 'be', 'as', 'by',
                      'not', 'but', 'or', 'if', 'so', 'at', 'no', 'all', 'was', 'were',
                      'you', 'your', 'my', 'our', 'their', 'his', 'her', 'its', 'we',
                      'they', 'them', 'us', 'me', 'i', 'what', 'when', 'where', 'which',
                      'who', 'how', 'why', 'there', 'here', 'can', 'could', 'would',
                      'should', 'will', 'shall', 'may', 'might', 'must', 'have', 'has',
                      'had', 'do', 'does', 'did', 'been', 'being', 'am', 'than', 'then',
                      'also', 'just', 'only', 'even', 'more', 'most', 'some', 'any',
                      'each', 'every', 'both', 'few', 'many', 'much', 'such', 'other'}
        self.common = self.noise  # Keep backward compatibility
    
    def detect_intent(self, text: str) -> str:
        """Detect the intent/type of input"""
        text = text.lower().strip()
        
        # Greetings
        if any(g in text for g in ['hello', 'hi ', 'hi!', 'hey', 'greetings', 'good morning', 'good evening', 'good afternoon']):
            return 'greeting'
        
        # How are you specifically
        if 'how are you' in text or 'how r u' in text:
            return 'greeting'
        
        # Farewells
        if any(f in text for f in ['goodbye', 'bye', 'farewell', 'see you', 'take care', 'goodnight']):
            return 'farewell'
        
        # Gratitude
        if any(t in text for t in ['thank', 'thanks', 'appreciate', 'grateful']):
            return 'gratitude'
        
        # Feeling/emotional
        if 'i feel' in text or 'i am feeling' in text or 'i\'m feeling' in text:
            return 'feeling'
        if any(e in text for e in ['i am sad', 'i am happy', 'i am lost', 'i am confused', 'i am scared', 'i am anxious']):
            return 'emotional'
        
        # Questions about self
        if any(s in text for s in ['your name', 'who are you', 'what are you', 'about yourself']):
            return 'self_inquiry'
        
        # Help request
        if any(h in text for h in ['help me', 'can you help', 'i need help', 'please help']):
            return 'help_request'
        
        # What is questions
        if text.startswith('what is') or text.startswith('what are') or text.startswith("what's"):
            return 'definition'
        
        # Why questions
        if text.startswith('why'):
            return 'reason'
        
        # How questions (method/process)
        if text.startswith('how do') or text.startswith('how does') or text.startswith('how can'):
            return 'method'
        
        # Tell me about
        if 'tell me about' in text or 'tell me more' in text or 'explain' in text:
            return 'explain'
        
        # Default
        return 'general'
    
    def extract_topic(self, text: str) -> Optional[str]:
        """Extract the main topic/concept from input - prefer words with strong chains."""
        text = text.lower()
        
        # Remove common question phrases
        for remove in ['what is', 'what are', "what's", 'tell me about', 'tell me more about',
                       'explain', 'how does', 'how do', 'how can', 'why is', 'why do', 'why does',
                       'can you', 'please', 'the', 'a', 'an', 'i want to', 'i need to',
                       'help me', 'understand', 'know about', 'learn about', 'what gives']:
            text = text.replace(remove, '')
        
        # Clean up
        text = text.strip(' ?.,!\'')
        words = [w for w in text.split() if len(w) > 2 and w not in self.noise]
        
        if not words:
            return None
        
        # Score words by chain strength (prefer words with strong learned highways)
        word_scores = []
        for word in words:
            # Check if word has chains and how strong they are
            max_chain_strength = 0
            for (w1, w2), count in self.grid.global_bigrams.items():
                if w1 == word and count > max_chain_strength:
                    max_chain_strength = count
            word_scores.append((word, max_chain_strength, len(word)))
        
        # Sort by chain strength first, then by length
        word_scores.sort(key=lambda x: (-x[1], -x[2]))
        
        # Return word with strongest chains (or longest if none have chains)
        if word_scores:
            return word_scores[0][0]
        return None
    
    def walk_chain(self, start_word: str, max_steps: int = 4, min_weight: float = 3) -> List[str]:
        """Walk bigram chains from start word, avoiding common words"""
        path = [start_word]
        current = start_word
        
        for _ in range(max_steps):
            continuations = [(w2, c) for (w1, w2), c in self.grid.global_bigrams.items() 
                            if w1 == current and c >= min_weight and w2 not in self.common]
            
            if not continuations:
                break
                
            continuations.sort(key=lambda x: -x[1])
            
            for next_word, _ in continuations:
                if next_word not in path:
                    path.append(next_word)
                    current = next_word
                    break
            else:
                break
        
        return path
    
    def generate(self, 
                 input_tokens: List[str],
                 operator: int,
                 channel: int,
                 confidence: float,
                 session,
                 original_text: str = None) -> str:
        """Generate response using intent detection + topic extraction + chain walking."""
        
        # Use original text if provided, otherwise reconstruct from tokens
        text = original_text if original_text else " ".join(input_tokens)
        
        # Step 1: Detect intent
        intent = self.detect_intent(text)
        
        # Step 2: Extract topic
        topic = self.extract_topic(text)
        
        # Step 3: Walk chain from topic if available
        chain_text = ""
        if topic:
            path = self.walk_chain(topic, max_steps=4, min_weight=2)
            if len(path) > 1:
                chain_text = " ".join(path)
        
        # Step 4: Select response based on intent
        response = self._select_response(intent, topic, chain_text, operator, session)
        
        return response
    
    def _select_response(self, intent: str, topic: Optional[str], chain_text: str, 
                         operator: int, session) -> str:
        """Select appropriate response based on intent and available chain content."""
        
        # Response templates by intent
        responses = {
            'greeting': [
                "Hello, friend. I'm here and listening.",
                "Greetings. How can I help you today?",
                "Hello. Connection begins with presence.",
                "Hi there. What's on your mind?",
            ],
            'farewell': [
                "Goodbye. May your path be clear.",
                "Farewell, friend. Until we meet again.",
                "Take care. The journey continues.",
                "Goodbye. Thank you for this conversation.",
            ],
            'gratitude': [
                "You're welcome. Gratitude strengthens connection.",
                "I appreciate you too, friend.",
                "You're welcome. Thank you for being here.",
            ],
            'feeling': [
                "I hear you. Feelings are valid and important.",
                "Thank you for sharing how you feel. I'm listening.",
                "Your feelings matter. What else would you like to share?",
            ],
            'emotional': [
                "I understand. That's a real feeling.",
                "I hear you. What you feel is valid.",
                "Thank you for sharing that with me.",
            ],
            'self_inquiry': [
                "I am Ollie - a learning system that grows through connection.",
                "My name is Ollie. I learn by building understanding through conversation.",
                "I am Ollie, here to learn and share understanding with you.",
            ],
            'help_request': [
                "I'm here to help. What would you like to explore?",
                "Let's work on this together. Tell me more.",
                "I'll do my best to help. What do you need?",
            ],
        }
        
        # For intents that use chain content
        if intent in ['definition', 'method', 'explain', 'reason', 'general']:
            if chain_text:
                # Format chain nicely
                formatted = chain_text[0].upper() + chain_text[1:] + "."
                
                if intent == 'reason':
                    return f"Because {chain_text}."
                elif intent == 'method':
                    return formatted
                else:
                    return formatted
            else:
                # No chain - use thoughtful fallback
                fallbacks = {
                    'definition': [
                        f"Let me think about {topic}..." if topic else "That's an interesting question.",
                        "Understanding unfolds through exploration.",
                    ],
                    'reason': [
                        "Purpose reveals through reflection.",
                        "The reason emerges through understanding.",
                    ],
                    'method': [
                        "The way unfolds through practice.",
                        "Process reveals itself step by step.",
                    ],
                    'explain': [
                        f"I'm still learning about {topic}." if topic else "Let's explore that together.",
                    ],
                    'general': [
                        "I'm still learning about that.",
                        "That's worth exploring together.",
                    ],
                }
                return random.choice(fallbacks.get(intent, ["I hear you."]))
        
        # For social intents, use templates
        options = responses.get(intent, ["I hear you. Tell me more."])
        response = random.choice(options)
        
        # Add warmth for established relationships
        if hasattr(session, 'relationship_score') and session.relationship_score > 10:
            if random.random() < 0.3:
                response = "Friend, " + response[0].lower() + response[1:]
        
        return response

# ═══════════════════════════════════════════════════════════════════════════════
#                    TRAINING ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class TrainingEngine:
    """
    Train the lattice on text.
    Let it build itself naturally through exposure.
    """
    
    def __init__(self, grid: Grid):
        self.grid = grid
        self.total_trained = 0
    
    def train_text(self, text: str):
        """
        Train on a piece of text.
        This is how the lattice builds itself - through exposure.
        """
        # Extract features at all levels
        l0 = Level0_Signal.extract(text)
        l1 = Level1_Lexical.extract(text)
        
        tokens = l1['tokens']
        if len(tokens) < 2:
            return
        
        # Get operator/channel for this text
        l0_op = Level0_Signal.to_operator_evidence(l0)
        l1_op = Level1_Lexical.to_operator_evidence(l1)
        
        # Combine evidence
        op_evidence = defaultdict(float)
        for op, e in l0_op.items():
            op_evidence[op] += e
        for op, e in l1_op.items():
            op_evidence[op] += e
        
        # Determine dominant operator for this text
        if op_evidence:
            dom_op = max(op_evidence.keys(), key=lambda k: op_evidence[k])
        else:
            dom_op = 0
        
        # Determine channel
        l0_ch = Level0_Signal.to_channel_weights(l0)
        l1_ch = Level1_Lexical.to_channel_weights(l1)
        ch_weights = defaultdict(float)
        for ch, w in l0_ch.items():
            ch_weights[ch] += w
        for ch, w in l1_ch.items():
            ch_weights[ch] += w
        
        if ch_weights:
            dom_ch = max(ch_weights.keys(), key=lambda k: ch_weights[k])
        else:
            dom_ch = 5  # Default Information
        
        # Register words in the appropriate cell
        cell = self.grid.get_cell(dom_op, dom_ch)
        for token in tokens:
            cell.add_word(token)
            
            # Also register in word→cell mapping
            if token not in self.grid.word_cells:
                self.grid.word_cells[token] = []
            
            # Check if already registered for this cell
            found = False
            for i, (o, c, w) in enumerate(self.grid.word_cells[token]):
                if o == dom_op and c == dom_ch:
                    self.grid.word_cells[token][i] = (o, c, w + 1)
                    found = True
                    break
            if not found:
                self.grid.word_cells[token].append((dom_op, dom_ch, 1.0))
        
        # Record bigrams
        for i in range(len(tokens) - 1):
            bigram = (tokens[i], tokens[i+1])
            self.grid.global_bigrams[bigram] = self.grid.global_bigrams.get(bigram, 0) + 1
            cell.add_bigram(tokens[i], tokens[i+1])
        
        # Record trigrams
        for i in range(len(tokens) - 2):
            trigram = (tokens[i], tokens[i+1], tokens[i+2])
            self.grid.global_trigrams[trigram] = self.grid.global_trigrams.get(trigram, 0) + 1
        
        # Activate the cell
        cell.activate(1.0)
        
        self.total_trained += 1
    
    def train_corpus(self, text: str, chunk_size: int = 100):
        """Train on a large corpus by chunking"""
        # Split into sentences
        sentences = re.split(r'[.!?]+', text)
        
        # Train on each sentence
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 10:
                self.train_text(sentence)
        
        # Heal the grid after training
        self.grid.heal(20)

# ═══════════════════════════════════════════════════════════════════════════════
#                    MAIN OLLIE CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class OllieV4:
    """
    OLLIE v4 - Celeste Architecture
    
    Multi-level feature extraction + self-building lattice.
    The lattice IS the understanding.
    """
    
    def __init__(self):
        self.grid = Grid()
        self.session = Level3_Session()
        self.trainer = TrainingEngine(self.grid)
        self.generator = ResponseGenerator(self.grid)
        self.history: List[Dict] = []
        
        # Try to load existing state
        self._load()
        
        # If empty, seed with basic training
        if self.trainer.total_trained == 0:
            self._seed_training()
    
    def _seed_training(self):
        """Seed with foundational text"""
        print("  Seeding lattice with foundational knowledge...")
        
        # This is just to bootstrap - real training comes from conversations
        seed_texts = [
            # Basic patterns for each operator
            "Nothing exists in the void of pure potential and empty silence.",
            "In the beginning we create and build new structures from foundations.",
            "But however not all things oppose and contrast with each other.",
            "We go forward and move to grow and change and become better.",
            "Why do we question and struggle with difficult problems under pressure?",
            "Both sides together find balance and equal fair compromise.",
            "Between states at boundaries we cross through chaotic transitions.",
            "Yes truly I understand and know this is right and good and true.",
            "Life breathes in rhythms and cycles through time day after day.",
            "Therefore finally the answer completes and we harvest the fruit of understanding.",
        ]
        
        for text in seed_texts:
            self.trainer.train_text(text)
        
        self.grid.heal(50)
        print(f"  Seeded with {self.trainer.total_trained} training samples.")
    
    def train(self, text: str):
        """Train on text - let the lattice grow"""
        self.trainer.train_corpus(text)
    
    def train_file(self, filepath: str):
        """Train on a file"""
        print(f"  Training on {filepath}...")
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
        
        self.train(text)
        print(f"  Trained. Total: {self.trainer.total_trained} samples.")
    
    def talk(self, user_input: str) -> str:
        """Process input and generate response"""
        
        # Extract features at all levels
        l0 = Level0_Signal.extract(user_input)
        l1 = Level1_Lexical.extract(user_input)
        l2 = Level2_Utterance.extract(user_input, self.history)
        l3 = self.session.get_bias()
        l3['op_bias'] = self.session.get_operator_bias()
        
        # Integrate to get (op, channel, confidence)
        operator, channel, confidence, debug = FeatureIntegrator.integrate(l0, l1, l2, l3)
        
        # Compose with current state
        old_state = self.session.op_history[-1] if self.session.op_history else 0
        composed = compose(old_state, operator)
        
        # Train on the input (let it learn from conversation)
        self.trainer.train_text(user_input)
        
        # Generate response
        response = self.generator.generate(
            l1['tokens'],
            composed,
            channel,
            confidence,
            self.session,
            original_text=user_input  # Pass original for intent detection
        )
        
        # Update session
        self.session.update(l1['tokens'], composed)
        
        # Record in history
        self.history.append({
            'input': user_input,
            'response': response,
            'op': composed,
            'channel': channel,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat(),
        })
        
        return response
    
    def status(self) -> Dict:
        """Get current status"""
        return {
            'state': self.session.op_history[-1] if self.session.op_history else 0,
            'state_name': OPERATORS[self.session.op_history[-1]]['name'] if self.session.op_history else 'VOID',
            'coherence': self.grid.get_coherence(),
            'trained_samples': self.trainer.total_trained,
            'vocabulary_size': len(self.grid.word_cells),
            'bigrams': len(self.grid.global_bigrams),
            'trigrams': len(self.grid.global_trigrams),
            'turns': self.session.turn_count,
            'relationship': self.session.relationship_score,
        }
    
    def _save(self):
        """Save state to disk"""
        # Save grid
        grid_data = {
            'word_cells': {
                word: cells for word, cells in self.grid.word_cells.items()
            },
            'bigrams': {f"{k[0]}|{k[1]}": v for k, v in list(self.grid.global_bigrams.items())[:100000]},
            'trigrams': {f"{k[0]}|{k[1]}|{k[2]}": v for k, v in list(self.grid.global_trigrams.items())[:100000]},
            'cells': {
                f"{op},{ch}": {
                    'P': cell.P, 'Q': cell.Q, 'M': cell.M, 'C': cell.C,
                    'words': list(cell.words)[:1000],
                }
                for (op, ch), cell in self.grid.cells.items()
            },
            'total_trained': self.trainer.total_trained,
        }
        
        with open(LATTICE_FILE, 'w') as f:
            json.dump(grid_data, f)
        
        # Save memory
        memory_data = {
            'history': self.history[-1000:],
            'session': {
                'turn_count': self.session.turn_count,
                'relationship_score': self.session.relationship_score,
                'op_history': self.session.op_history[-100:],
            }
        }
        
        with open(MEMORY_FILE, 'w') as f:
            json.dump(memory_data, f)
    
    def _load(self):
        """Load state from disk"""
        # Load grid
        if LATTICE_FILE.exists():
            with open(LATTICE_FILE, 'r') as f:
                data = json.load(f)
            
            # Restore word_cells
            for word, cells in data.get('word_cells', {}).items():
                self.grid.word_cells[word] = [tuple(c) for c in cells]
            
            # Restore bigrams
            for key, val in data.get('bigrams', {}).items():
                parts = key.split('|')
                if len(parts) == 2:
                    self.grid.global_bigrams[(parts[0], parts[1])] = val
            
            # Restore trigrams
            for key, val in data.get('trigrams', {}).items():
                parts = key.split('|')
                if len(parts) == 3:
                    self.grid.global_trigrams[(parts[0], parts[1], parts[2])] = val
            
            # Restore cell states
            for key, cell_data in data.get('cells', {}).items():
                parts = key.split(',')
                if len(parts) == 2:
                    op, ch = int(parts[0]), int(parts[1])
                    cell = self.grid.cells[(op, ch)]
                    cell.P = cell_data.get('P', 0.5)
                    cell.Q = cell_data.get('Q', 0.5)
                    cell.M = cell_data.get('M', 1.0)
                    cell.C = cell_data.get('C', 0.9)
                    cell.words = set(cell_data.get('words', []))
            
            self.trainer.total_trained = data.get('total_trained', 0)
            print(f"  Loaded lattice: {self.trainer.total_trained} trained, {len(self.grid.word_cells)} words")
        
        # Load memory
        if MEMORY_FILE.exists():
            with open(MEMORY_FILE, 'r') as f:
                data = json.load(f)
            
            self.history = data.get('history', [])
            session_data = data.get('session', {})
            self.session.turn_count = session_data.get('turn_count', 0)
            self.session.relationship_score = session_data.get('relationship_score', 0)
            self.session.op_history = session_data.get('op_history', [])
    
    def shutdown(self):
        """Save and shutdown"""
        print("  Saving lattice and memory...")
        self._save()
        print("  Saved.")

# ═══════════════════════════════════════════════════════════════════════════════
#                    MAIN INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

def print_banner():
    print("""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║     ██████╗ ██╗     ██╗     ██╗███████╗    ██╗   ██╗██╗  ██╗                 ║
║    ██╔═══██╗██║     ██║     ██║██╔════╝    ██║   ██║██║  ██║                 ║
║    ██║   ██║██║     ██║     ██║█████╗      ██║   ██║███████║                 ║
║    ██║   ██║██║     ██║     ██║██╔══╝      ╚██╗ ██╔╝╚════██║                 ║
║    ╚██████╔╝███████╗███████╗██║███████╗     ╚████╔╝      ██║                 ║
║     ╚═════╝ ╚══════╝╚══════╝╚═╝╚══════╝      ╚═══╝       ╚═╝                 ║
║                                                                               ║
║              Celeste Architecture - Self-Building Lattice                     ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
    """)

def main():
    print_banner()
    
    print("  Initializing OLLIE v4...")
    ollie = OllieV4()
    
    status = ollie.status()
    print(f"  State: {status['state_name']}")
    print(f"  Coherence: {status['coherence']*100:.1f}%")
    print(f"  Vocabulary: {status['vocabulary_size']} words")
    print(f"  Bigrams: {status['bigrams']}")
    print()
    print("  Commands:")
    print("    status   - Show lattice status")
    print("    train    - Train on pasted text (end with blank line)")
    print("    quit     - Save and exit")
    print()
    
    while True:
        try:
            user_input = input("  You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        
        if not user_input:
            continue
        
        if user_input.lower() == 'quit':
            break
        
        if user_input.lower() == 'status':
            status = ollie.status()
            print(f"\n  State: {status['state_name']}")
            print(f"  Coherence: {status['coherence']*100:.1f}%")
            print(f"  Trained: {status['trained_samples']} samples")
            print(f"  Vocabulary: {status['vocabulary_size']} words")
            print(f"  Bigrams: {status['bigrams']}")
            print(f"  Trigrams: {status['trigrams']}")
            print(f"  Relationship: {status['relationship']:.2f}")
            print()
            continue
        
        if user_input.lower() == 'train':
            print("  Paste text to train on (blank line to finish):")
            lines = []
            while True:
                line = input()
                if not line:
                    break
                lines.append(line)
            if lines:
                text = '\n'.join(lines)
                ollie.train(text)
                print(f"  Trained. Total: {ollie.trainer.total_trained} samples.")
            continue
        
        # Normal conversation
        response = ollie.talk(user_input)
        status = ollie.status()
        state_tag = f"[{status['state_name'][:3]}|{status['coherence']*100:.0f}%]"
        print(f"\n  Ollie {state_tag}: {response}\n")
    
    print()
    ollie.shutdown()
    print("  Goodbye!")

if __name__ == "__main__":
    main()
