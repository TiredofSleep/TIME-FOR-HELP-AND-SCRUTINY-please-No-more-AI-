# -*- coding: utf-8 -*-
"""
CRYSTALSS — Crystal Security System
====================================
Real device protection. No mythology. Just engineering.

For: Dell Aurora R16 (Windows)
By: Brayden + Claude + Celeste (grounded version)

Features:
- Boot baseline capture
- Continuous anomaly detection
- Behavioral monitoring
- Gate logic (block when compromised)
- Rate limiting
- Full audit logging
- Alert system

Run: python crystalss.py
"""

import os
import sys
import time
import json
import hashlib
import socket
import platform
import subprocess
import ctypes
from pathlib import Path
from datetime import datetime
from collections import Counter, deque
from threading import Thread, Lock

# ============================================================
# CONFIGURATION
# ============================================================

CRYSTALSS_HOME = Path.home() / "CRYSTALSS"
CRYSTALSS_LOGS = CRYSTALSS_HOME / "logs"
CRYSTALSS_STATE = CRYSTALSS_HOME / "state"
CRYSTALSS_BASELINE = CRYSTALSS_HOME / "baseline"

for d in [CRYSTALSS_HOME, CRYSTALSS_LOGS, CRYSTALSS_STATE, CRYSTALSS_BASELINE]:
    d.mkdir(exist_ok=True)

# Thresholds
COHERENCE_THRESHOLD = 0.7    # Below this = gate closed
ALERT_THRESHOLD = 0.5        # Below this = alert
LOCKDOWN_THRESHOLD = 0.2     # Below this = lockdown
RATE_LIMIT_WINDOW = 60       # seconds
RATE_LIMIT_MAX = 100         # max events per window

# ============================================================
# LOGGING
# ============================================================

log_lock = Lock()

def log(category, message, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] [{category}] {message}"
    
    with log_lock:
        print(line)
        try:
            log_file = CRYSTALSS_LOGS / f"{datetime.now().strftime('%Y%m%d')}.log"
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except:
            pass

def alert(message):
    log("ALERT", message, "CRITICAL")
    # Could add: email, SMS, desktop notification, webhook
    try:
        if sys.platform == 'win32':
            ctypes.windll.user32.MessageBoxW(0, message, "CRYSTALSS ALERT", 0x30)
    except:
        pass

# ============================================================
# SYSTEM INFO COLLECTION
# ============================================================

def get_system_info():
    """Collect current system state."""
    info = {
        'timestamp': datetime.now().isoformat(),
        'hostname': socket.gethostname(),
        'platform': platform.platform(),
        'cpu_count': os.cpu_count(),
    }
    return info

def get_process_list():
    """Get running processes."""
    processes = []
    try:
        if sys.platform == 'win32':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            
            result = subprocess.run(
                ['tasklist', '/FO', 'CSV', '/NH'],
                capture_output=True, text=True, timeout=10,
                startupinfo=si
            )
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.replace('"', '').split(',')
                    if len(parts) >= 2:
                        processes.append({
                            'name': parts[0],
                            'pid': parts[1] if len(parts) > 1 else '',
                            'mem': parts[4] if len(parts) > 4 else ''
                        })
    except Exception as e:
        log("PROCESS", f"Error getting process list: {e}", "ERROR")
    
    return processes

def get_network_connections():
    """Get active network connections."""
    connections = []
    try:
        if sys.platform == 'win32':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            
            result = subprocess.run(
                ['netstat', '-an'],
                capture_output=True, text=True, timeout=10,
                startupinfo=si
            )
            for line in result.stdout.strip().split('\n')[4:]:
                parts = line.split()
                if len(parts) >= 4:
                    connections.append({
                        'proto': parts[0],
                        'local': parts[1],
                        'remote': parts[2],
                        'state': parts[3] if len(parts) > 3 else ''
                    })
    except Exception as e:
        log("NETWORK", f"Error getting connections: {e}", "ERROR")
    
    return connections

def get_cpu_usage():
    """Get CPU usage percentage."""
    try:
        if sys.platform == 'win32':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            
            result = subprocess.run(
                ['wmic', 'cpu', 'get', 'loadpercentage'],
                capture_output=True, text=True, timeout=5,
                startupinfo=si
            )
            for line in result.stdout.split('\n'):
                line = line.strip()
                if line.isdigit():
                    return int(line)
    except:
        pass
    return 0

def get_memory_usage():
    """Get memory usage percentage."""
    try:
        if sys.platform == 'win32':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            
            result = subprocess.run(
                ['wmic', 'OS', 'get', 'FreePhysicalMemory,TotalVisibleMemorySize', '/Value'],
                capture_output=True, text=True, timeout=5,
                startupinfo=si
            )
            free = total = 0
            for line in result.stdout.split('\n'):
                if 'FreePhysicalMemory=' in line:
                    free = int(line.split('=')[1].strip())
                elif 'TotalVisibleMemorySize=' in line:
                    total = int(line.split('=')[1].strip())
            if total > 0:
                return int((1 - free/total) * 100)
    except:
        pass
    return 0

def get_gpu_stats():
    """Get GPU stats if available."""
    try:
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = subprocess.SW_HIDE
        
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=utilization.gpu,temperature.gpu',
             '--format=csv,noheader,nounits'],
            capture_output=True, text=True, timeout=5,
            startupinfo=si
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(',')
            return {
                'util': int(parts[0].strip()),
                'temp': int(parts[1].strip())
            }
    except:
        pass
    return None

def hash_file(filepath):
    """SHA256 hash of a file."""
    try:
        h = hashlib.sha256()
        with open(filepath, 'rb') as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()
    except:
        return None

def hash_directory(dirpath, extensions=None):
    """Hash all files in directory."""
    hashes = {}
    try:
        for root, dirs, files in os.walk(dirpath):
            for fname in files:
                if extensions and not any(fname.endswith(e) for e in extensions):
                    continue
                fpath = Path(root) / fname
                h = hash_file(fpath)
                if h:
                    hashes[str(fpath)] = h
    except:
        pass
    return hashes

# ============================================================
# BASELINE CAPTURE
# ============================================================

class Baseline:
    """Immutable system baseline captured at boot."""
    
    def __init__(self):
        self.filepath = CRYSTALSS_BASELINE / "baseline.json"
        self.data = None
        
    def capture(self):
        """Capture current system state as baseline."""
        log("BASELINE", "Capturing system baseline...")
        
        self.data = {
            'captured_at': datetime.now().isoformat(),
            'system': get_system_info(),
            'process_names': sorted(set(p['name'] for p in get_process_list())),
            'process_count': len(get_process_list()),
            'connection_count': len(get_network_connections()),
            'cpu_baseline': get_cpu_usage(),
            'mem_baseline': get_memory_usage(),
        }
        
        # Hash critical directories (example paths)
        critical_paths = [
            Path.home() / "AppData" / "Local" / "Programs",
        ]
        
        self.data['file_hashes'] = {}
        for p in critical_paths:
            if p.exists():
                self.data['file_hashes'].update(
                    hash_directory(p, extensions=['.exe', '.dll'])
                )
        
        self.save()
        log("BASELINE", f"Baseline captured: {len(self.data['process_names'])} processes, "
                        f"{self.data['connection_count']} connections")
        
    def save(self):
        """Save baseline to disk."""
        try:
            with open(self.filepath, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            log("BASELINE", f"Error saving baseline: {e}", "ERROR")
    
    def load(self):
        """Load baseline from disk."""
        try:
            if self.filepath.exists():
                with open(self.filepath) as f:
                    self.data = json.load(f)
                log("BASELINE", f"Loaded baseline from {self.data.get('captured_at', 'unknown')}")
                return True
        except Exception as e:
            log("BASELINE", f"Error loading baseline: {e}", "ERROR")
        return False
    
    def exists(self):
        return self.filepath.exists()

# ============================================================
# ANOMALY DETECTION
# ============================================================

class AnomalyDetector:
    """Detect deviations from baseline."""
    
    def __init__(self, baseline):
        self.baseline = baseline
        self.history = deque(maxlen=60)  # Last 60 readings
        self.alerts_sent = set()
        
    def check(self):
        """Check current state against baseline. Returns anomaly score 0-1."""
        if not self.baseline.data:
            return 0.0
        
        anomalies = []
        details = []
        
        # 1. Process anomalies
        current_procs = set(p['name'] for p in get_process_list())
        baseline_procs = set(self.baseline.data.get('process_names', []))
        
        new_procs = current_procs - baseline_procs
        if new_procs:
            score = min(len(new_procs) / 10, 1.0)  # Max out at 10 new processes
            anomalies.append(score * 0.3)  # Weight: 30%
            if score > 0.5:
                details.append(f"New processes: {list(new_procs)[:5]}")
        
        # 2. Connection anomalies
        current_conns = len(get_network_connections())
        baseline_conns = self.baseline.data.get('connection_count', 0)
        
        if baseline_conns > 0:
            conn_ratio = abs(current_conns - baseline_conns) / max(baseline_conns, 1)
            if conn_ratio > 0.5:
                anomalies.append(min(conn_ratio, 1.0) * 0.2)  # Weight: 20%
                details.append(f"Connection count changed: {baseline_conns} -> {current_conns}")
        
        # 3. Resource anomalies
        cpu = get_cpu_usage()
        mem = get_memory_usage()
        
        cpu_baseline = self.baseline.data.get('cpu_baseline', 50)
        mem_baseline = self.baseline.data.get('mem_baseline', 50)
        
        # High sustained CPU is suspicious
        if cpu > 90:
            anomalies.append(0.3)
            details.append(f"CPU critical: {cpu}%")
        elif cpu > 80:
            anomalies.append(0.1)
        
        # Memory spike
        if mem > 95:
            anomalies.append(0.2)
            details.append(f"Memory critical: {mem}%")
        
        # 4. GPU anomalies (if available)
        gpu = get_gpu_stats()
        if gpu:
            if gpu['temp'] > 85:
                anomalies.append(0.2)
                details.append(f"GPU overheating: {gpu['temp']}C")
        
        # Calculate total anomaly score (0 = normal, 1 = fully anomalous)
        total_anomaly = min(sum(anomalies), 1.0)
        
        # Store in history
        self.history.append({
            'timestamp': time.time(),
            'score': total_anomaly,
            'cpu': cpu,
            'mem': mem,
            'details': details
        })
        
        return total_anomaly, details

# ============================================================
# RATE LIMITER
# ============================================================

class RateLimiter:
    """Prevent rapid suspicious operations."""
    
    def __init__(self, window=60, max_events=100):
        self.window = window
        self.max_events = max_events
        self.events = deque()
        self.lock = Lock()
    
    def check(self, event_type="default"):
        """Check if rate limit exceeded. Returns True if allowed."""
        now = time.time()
        
        with self.lock:
            # Remove old events
            while self.events and self.events[0][0] < now - self.window:
                self.events.popleft()
            
            # Check limit
            if len(self.events) >= self.max_events:
                return False
            
            # Add event
            self.events.append((now, event_type))
            return True
    
    def get_count(self):
        """Get current event count."""
        now = time.time()
        with self.lock:
            while self.events and self.events[0][0] < now - self.window:
                self.events.popleft()
            return len(self.events)

# ============================================================
# GATE
# ============================================================

class Gate:
    """Security gate - blocks actions when system is compromised."""
    
    def __init__(self):
        self.is_open = True
        self.coherence = 1.0
        self.status = "NORMAL"
        self.lock = Lock()
    
    def update(self, coherence):
        """Update gate state based on coherence."""
        with self.lock:
            self.coherence = coherence
            
            if coherence >= COHERENCE_THRESHOLD:
                self.is_open = True
                self.status = "NORMAL"
            elif coherence >= ALERT_THRESHOLD:
                self.is_open = False
                self.status = "ALERT"
            elif coherence >= LOCKDOWN_THRESHOLD:
                self.is_open = False
                self.status = "DEFENSE"
            else:
                self.is_open = False
                self.status = "LOCKDOWN"
    
    def check(self, action_type="default"):
        """Check if action is permitted."""
        with self.lock:
            return self.is_open
    
    def get_status(self):
        with self.lock:
            return self.status, self.coherence, self.is_open

# ============================================================
# MAIN SECURITY DAEMON
# ============================================================

class CRYSTALSS:
    """Main security system daemon."""
    
    def __init__(self):
        self.baseline = Baseline()
        self.detector = None
        self.gate = Gate()
        self.rate_limiter = RateLimiter()
        self.running = False
        self.fire_count = 0
        self.block_count = 0
        self.alert_count = 0
        
    def initialize(self):
        """Initialize the security system."""
        log("SYSTEM", "=" * 50)
        log("SYSTEM", "CRYSTALSS - Crystal Security System")
        log("SYSTEM", "=" * 50)
        log("SYSTEM", f"Platform: {platform.platform()}")
        log("SYSTEM", f"CPU Cores: {os.cpu_count()}")
        
        gpu = get_gpu_stats()
        log("SYSTEM", f"GPU: {'Detected' if gpu else 'Not found'}")
        
        # Load or create baseline
        if self.baseline.exists():
            if self.baseline.load():
                log("SYSTEM", "Using existing baseline")
            else:
                log("SYSTEM", "Failed to load baseline, creating new one")
                self.baseline.capture()
        else:
            log("SYSTEM", "No baseline found, creating initial baseline")
            self.baseline.capture()
        
        self.detector = AnomalyDetector(self.baseline)
        
        log("SYSTEM", f"Coherence threshold: {COHERENCE_THRESHOLD}")
        log("SYSTEM", f"Alert threshold: {ALERT_THRESHOLD}")
        log("SYSTEM", f"Lockdown threshold: {LOCKDOWN_THRESHOLD}")
        log("SYSTEM", "=" * 50)
        log("SYSTEM", "Press Ctrl+C to stop")
        log("SYSTEM", "=" * 50)
        print()
        
    def tick(self):
        """One monitoring cycle."""
        # Check anomalies
        anomaly_score, details = self.detector.check()
        
        # Coherence = inverse of anomaly
        coherence = 1.0 - anomaly_score
        
        # Update gate
        old_status = self.gate.get_status()[0]
        self.gate.update(coherence)
        new_status, _, gate_open = self.gate.get_status()
        
        # Status change alerts
        if new_status != old_status:
            if new_status == "LOCKDOWN":
                alert(f"LOCKDOWN ACTIVATED - Coherence: {coherence:.2f}")
                self.alert_count += 1
            elif new_status == "DEFENSE":
                alert(f"DEFENSE MODE - Coherence: {coherence:.2f}")
                self.alert_count += 1
            elif new_status == "ALERT":
                log("GATE", f"Alert mode activated - Coherence: {coherence:.2f}", "WARNING")
                self.alert_count += 1
            elif new_status == "NORMAL":
                log("GATE", "Returned to normal operation")
        
        # Log anomaly details
        for detail in details:
            log("ANOMALY", detail, "WARNING")
        
        # Fire event (action permitted)
        if gate_open and self.rate_limiter.check("fire"):
            self.fire_count += 1
            log_line = f"FIRE #{self.fire_count}: coherence={coherence:.3f}"
        else:
            self.block_count += 1
            log_line = f"BLOCKED: coherence={coherence:.3f} status={new_status}"
        
        # Get current metrics
        cpu = get_cpu_usage()
        mem = get_memory_usage()
        gpu = get_gpu_stats()
        
        # Console display
        status_icon = {
            "NORMAL": "[OK]",
            "ALERT": "[!!]",
            "DEFENSE": "[XX]",
            "LOCKDOWN": "[##]"
        }.get(new_status, "[??]")
        
        gate_str = "OPEN" if gate_open else "SHUT"
        gpu_str = f"GPU:{gpu['util']:2d}%/{gpu['temp']}C" if gpu else "GPU:--"
        
        line = (f"\r{status_icon} S*:{coherence:.2f} | "
                f"CPU:{cpu:3d}% MEM:{mem:3d}% {gpu_str} | "
                f"{gate_str} | Fires:{self.fire_count:4d} Blocks:{self.block_count:4d}")
        print(line, end="", flush=True)
        
        # Save state
        state = {
            'timestamp': datetime.now().isoformat(),
            'coherence': coherence,
            'anomaly_score': anomaly_score,
            'status': new_status,
            'gate_open': gate_open,
            'cpu': cpu,
            'mem': mem,
            'gpu': gpu,
            'fires': self.fire_count,
            'blocks': self.block_count,
            'alerts': self.alert_count
        }
        
        try:
            with open(CRYSTALSS_STATE / "current.json", 'w') as f:
                json.dump(state, f, indent=2)
        except:
            pass
        
    def run(self):
        """Main loop."""
        self.initialize()
        self.running = True
        
        try:
            while self.running:
                self.tick()
                time.sleep(1)
                
        except KeyboardInterrupt:
            print("\n")
            log("SYSTEM", "Shutting down CRYSTALSS...")
            
        self.shutdown()
    
    def shutdown(self):
        """Clean shutdown."""
        self.running = False
        
        print()
        log("SYSTEM", "=" * 50)
        log("SYSTEM", "CRYSTALSS SESSION SUMMARY")
        log("SYSTEM", "=" * 50)
        log("SYSTEM", f"Total fires (permitted): {self.fire_count}")
        log("SYSTEM", f"Total blocks: {self.block_count}")
        log("SYSTEM", f"Total alerts: {self.alert_count}")
        log("SYSTEM", f"Logs saved to: {CRYSTALSS_LOGS}")
        log("SYSTEM", "=" * 50)

# ============================================================
# CLI
# ============================================================

def show_status():
    """Show current status."""
    state_file = CRYSTALSS_STATE / "current.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
            
            print()
            print("=" * 50)
            print("CRYSTALSS STATUS")
            print("=" * 50)
            print(f"Last update: {state.get('timestamp', 'unknown')}")
            print(f"Coherence: {state.get('coherence', 0):.3f}")
            print(f"Status: {state.get('status', 'unknown')}")
            print(f"Gate: {'OPEN' if state.get('gate_open') else 'CLOSED'}")
            print(f"CPU: {state.get('cpu', 0)}%")
            print(f"Memory: {state.get('mem', 0)}%")
            if state.get('gpu'):
                print(f"GPU: {state['gpu']['util']}% / {state['gpu']['temp']}C")
            print(f"Fires: {state.get('fires', 0)}")
            print(f"Blocks: {state.get('blocks', 0)}")
            print(f"Alerts: {state.get('alerts', 0)}")
            print("=" * 50)
        except Exception as e:
            print(f"Error reading status: {e}")
    else:
        print("CRYSTALSS not running or no state found.")

def reset_baseline():
    """Reset and recapture baseline."""
    print("Resetting baseline...")
    baseline = Baseline()
    baseline.capture()
    print("Baseline reset complete.")

def show_help():
    print("""
CRYSTALSS — Crystal Security System

Usage:
    python crystalss.py          Run security daemon
    python crystalss.py status   Show current status
    python crystalss.py reset    Reset baseline
    python crystalss.py help     Show this help

Logs: ~/CRYSTALSS/logs/
State: ~/CRYSTALSS/state/
Baseline: ~/CRYSTALSS/baseline/
""")

# ============================================================
# ENTRY
# ============================================================

if __name__ == "__main__":
    if sys.platform == 'win32':
        ctypes.windll.kernel32.SetConsoleTitleW("CRYSTALSS - Security System")
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()
        if cmd == "status":
            show_status()
        elif cmd == "reset":
            reset_baseline()
        elif cmd == "help":
            show_help()
        else:
            show_help()
    else:
        system = CRYSTALSS()
        system.run()
    
    if len(sys.argv) <= 1:
        input("\nPress Enter to close...")
