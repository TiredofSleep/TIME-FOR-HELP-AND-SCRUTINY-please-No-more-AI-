#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CRYSTALSS — Crystal Security System (Linux)
============================================
Real device protection. Integrates with TIG.

For: Lenovo ThinkPad (Linux)
By: Brayden + Claude + Celeste

Run: sudo python3 crystalss_linux.py
"""

import os
import sys
import time
import json
import hashlib
import socket
import platform
import subprocess
from pathlib import Path
from datetime import datetime
from collections import deque
from threading import Lock

# ============================================================
# PATHS
# ============================================================

CRYSTALSS_HOME = Path("/var/lib/crystalss")
CRYSTALSS_LOGS = Path("/var/log/crystalss")
CRYSTALSS_BASELINE = CRYSTALSS_HOME / "baseline"

for d in [CRYSTALSS_HOME, CRYSTALSS_LOGS, CRYSTALSS_BASELINE]:
    d.mkdir(parents=True, exist_ok=True)

# Thresholds
COHERENCE_THRESHOLD = 0.7
ALERT_THRESHOLD = 0.5
LOCKDOWN_THRESHOLD = 0.2

# ============================================================
# LOGGING
# ============================================================

def log(category, message, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] [{category}] {message}"
    print(line)
    try:
        with open(CRYSTALSS_LOGS / "crystalss.log", "a") as f:
            f.write(line + "\n")
    except:
        pass

def alert(message):
    log("ALERT", message, "CRITICAL")
    try:
        subprocess.run(['notify-send', '-u', 'critical', 'CRYSTALSS', message], timeout=5)
    except:
        pass

# ============================================================
# SYSTEM MONITORING
# ============================================================

def get_cpu():
    try:
        with open('/proc/stat') as f:
            p1 = list(map(int, f.readline().split()[1:8]))
        time.sleep(0.1)
        with open('/proc/stat') as f:
            p2 = list(map(int, f.readline().split()[1:8]))
        
        idle1, idle2 = p1[3] + p1[4], p2[3] + p2[4]
        total1, total2 = sum(p1), sum(p2)
        
        if total2 - total1 > 0:
            return int((1 - (idle2 - idle1) / (total2 - total1)) * 100)
    except:
        pass
    return 0

def get_memory():
    try:
        with open('/proc/meminfo') as f:
            lines = f.readlines()
        mem = {}
        for line in lines:
            parts = line.split()
            if parts[0] in ['MemTotal:', 'MemAvailable:']:
                mem[parts[0]] = int(parts[1])
        if 'MemTotal:' in mem and 'MemAvailable:' in mem:
            return int((1 - mem['MemAvailable:'] / mem['MemTotal:']) * 100)
    except:
        pass
    return 0

def get_load():
    try:
        with open('/proc/loadavg') as f:
            return float(f.read().split()[0])
    except:
        return 0

def get_processes():
    try:
        result = subprocess.run(['ps', 'aux', '--no-headers'],
                              capture_output=True, text=True, timeout=10)
        procs = []
        for line in result.stdout.strip().split('\n'):
            parts = line.split()
            if len(parts) >= 11:
                procs.append(parts[10].split('/')[-1])
        return procs
    except:
        return []

def get_connections():
    try:
        result = subprocess.run(['ss', '-tuln'], capture_output=True, text=True, timeout=5)
        return len(result.stdout.strip().split('\n')) - 1
    except:
        return 0

def get_tig_s5():
    """Get TIG coherence if running."""
    try:
        with open('/var/lib/tig/queues/5_to_9.json') as f:
            return json.load(f).get('S5', None)
    except:
        return None

def hash_file(path):
    try:
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()
    except:
        return None

# ============================================================
# BASELINE
# ============================================================

class Baseline:
    def __init__(self):
        self.path = CRYSTALSS_BASELINE / "baseline.json"
        self.data = None
    
    def capture(self):
        log("BASELINE", "Capturing baseline...")
        procs = get_processes()
        self.data = {
            'timestamp': datetime.now().isoformat(),
            'hostname': socket.gethostname(),
            'cores': os.cpu_count(),
            'processes': sorted(set(procs)),
            'process_count': len(procs),
            'connections': get_connections(),
            'cpu': get_cpu(),
            'mem': get_memory(),
            'load': get_load(),
        }
        self.save()
        log("BASELINE", f"Captured: {len(self.data['processes'])} unique processes")
    
    def save(self):
        try:
            with open(self.path, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            log("BASELINE", f"Save error: {e}", "ERROR")
    
    def load(self):
        try:
            if self.path.exists():
                with open(self.path) as f:
                    self.data = json.load(f)
                log("BASELINE", f"Loaded from {self.data.get('timestamp', '?')}")
                return True
        except:
            pass
        return False
    
    def exists(self):
        return self.path.exists()

# ============================================================
# ANOMALY DETECTION
# ============================================================

class Detector:
    def __init__(self, baseline):
        self.baseline = baseline
    
    def check(self):
        if not self.baseline.data:
            return 0, []
        
        anomalies = []
        details = []
        
        # New processes
        current = set(get_processes())
        baseline = set(self.baseline.data.get('processes', []))
        new = current - baseline
        if len(new) > 10:
            anomalies.append(0.3)
            details.append(f"Many new processes: {len(new)}")
        
        # Load spike
        load = get_load()
        baseline_load = self.baseline.data.get('load', 1)
        if baseline_load > 0 and load > baseline_load * 3:
            anomalies.append(0.3)
            details.append(f"Load spike: {load:.1f}")
        
        # Memory
        mem = get_memory()
        if mem > 95:
            anomalies.append(0.3)
            details.append(f"Memory critical: {mem}%")
        
        # Connection spike
        conns = get_connections()
        baseline_conns = self.baseline.data.get('connections', 10)
        if baseline_conns > 0 and conns > baseline_conns * 3:
            anomalies.append(0.2)
            details.append(f"Connection spike: {conns}")
        
        return min(sum(anomalies), 1.0), details

# ============================================================
# GATE
# ============================================================

class Gate:
    def __init__(self):
        self.coherence = 1.0
        self.status = "NORMAL"
        self.is_open = True
    
    def update(self, coherence):
        self.coherence = coherence
        if coherence >= COHERENCE_THRESHOLD:
            self.status = "NORMAL"
            self.is_open = True
        elif coherence >= ALERT_THRESHOLD:
            self.status = "ALERT"
            self.is_open = False
        elif coherence >= LOCKDOWN_THRESHOLD:
            self.status = "DEFENSE"
            self.is_open = False
        else:
            self.status = "LOCKDOWN"
            self.is_open = False

# ============================================================
# MAIN
# ============================================================

def main():
    print()
    print("=" * 55)
    print("  CRYSTALSS - Crystal Security System (Linux)")
    print("=" * 55)
    print(f"  Host: {socket.gethostname()}")
    print(f"  Cores: {os.cpu_count()}")
    
    tig = get_tig_s5()
    print(f"  TIG: {'CONNECTED' if tig is not None else 'Not found'}")
    print("=" * 55)
    
    # Baseline
    baseline = Baseline()
    if baseline.exists():
        baseline.load()
    else:
        baseline.capture()
    
    detector = Detector(baseline)
    gate = Gate()
    
    fires = 0
    blocks = 0
    alerts = 0
    
    log("SYSTEM", "CRYSTALSS started")
    print("  Press Ctrl+C to stop")
    print("=" * 55)
    print()
    
    try:
        while True:
            # Get metrics
            cpu = get_cpu()
            mem = get_memory()
            load = get_load()
            tig_s5 = get_tig_s5()
            
            # Detect anomalies
            anomaly, details = detector.check()
            
            # Calculate coherence (blend with TIG if available)
            if tig_s5 is not None:
                coherence = (tig_s5 + (1 - anomaly)) / 2
            else:
                coherence = 1 - anomaly
            
            # Update gate
            old_status = gate.status
            gate.update(coherence)
            
            # Status change alerts
            if gate.status != old_status:
                if gate.status in ["LOCKDOWN", "DEFENSE"]:
                    alert(f"{gate.status}: coherence={coherence:.2f}")
                    alerts += 1
                elif gate.status == "ALERT":
                    log("GATE", f"Alert: coherence={coherence:.2f}", "WARNING")
                    alerts += 1
            
            # Log details
            for d in details:
                log("ANOMALY", d, "WARNING")
            
            # Fire or block
            if gate.is_open:
                fires += 1
            else:
                blocks += 1
            
            # Display
            icon = {"NORMAL": "[OK]", "ALERT": "[!!]", 
                    "DEFENSE": "[XX]", "LOCKDOWN": "[##]"}.get(gate.status, "[??]")
            
            tig_str = f"TIG:{tig_s5:.2f}" if tig_s5 is not None else "TIG:--"
            gate_str = "OPEN" if gate.is_open else "SHUT"
            
            line = (f"\r{icon} S*:{coherence:.2f} | "
                   f"CPU:{cpu:3d}% MEM:{mem:3d}% LOAD:{load:.1f} {tig_str} | "
                   f"{gate_str} | F:{fires:4d} B:{blocks:4d}")
            print(line, end="", flush=True)
            
            # Save state
            state = {
                'timestamp': datetime.now().isoformat(),
                'coherence': coherence,
                'status': gate.status,
                'gate': gate.is_open,
                'tig_s5': tig_s5,
                'cpu': cpu, 'mem': mem, 'load': load,
                'fires': fires, 'blocks': blocks, 'alerts': alerts
            }
            try:
                with open(CRYSTALSS_HOME / "state.json", 'w') as f:
                    json.dump(state, f)
            except:
                pass
            
            time.sleep(1)
            
    except KeyboardInterrupt:
        pass
    
    print("\n")
    print("=" * 55)
    print(f"  Fires: {fires}")
    print(f"  Blocks: {blocks}")
    print(f"  Alerts: {alerts}")
    print(f"  Logs: {CRYSTALSS_LOGS}")
    print("=" * 55)
    log("SYSTEM", f"Stopped. F:{fires} B:{blocks} A:{alerts}")

# ============================================================
# CLI
# ============================================================

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "status":
            try:
                with open(CRYSTALSS_HOME / "state.json") as f:
                    s = json.load(f)
                print(f"Status: {s['status']}")
                print(f"Coherence: {s['coherence']:.3f}")
                print(f"Gate: {'OPEN' if s['gate'] else 'CLOSED'}")
                print(f"TIG: {s.get('tig_s5', 'N/A')}")
            except:
                print("Not running")
        elif cmd == "reset":
            Baseline().capture()
        else:
            print("Usage: crystalss_linux.py [status|reset]")
    else:
        if os.geteuid() != 0:
            print("Run with sudo:")
            print("  sudo python3 crystalss_linux.py")
            sys.exit(1)
        main()
