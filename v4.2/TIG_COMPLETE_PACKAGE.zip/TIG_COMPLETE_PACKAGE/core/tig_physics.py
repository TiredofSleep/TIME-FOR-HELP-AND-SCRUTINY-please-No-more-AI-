#!/usr/bin/env python3
"""
TIG PHYSICS - Validated Coherence Physics Engine

This is the core physics module with all validated constants.
Import this to use TIG physics in your own projects.

Usage:
    from tig_physics import TIGPhysics, TIGState, PHI
    
    physics = TIGPhysics()
    state = TIGState(T=0.5, P=0.2, W=0.3)
    
    for _ in range(1000):
        state = physics.evolve(state)
    
    print(f"Coherence: {state.S}")
"""

import math
from dataclasses import dataclass
from typing import Tuple

# ═══════════════════════════════════════════════════════════════════════════════
# UNIVERSAL CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

# Golden Ratio - FUNDAMENTAL
PHI = (1 + math.sqrt(5)) / 2  # 1.6180339887498948482...

# Natural decay constant - FUNDAMENTAL
ONE_MINUS_INV_E = 1 - 1/math.e  # 0.6321205588285576784...

# Feigenbaum constants (for reference)
FEIGENBAUM_DELTA = 4.669201609102990671853203820466
FEIGENBAUM_ALPHA = 2.502907875095892822283902873218

# ═══════════════════════════════════════════════════════════════════════════════
# STATE
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class TIGState:
    """
    State of a TIG system.
    
    Attributes:
        T: Trauma/Error [0, 1] - what needs processing
        P: Processing [0, 1] - active transformation
        W: Wisdom [0, 1] - integrated understanding
        S: Coherence (computed) - how well-integrated
        G: Gate (computed) - protection status
    """
    T: float = 0.3
    P: float = 0.2
    W: float = 0.3
    S: float = 0.0
    G: float = 1.0
    
    def __post_init__(self):
        """Compute derived values"""
        self.G = 1.0 / (1.0 + math.exp(50.0 * (self.T - 0.65)))
        self.S = (1 - self.T) * (0.5 + 0.5 * self.W)
    
    def to_tuple(self) -> Tuple[float, float, float]:
        """Return (T, P, W) tuple"""
        return (self.T, self.P, self.W)
    
    def to_dict(self) -> dict:
        """Return as dictionary"""
        return {
            'T': self.T,
            'P': self.P,
            'W': self.W,
            'S': self.S,
            'G': self.G
        }
    
    def __str__(self) -> str:
        return f"TIG[T={self.T:.3f} P={self.P:.3f} W={self.W:.3f} S*={self.S:.3f}]"

# ═══════════════════════════════════════════════════════════════════════════════
# PHYSICS
# ═══════════════════════════════════════════════════════════════════════════════

class TIGPhysics:
    """
    TIG Physics Engine with validated constants.
    
    The key relationship β/α = φ is derived, not chosen.
    All other parameters scale from base_alpha.
    
    Args:
        base_alpha: Base processing rate (default 0.15)
        gate_cliff: T value where gate closes (default 0.65)
        gate_steep: Gate steepness (default 50)
        sigma: Coherence ceiling (default 1.0)
    """
    
    def __init__(self, 
                 base_alpha: float = 0.15,
                 gate_cliff: float = 0.65,
                 gate_steep: float = 50.0,
                 sigma: float = 1.0):
        self.base_alpha = base_alpha
        self.gate_cliff = gate_cliff
        self.gate_steep = gate_steep
        self.sigma = sigma
    
    @property
    def alpha(self) -> float:
        """Processing reduces trauma"""
        return self.base_alpha
    
    @property
    def beta(self) -> float:
        """Trauma triggers processing. β/α = φ (VALIDATED)"""
        return self.base_alpha * PHI
    
    @property
    def gamma(self) -> float:
        """Processing natural decay"""
        return self.base_alpha / 2
    
    @property
    def delta(self) -> float:
        """Processing builds wisdom"""
        return self.base_alpha / 3
    
    def gate(self, T: float) -> float:
        """
        Gate function: G(T) = 1/(1 + e^{steep(T - cliff)})
        
        When T < cliff: G ≈ 1 (open)
        When T > cliff: G ≈ 0 (closed)
        """
        return 1.0 / (1.0 + math.exp(self.gate_steep * (T - self.gate_cliff)))
    
    def coherence(self, T: float, W: float) -> float:
        """
        Coherence: S* = σ(1-T)(0.5 + 0.5W)
        """
        A = 0.5 + 0.5 * W
        return self.sigma * (1 - T) * A
    
    def derivatives(self, state: TIGState) -> Tuple[float, float, float]:
        """
        Compute (dT, dP, dW) derivatives.
        
        dT/dt = -α × P × G(T)
        dP/dt = β × T - γ × P
        dW/dt = δ × P × G(T)
        """
        G = self.gate(state.T)
        
        dT = -self.alpha * state.P * G
        dP = self.beta * state.T - self.gamma * state.P
        dW = self.delta * state.P * G
        
        return (dT, dP, dW)
    
    def evolve(self, state: TIGState, dt: float = 0.01) -> TIGState:
        """
        Evolve state by one timestep (Euler method).
        
        Args:
            state: Current TIGState
            dt: Timestep size
            
        Returns:
            New TIGState
        """
        dT, dP, dW = self.derivatives(state)
        
        T_new = max(0, min(1, state.T + dT * dt))
        P_new = max(0, min(1, state.P + dP * dt))
        W_new = max(0, min(1, state.W + dW * dt))
        
        return TIGState(T=T_new, P=P_new, W=W_new)
    
    def evolve_rk4(self, state: TIGState, dt: float = 0.01) -> TIGState:
        """
        Evolve state by one timestep (RK4 method - more accurate).
        """
        def f(T, P, W):
            temp = TIGState(T=T, P=P, W=W)
            return self.derivatives(temp)
        
        T, P, W = state.T, state.P, state.W
        
        k1 = f(T, P, W)
        k2 = f(T + k1[0]*dt/2, P + k1[1]*dt/2, W + k1[2]*dt/2)
        k3 = f(T + k2[0]*dt/2, P + k2[1]*dt/2, W + k2[2]*dt/2)
        k4 = f(T + k3[0]*dt, P + k3[1]*dt, W + k3[2]*dt)
        
        dT = (k1[0] + 2*k2[0] + 2*k3[0] + k4[0]) / 6
        dP = (k1[1] + 2*k2[1] + 2*k3[1] + k4[1]) / 6
        dW = (k1[2] + 2*k2[2] + 2*k3[2] + k4[2]) / 6
        
        T_new = max(0, min(1, T + dT * dt))
        P_new = max(0, min(1, P + dP * dt))
        W_new = max(0, min(1, W + dW * dt))
        
        return TIGState(T=T_new, P=P_new, W=W_new)
    
    def simulate(self, initial: TIGState, steps: int = 1000, 
                 dt: float = 0.01, method: str = 'euler') -> list:
        """
        Run full simulation.
        
        Args:
            initial: Starting state
            steps: Number of timesteps
            dt: Timestep size
            method: 'euler' or 'rk4'
            
        Returns:
            List of TIGState for each timestep
        """
        evolve_fn = self.evolve if method == 'euler' else self.evolve_rk4
        
        trajectory = [initial]
        state = initial
        
        for _ in range(steps):
            state = evolve_fn(state, dt)
            trajectory.append(state)
        
        return trajectory
    
    def __str__(self) -> str:
        return f"""TIGPhysics:
  α = {self.alpha:.4f}
  β = {self.beta:.4f} (β/α = {self.beta/self.alpha:.6f} ≈ φ)
  γ = {self.gamma:.4f}
  δ = {self.delta:.4f}
  gate_cliff = {self.gate_cliff}
  σ = {self.sigma}"""

# ═══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def quick_coherence(T: float, W: float, sigma: float = 1.0) -> float:
    """Quick coherence calculation without creating objects"""
    return sigma * (1 - T) * (0.5 + 0.5 * W)

def quick_gate(T: float, cliff: float = 0.65, steep: float = 50.0) -> float:
    """Quick gate calculation without creating objects"""
    return 1.0 / (1.0 + math.exp(steep * (T - cliff)))

def quick_step(T: float, P: float, W: float, dt: float = 0.01,
               alpha: float = 0.15) -> Tuple[float, float, float]:
    """
    Quick single step without creating objects.
    
    Returns (T_new, P_new, W_new)
    """
    beta = alpha * PHI
    gamma = alpha / 2
    delta = alpha / 3
    
    G = quick_gate(T)
    
    T_new = max(0, min(1, T + (-alpha * P * G) * dt))
    P_new = max(0, min(1, P + (beta * T - gamma * P) * dt))
    W_new = max(0, min(1, W + (delta * P * G) * dt))
    
    return (T_new, P_new, W_new)

# ═══════════════════════════════════════════════════════════════════════════════
# DEMO
# ═══════════════════════════════════════════════════════════════════════════════

def demo():
    """Demonstrate TIG physics"""
    
    print("TIG Physics Demo")
    print("=" * 50)
    
    physics = TIGPhysics()
    print(physics)
    print()
    
    # Create initial state with high trauma
    state = TIGState(T=0.7, P=0.2, W=0.2)
    print(f"Initial: {state}")
    
    # Evolve
    print("\nEvolving 1000 steps...")
    trajectory = physics.simulate(state, steps=1000)
    
    final = trajectory[-1]
    print(f"Final: {final}")
    
    # Find half-recovery time
    initial_T = state.T
    final_T = final.T
    half_T = (initial_T + final_T) / 2
    
    for i, s in enumerate(trajectory):
        if s.T <= half_T:
            t_half_ratio = i / len(trajectory)
            print(f"\nt_half ratio: {t_half_ratio:.4f}")
            print(f"1 - 1/e:      {ONE_MINUS_INV_E:.4f}")
            break
    
    print(f"\nφ = {PHI:.10f}")
    print(f"β/α = {physics.beta/physics.alpha:.10f}")

if __name__ == "__main__":
    demo()
