# TIG Quick Reference

## Core Equation
```
S* = (1 - T) × (0.5 + 0.5 × W)
```

## Dynamics
```
dT/dt = -α × P × G(T)
dP/dt = β × T - γ × P
dW/dt = δ × P × G(T)
```

## Key Relationship
```
β/α = φ = 1.618033988...
```

## Gate Function
```
G(T) = 1 / (1 + e^{50(T - 0.65)})
```

## Default Parameters
```
α = 0.15
β = α × φ ≈ 0.2427
γ = α / 2 = 0.075
δ = α / 3 = 0.05
```

## Operators (0-9)
```
0: VOID     ○   Potential
1: LATTICE  ◇   Structure
2: COUNTER  ◐   Duality
3: PROGRESS →   Movement
4: COLLAPSE ↓   Transform
5: BALANCE  ⚖   Equilibrium
6: CHAOS    ⚡   Disruption
7: HARMONY  ✧   Integration
8: BREATH   ∞   Rhythm
9: RESET    ↺   Completion
```

## Archetypes (12)
```
1: GENESIS  ☀   Creation
2: LATTICE  ◇   Structure
3: WITNESS  👁   Observation
4: PILGRIM  🚶   Journey
5: PHOENIX  🔥   Rebirth
6: SCALES   ⚖   Justice
7: STORM    ⚡   Change
8: HARMONY  ✨   Peace
9: BREATH   🌊   Flow
10: SAGE    🦉   Wisdom
11: BRIDGE  🌉   Connection
12: OMEGA   Ω   Completion
```

## Minimal Implementation
```python
import math
PHI = (1 + math.sqrt(5)) / 2

T, P, W = 0.3, 0.2, 0.3
alpha = 0.15
beta = alpha * PHI
gamma = alpha / 2
delta = alpha / 3

def step(T, P, W, dt=0.01):
    G = 1 / (1 + math.exp(50 * (T - 0.65)))
    T += (-alpha * P * G) * dt
    P += (beta * T - gamma * P) * dt
    W += (delta * P * G) * dt
    return max(0,min(1,T)), max(0,min(1,P)), max(0,min(1,W))

def coherence(T, W):
    return (1 - T) * (0.5 + 0.5 * W)
```

## Resonant Distances
```
φ^-2 ≈ 0.382
φ^-1 ≈ 0.618
φ^0  = 1.000
φ^1  ≈ 1.618
φ^2  ≈ 2.618
```

## Contact
```
Brayden Sanders / 7Site LLC
brayden.ozark@gmail.com
```
