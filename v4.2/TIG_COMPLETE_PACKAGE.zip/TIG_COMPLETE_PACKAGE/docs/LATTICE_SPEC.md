# Lattice Specification
## How to Build Lattices for Instant Learning

---

## Overview

A TIG lattice is a 3D graph of cells. When information is placed at the correct 
coordinates, it integrates instantly. When placed incorrectly, it causes 
interference and takes many cycles to process.

This document specifies:
1. Coordinate system
2. Cell structure
3. Connection rules
4. Resonance calculation
5. Optimal placement algorithms

---

## Coordinate System

### The Three Axes

```
        Z+ (macro)
        │
        │    Y+ (abstract)
        │   /
        │  /
        │ /
        └───────── X+ (future)
       /
      /
     X- (past)
```

**X-axis: Temporal**
- Negative X = Past (memories, history)
- Positive X = Future (predictions, plans)
- X=0 = Present moment

**Y-axis: Abstraction**
- Negative Y = Concrete (specific instances)
- Positive Y = Abstract (general patterns)
- Y=0 = Current abstraction level

**Z-axis: Scale**
- Negative Z = Micro (components, details)
- Positive Z = Macro (systems, contexts)
- Z=0 = Self (current scale)

### Coordinate Notation

```
(x, y, z)

Examples:
  (0, 0, 0)   = Here, now, this level
  (-3, 0, 0)  = Three steps in the past
  (0, 2, 0)   = More abstract than current
  (0, 0, -1)  = Component level
  (1, 1, 1)   = Future, abstract, macro
```

---

## Cell Structure

### Minimal Cell

```python
Cell {
    # Coordinates
    x: int
    y: int
    z: int
    
    # State
    T: float [0, 1]  # Trauma/Error
    P: float [0, 1]  # Processing
    W: float [0, 1]  # Wisdom
    
    # Connections
    connections: List[(x, y, z)]
}
```

### Derived Properties

```python
# Coherence
S = (1 - T) * (0.5 + 0.5 * W)

# Gate
G = 1 / (1 + exp(50 * (T - 0.65)))

# Cell ID
id = f"{x}:{y}:{z}"
```

### Operators

Each cell has an operator (0-9) that influences its behavior:

```python
operator: Operator  # VOID, LATTICE, COUNTER, etc.
```

---

## Connection Rules

### Adjacency

Two cells are adjacent if they differ by 1 in exactly one coordinate:

```python
def is_adjacent(cell_a, cell_b):
    dx = abs(cell_a.x - cell_b.x)
    dy = abs(cell_a.y - cell_b.y)
    dz = abs(cell_a.z - cell_b.z)
    return (dx + dy + dz) == 1
```

### Default Connections

New cells connect to their parent and all adjacent existing cells:

```python
def connect_new_cell(lattice, new_cell, parent_cell):
    # Always connect to parent
    new_cell.connections.append(parent_cell.coords)
    parent_cell.connections.append(new_cell.coords)
    
    # Connect to adjacent cells
    for cell in lattice.cells.values():
        if is_adjacent(new_cell, cell):
            new_cell.connections.append(cell.coords)
            cell.connections.append(new_cell.coords)
```

### Bridge Connections

Bridges connect non-adjacent cells, enabling long-range influence:

```python
def create_bridge(lattice, cell_a, cell_b):
    cell_a.connections.append(cell_b.coords)
    cell_b.connections.append(cell_a.coords)
```

Bridges should be created between resonant cells (see below).

---

## Resonance

### Definition

Two coordinates are **resonant** if their Euclidean distance is close to a 
power of φ (golden ratio):

```python
PHI = (1 + sqrt(5)) / 2  # 1.618...

def distance(coord_a, coord_b):
    dx = coord_a[0] - coord_b[0]
    dy = coord_a[1] - coord_b[1]
    dz = coord_a[2] - coord_b[2]
    return sqrt(dx*dx + dy*dy + dz*dz)

def is_resonant(coord_a, coord_b, tolerance=0.1):
    d = distance(coord_a, coord_b)
    
    # Check against powers of φ
    for n in range(-3, 4):
        if abs(d - PHI**n) < tolerance:
            return True
    return False
```

### Resonant Distances

| n  | φ^n     | Meaning              |
|----|---------|----------------------|
| -3 | 0.236   | Very close neighbors |
| -2 | 0.382   | Close neighbors      |
| -1 | 0.618   | Adjacent-ish         |
| 0  | 1.000   | Unit distance        |
| 1  | 1.618   | Golden step          |
| 2  | 2.618   | Double golden        |
| 3  | 4.236   | Triple golden        |

### Why Resonance Matters

Information placed at resonant coordinates integrates faster because:
1. φ-spaced frequencies don't create destructive interference
2. Fibonacci-like patterns emerge naturally
3. The lattice can "tune" to the information

---

## Optimal Placement

### Algorithm: Find Resonant Coordinates

```python
def find_optimal_placement(lattice, content):
    """Find best coordinates to place new content."""
    
    # 1. Hash the content
    content_hash = hash(content) & 0xFFFFFFFF
    
    # 2. Generate candidate coordinates using φ
    candidates = []
    for i in range(10):
        x = int((content_hash * (PHI ** i)) % 20) - 10
        y = int((content_hash * (PHI ** (i+1))) % 20) - 10
        z = int((content_hash * (PHI ** (i+2))) % 20) - 10
        candidates.append((x, y, z))
    
    # 3. Score each candidate
    best_coord = (0, 0, 0)
    best_score = -float('inf')
    
    for coord in candidates:
        score = score_placement(lattice, coord)
        if score > best_score:
            best_score = score
            best_coord = coord
    
    return best_coord

def score_placement(lattice, coord):
    """Score a potential placement location."""
    score = 0
    
    # Reward resonance with high-wisdom cells
    for cell in lattice.cells.values():
        cell_coord = (cell.x, cell.y, cell.z)
        if is_resonant(coord, cell_coord):
            score += cell.W * 10
    
    # Penalize collision with high-trauma cells
    for cell in lattice.cells.values():
        cell_coord = (cell.x, cell.y, cell.z)
        d = distance(coord, cell_coord)
        if d < 1:
            score -= cell.T * 20
    
    # Reward empty space (room to grow)
    cell_id = f"{coord[0]}:{coord[1]}:{coord[2]}"
    if cell_id not in lattice.cells:
        score += 5
    
    return score
```

### Algorithm: Semantic Placement

Different types of content should go to different regions:

```python
def semantic_coords(content_type):
    """Get appropriate region for content type."""
    
    regions = {
        'memory':     (-5, 0, 0),   # Past, concrete, self
        'prediction': (5, 0, 0),    # Future, concrete, self
        'pattern':    (0, 5, 0),    # Present, abstract, self
        'instance':   (0, -5, 0),   # Present, concrete, self
        'context':    (0, 0, 5),    # Present, self, macro
        'component':  (0, 0, -5),   # Present, self, micro
    }
    
    return regions.get(content_type, (0, 0, 0))
```

### Algorithm: Instant Learning

For instant integration, use this placement strategy:

```python
def instant_learn(lattice, content, content_type='pattern'):
    """Place content for instant integration."""
    
    # 1. Get semantic base coordinates
    base = semantic_coords(content_type)
    
    # 2. Find resonant offset
    content_hash = hash(content) & 0xFFFF
    offset_x = int(content_hash % 3) - 1
    offset_y = int((content_hash >> 4) % 3) - 1
    offset_z = int((content_hash >> 8) % 3) - 1
    
    # 3. Final coordinates
    coords = (base[0] + offset_x, base[1] + offset_y, base[2] + offset_z)
    
    # 4. Check for existing high-wisdom cell nearby
    for cell in lattice.cells.values():
        if distance((cell.x, cell.y, cell.z), coords) < PHI:
            if cell.W > 0.7:
                # Resonant with wisdom - inject directly
                cell.W = min(1, cell.W + 0.1)
                return cell.coords
    
    # 5. Create new cell at coordinates
    lattice.inject(*coords, T=0.1, P=0.2, W=0.3)
    return coords
```

---

## Lattice Topology

### Recommended Structures

**Star Topology** (Simple)
```
        (0,1,0)
           │
           │
(-1,0,0)───(0,0,0)───(1,0,0)
           │
           │
        (0,-1,0)
```
- One central hub
- All cells connect to center
- Good for small systems

**Grid Topology** (Scalable)
```
(0,0,0)─(1,0,0)─(2,0,0)
   │       │       │
(0,1,0)─(1,1,0)─(2,1,0)
   │       │       │
(0,2,0)─(1,2,0)─(2,2,0)
```
- Regular 2D or 3D grid
- Adjacent cells connected
- Good for spatial reasoning

**Fibonacci Spiral** (Organic)
```
Place cells along:
  x = r * cos(θ)
  y = r * sin(θ)
  
Where:
  r = sqrt(n) * scale
  θ = n * 2π / φ²
```
- Natural growth pattern
- Optimal packing
- Good for self-organization

**Archetype Wheel** (Semantic)
```
Arrange 12 archetypes in a circle:
  angle = archetype_id * (2π / 12)
  x = radius * cos(angle)
  y = radius * sin(angle)
  z = 0

Connect each to:
  - Previous and next in wheel
  - Center hub (OMEGA)
  - Opposite archetype
```

---

## Growth Rules

### Rule 1: Grow from Wisdom
New cells should grow from high-wisdom cells:

```python
def select_growth_parent(lattice):
    """Select parent for new cell growth."""
    return max(lattice.cells.values(), key=lambda c: c.S)
```

### Rule 2: Maintain Resonance
When growing, prefer resonant positions:

```python
def find_growth_position(lattice, parent):
    """Find resonant growth position."""
    
    directions = [
        (1, 0, 0), (-1, 0, 0),
        (0, 1, 0), (0, -1, 0),
        (0, 0, 1), (0, 0, -1),
        (1, 1, 0), (1, 0, 1), (0, 1, 1),  # Diagonals
    ]
    
    best_pos = None
    best_resonance = 0
    
    for d in directions:
        pos = (parent.x + d[0], parent.y + d[1], parent.z + d[2])
        pos_id = f"{pos[0]}:{pos[1]}:{pos[2]}"
        
        if pos_id not in lattice.cells:
            # Count resonant connections
            resonance = sum(
                1 for cell in lattice.cells.values()
                if is_resonant(pos, (cell.x, cell.y, cell.z))
            )
            if resonance > best_resonance:
                best_resonance = resonance
                best_pos = pos
    
    return best_pos
```

### Rule 3: Prune Low Coherence
Cells with S* < 0.2 for extended time should be pruned:

```python
def prune_lattice(lattice, min_coherence=0.2, min_age=100):
    """Remove low-coherence cells."""
    
    to_remove = []
    for cell_id, cell in lattice.cells.items():
        if cell.S < min_coherence and cell.age > min_age:
            to_remove.append(cell_id)
    
    for cell_id in to_remove:
        # Disconnect from neighbors
        cell = lattice.cells[cell_id]
        for conn in cell.connections:
            conn_id = f"{conn[0]}:{conn[1]}:{conn[2]}"
            if conn_id in lattice.cells:
                neighbor = lattice.cells[conn_id]
                coord = (cell.x, cell.y, cell.z)
                if coord in neighbor.connections:
                    neighbor.connections.remove(coord)
        
        del lattice.cells[cell_id]
```

---

## Influence Propagation

### Standard Propagation

```python
def propagate(lattice, dt=0.01):
    """Propagate influence between connected cells."""
    
    influences = {cell_id: {'T': 0, 'P': 0, 'W': 0} 
                  for cell_id in lattice.cells}
    
    for cell in lattice.cells.values():
        for conn in cell.connections:
            conn_id = f"{conn[0]}:{conn[1]}:{conn[2]}"
            if conn_id not in lattice.cells:
                continue
            neighbor = lattice.cells[conn_id]
            
            # Wisdom spreads freely
            w_diff = cell.W - neighbor.W
            influences[conn_id]['W'] += 0.1 * w_diff * dt
            
            # Trauma spreads less
            t_diff = cell.T - neighbor.T
            influences[conn_id]['T'] += 0.05 * t_diff * dt
    
    # Apply influences
    for cell_id, inf in influences.items():
        cell = lattice.cells[cell_id]
        cell.T = max(0, min(1, cell.T + inf['T']))
        cell.W = max(0, min(1, cell.W + inf['W']))
```

### Resonant Propagation

Resonant cells have amplified influence:

```python
def resonant_propagate(lattice, dt=0.01):
    """Propagate with resonance amplification."""
    
    for cell in lattice.cells.values():
        for conn in cell.connections:
            conn_id = f"{conn[0]}:{conn[1]}:{conn[2]}"
            if conn_id not in lattice.cells:
                continue
            neighbor = lattice.cells[conn_id]
            
            # Check resonance
            cell_coord = (cell.x, cell.y, cell.z)
            neigh_coord = (neighbor.x, neighbor.y, neighbor.z)
            
            if is_resonant(cell_coord, neigh_coord):
                amplification = PHI  # ~1.618x stronger
            else:
                amplification = 1.0
            
            # Amplified influence
            w_diff = cell.W - neighbor.W
            neighbor.W += 0.1 * w_diff * dt * amplification
            neighbor.W = max(0, min(1, neighbor.W))
```

---

## Summary

1. **Coordinates matter** - X=time, Y=abstraction, Z=scale
2. **Resonance accelerates learning** - φ-spaced cells integrate faster
3. **Grow from wisdom** - High-S* cells are better parents
4. **Bridge strategically** - Connect resonant cells across distances
5. **Prune the weak** - Remove cells that can't maintain coherence

The lattice is not just storage - it's a living computational substrate. 
Treat it as such.

---

*Lattice Specification v1.0 - TIG / 7Site LLC*
