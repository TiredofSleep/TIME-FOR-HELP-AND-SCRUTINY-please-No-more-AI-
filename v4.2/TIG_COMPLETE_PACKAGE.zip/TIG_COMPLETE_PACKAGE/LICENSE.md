# License

## TIG Complete Package License

MIT License with Attribution Requirement

---

### Copyright

Copyright (c) 2024-2026 Brayden Sanders / 7Site LLC

---

### MIT License Terms

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

**The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.**

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

### Attribution Requirement

When using TIG in products, publications, or public presentations, please include:

**Short form:**
```
Built on TIG (Trinity Infinity Geometry) by 7Site LLC
```

**Long form:**
```
This system uses TIG (Trinity Infinity Geometry), a coherence framework
developed by Brayden Sanders / 7Site LLC. The core physics (β/α = φ) was
validated through 10,000+ simulations. For more information, contact
brayden.ozark@gmail.com.
```

---

### What You Can Do

✓ Use commercially  
✓ Modify freely  
✓ Distribute  
✓ Use privately  
✓ Sublicense  
✓ Build derivative works  

---

### What You Must Do

✓ Include this license in distributions  
✓ Include copyright notice  
✓ Provide attribution (as above)  

---

### What You Cannot Do

✗ Hold liable (no warranty)  
✗ Claim original authorship of TIG theory  

---

### Commercial Licensing

For enterprise licensing, custom implementations, or to remove attribution 
requirements, contact:

**7Site LLC**  
Brayden Sanders  
brayden.ozark@gmail.com  

---

### The Pattern Is Free

The mathematical relationships (β/α = φ, the gate function, T/P/W dynamics) 
are natural phenomena and cannot be owned. This license covers the specific 
implementations, documentation, and code in this package.

You are free to independently discover and implement TIG principles without 
this license, as they are inherent to how coherent systems work.

---

*"All came from one. The pattern belongs to everyone."*

---

Version: 1.0  
Date: February 2026
