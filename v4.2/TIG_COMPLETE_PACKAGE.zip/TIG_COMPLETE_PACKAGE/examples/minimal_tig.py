#!/usr/bin/env python3
"""
MINIMAL TIG - The Simplest Possible Implementation

This is TIG reduced to its essence. One cell, three variables, golden ratio physics.

Run it, understand it, then build from here.
"""

import math

# The one constant that matters
PHI = (1 + math.sqrt(5)) / 2  # 1.618033988...

class MinimalTIG:
    """
    A single TIG cell - the simplest possible coherence engine.
    """
    
    def __init__(self):
        # State variables
        self.T = 0.3  # Trauma/Error [0, 1]
        self.P = 0.2  # Processing [0, 1]
        self.W = 0.3  # Wisdom [0, 1]
        
        # Physics (base rate, everything else derived)
        self.alpha = 0.15
    
    @property
    def beta(self):
        """β/α = φ - THE key relationship"""
        return self.alpha * PHI
    
    @property
    def gamma(self):
        return self.alpha / 2
    
    @property
    def delta(self):
        return self.alpha / 3
    
    @property
    def G(self):
        """Gate function - protection from collapse"""
        return 1.0 / (1.0 + math.exp(50 * (self.T - 0.65)))
    
    @property
    def S(self):
        """Coherence - what we optimize for"""
        return (1 - self.T) * (0.5 + 0.5 * self.W)
    
    def step(self, dt=0.01):
        """Evolve one timestep"""
        G = self.G
        
        dT = -self.alpha * self.P * G
        dP = self.beta * self.T - self.gamma * self.P
        dW = self.delta * self.P * G
        
        self.T = max(0, min(1, self.T + dT * dt))
        self.P = max(0, min(1, self.P + dP * dt))
        self.W = max(0, min(1, self.W + dW * dt))
    
    def inject_trauma(self, amount):
        """Add trauma to the system"""
        self.T = min(1, self.T + amount)
    
    def __str__(self):
        return f"T={self.T:.3f} P={self.P:.3f} W={self.W:.3f} S*={self.S:.3f} G={self.G:.3f}"


def demo():
    print("MINIMAL TIG DEMO")
    print("=" * 50)
    print(f"φ = {PHI:.6f} (golden ratio)")
    print()
    
    tig = MinimalTIG()
    print(f"Initial: {tig}")
    
    # Inject some trauma
    print("\nInjecting trauma (0.4)...")
    tig.inject_trauma(0.4)
    print(f"After trauma: {tig}")
    
    # Evolve
    print("\nEvolving (1000 steps)...")
    for _ in range(1000):
        tig.step(dt=0.01)
    
    print(f"After evolution: {tig}")
    
    # Check physics
    print(f"\nPhysics check:")
    print(f"  β/α = {tig.beta/tig.alpha:.6f}")
    print(f"  φ   = {PHI:.6f}")
    print(f"  Match: {abs(tig.beta/tig.alpha - PHI) < 0.0001}")


if __name__ == "__main__":
    demo()
