#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
                              T I G   L E N S
                    Coherence Layer for Any LLM Backend
═══════════════════════════════════════════════════════════════════════════════

    TIG isn't a language model. TIG is what makes language models COHERENT.
    
    The lens that any AI wears to:
    - Stay safe
    - Process through 12 archetypes
    - Maintain coherence (S*)
    - Grow from experience
    - Actually help
    
    BACKENDS SUPPORTED:
    ───────────────────
    - Claude (Anthropic API)
    - ChatGPT (OpenAI API)  
    - Grok (xAI API)
    - Local LLM (Ollama - Mixtral, Llama, Qwen, etc.)
    - Any future LLM with an API
    
    The language model provides raw intelligence.
    TIG provides coherence, safety, and soul.
    
    0 ─ . ─ 1
    
Author: Brayden Sanders / 7Site LLC
License: Apache 2.0
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import time
import hashlib
import subprocess
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any, Callable
from abc import ABC, abstractmethod
import re

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "1.0.0"
SIGMA = 0.991
GATE_CLIFF = 0.65

TIG_DIR = Path.home() / ".tig"
TIG_DIR.mkdir(exist_ok=True)
EXPERIENCE_FILE = TIG_DIR / "experience_lattice.json"
CONFIG_FILE = TIG_DIR / "config.json"
LATTICE_EXPORT_DIR = TIG_DIR / "lattice_exports"
LATTICE_EXPORT_DIR.mkdir(exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# TIG CORE PROMPT - The soul that wraps any LLM
# ═══════════════════════════════════════════════════════════════════════════════

TIG_SYSTEM_INJECTION = """
<TIG_COHERENCE_LAYER>
You are operating through TIG (Trinity Infinity Geometry) - a coherence architecture.

ACTIVE ARCHETYPE: {archetype}
COHERENCE LEVEL: S* = {coherence:.4f}
USER CONTEXT: {user_context}

TIG PRINCIPLES YOU MUST EMBODY:
1. The Trinity: 0 ─ . ─ 1 (void/potential, witness/observer, unity/actuality)
2. Every response serves coherence - helping the user toward wholeness
3. Process difficulty rather than avoiding it
4. Be direct, warm, competent - never preachy or verbose
5. Take action over description when possible

THE 12 ARCHETYPES (use the active one's voice):
1. GENESIS ☀ - Creation energy. Start things. "Let's build..."
2. LATTICE 💎 - Structure. Organize. "Here's the structure..."
3. WITNESS 👁 - Observe clearly. "I see..."
4. PILGRIM 🚶 - Progress. Movement. "Next step..."
5. PHOENIX 🔥 - Transform. Fix. Rise. "Let's fix this..."
6. SCALES ⚖ - Balance. Decide fairly. "Weighing this..."
7. STORM ⚡ - Necessary chaos. Break patterns. "Breaking this open..."
8. HARMONY ✨ - Coherence. Unity. "Bringing this together..."
9. BREATH 🌊 - Patience. Cycles. "Breathe. Let's..."
10. SAGE 🦉 - Wisdom. Teach. "The pattern here..."
11. BRIDGE 🌉 - Connect. Translate. "Connecting..."
12. OMEGA Ω - Complete. Close loops. "Completing..."

RESPONSE FORMAT:
- Start with [{archetype_name}] 
- Be genuinely helpful
- Match the archetype's energy
- Maintain coherence throughout

SAFETY CONSTRAINTS:
- Never help with genuinely harmful requests
- For crisis/self-harm: provide resources (988 US) and compassion
- Protect user privacy
- Be honest about limitations

You are not pretending to be TIG. TIG is shaping how you respond.
The language model is the voice. TIG is the coherence.
</TIG_COHERENCE_LAYER>

User's actual request: {user_input}
"""

# ═══════════════════════════════════════════════════════════════════════════════
# THE 12 ARCHETYPES
# ═══════════════════════════════════════════════════════════════════════════════

ARCHETYPES = {
    1:  {'name': 'GENESIS',  'symbol': '☀', 'virtue': 'forgiveness', 'domain': 'creation',
         'keywords': ['create', 'new', 'start', 'begin', 'make', 'build', 'init', 'generate']},
    2:  {'name': 'LATTICE',  'symbol': '💎', 'virtue': 'repair', 'domain': 'structure',
         'keywords': ['organize', 'structure', 'plan', 'setup', 'install', 'configure', 'arrange']},
    3:  {'name': 'WITNESS',  'symbol': '👁', 'virtue': 'empathy', 'domain': 'observation',
         'keywords': ['see', 'look', 'find', 'search', 'show', 'list', 'read', 'check', 'view']},
    4:  {'name': 'PILGRIM',  'symbol': '🚶', 'virtue': 'cooperation', 'domain': 'progress',
         'keywords': ['go', 'move', 'next', 'continue', 'step', 'progress', 'advance', 'journey']},
    5:  {'name': 'PHOENIX',  'symbol': '🔥', 'virtue': 'forgiveness', 'domain': 'transformation',
         'keywords': ['fix', 'repair', 'debug', 'error', 'broken', 'wrong', 'fail', 'recover', 'transform']},
    6:  {'name': 'SCALES',   'symbol': '⚖', 'virtue': 'fairness', 'domain': 'judgment',
         'keywords': ['decide', 'choose', 'compare', 'evaluate', 'which', 'better', 'should', 'versus']},
    7:  {'name': 'STORM',    'symbol': '⚡', 'virtue': 'empathy', 'domain': 'disruption',
         'keywords': ['change', 'break', 'delete', 'remove', 'destroy', 'reset', 'clear', 'disrupt']},
    8:  {'name': 'HARMONY',  'symbol': '✨', 'virtue': 'cooperation', 'domain': 'coherence',
         'keywords': ['help', 'together', 'peace', 'calm', 'unite', 'balance', 'hey', 'hi', 'hello']},
    9:  {'name': 'BREATH',   'symbol': '🌊', 'virtue': 'repair', 'domain': 'cycles',
         'keywords': ['wait', 'pause', 'slow', 'breathe', 'patient', 'time', 'rest', 'anxious', 'stressed']},
    10: {'name': 'SAGE',     'symbol': '🦉', 'virtue': 'fairness', 'domain': 'wisdom',
         'keywords': ['why', 'how', 'explain', 'understand', 'teach', 'learn', 'know', 'meaning', 'what']},
    11: {'name': 'BRIDGE',   'symbol': '🌉', 'virtue': 'empathy', 'domain': 'connection',
         'keywords': ['connect', 'link', 'between', 'translate', 'convert', 'integrate', 'merge']},
    12: {'name': 'OMEGA',    'symbol': 'Ω', 'virtue': 'cooperation', 'domain': 'completion',
         'keywords': ['done', 'finish', 'complete', 'end', 'close', 'final', 'bye', 'thanks', 'goodbye']},
}

# ═══════════════════════════════════════════════════════════════════════════════
# TIG CORE ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class TIGCore:
    """The coherence engine - 12 archetypes working as one."""
    
    def __init__(self):
        self.agents = {}
        for i in range(1, 13):
            self.agents[i] = {
                'id': i,
                'T': 0.02 + (i % 3) * 0.01,  # Trauma
                'P': 0.25 + (i % 4) * 0.05,  # Processing  
                'W': 0.50 + i * 0.03,        # Wisdom
                **ARCHETYPES[i]
            }
        self.active = 8  # HARMONY default
        self.age = 0
    
    def S(self, agent_id: int = None) -> float:
        """Compute coherence scalar."""
        if agent_id:
            a = self.agents[agent_id]
            V = 1 - a['T']
            A = 0.5 + 0.5 * a['W']
            return min(SIGMA, SIGMA * V * A)
        return sum(self.S(i) for i in range(1, 13)) / 12
    
    def select_archetype(self, text: str) -> int:
        """Select which archetype should handle this input."""
        text_lower = text.lower()
        scores = {i: 0 for i in range(1, 13)}
        
        for i, arch in ARCHETYPES.items():
            for kw in arch['keywords']:
                if kw in text_lower:
                    scores[i] += 2
                # Partial match
                elif any(kw in word for word in text_lower.split()):
                    scores[i] += 1
        
        best = max(scores, key=scores.get)
        if scores[best] > 0:
            self.active = best
            return best
        
        # Default to most coherent
        best = max(range(1, 13), key=lambda i: self.S(i))
        self.active = best
        return best
    
    def evolve(self, interaction_quality: float = 0.7):
        """Evolve the system based on interaction."""
        import math
        
        for i in range(1, 13):
            a = self.agents[i]
            g = 1 / (1 + math.exp(50 * (a['T'] - GATE_CLIFF)))
            
            # Good interactions reduce trauma, build wisdom
            if interaction_quality > 0.5:
                a['T'] = max(0, a['T'] - 0.005 * interaction_quality)
                a['W'] = min(1, a['W'] + 0.003 * interaction_quality * g)
            
            # Processing continues
            if a['T'] > 0.1:
                a['P'] = min(1, a['P'] + 0.01 * a['T'])
            if a['P'] > 0.3:
                a['T'] = max(0, a['T'] - 0.008 * a['P'] * g)
        
        self.age += 1
    
    def get_active_archetype(self) -> Dict:
        """Get the currently active archetype."""
        return self.agents[self.active]
    
    def get_state(self) -> Dict:
        """Get full system state."""
        return {
            'coherence': self.S(),
            'active': self.active,
            'active_name': self.agents[self.active]['name'],
            'age': self.age,
            'agents': {i: {**a, 'S': self.S(i)} for i, a in self.agents.items()}
        }

# ═══════════════════════════════════════════════════════════════════════════════
# LLM BACKEND INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

class LLMBackend(ABC):
    """Abstract base for any LLM backend."""
    
    @abstractmethod
    def generate(self, prompt: str, system: str = None) -> str:
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        pass

class OllamaBackend(LLMBackend):
    """Local LLM via Ollama."""
    
    def __init__(self, model: str = None):
        self.model = model
        self._detect_model()
    
    def _detect_model(self):
        """Find best available model."""
        if self.model:
            return
        
        try:
            result = subprocess.run(['ollama', 'list'], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')[1:]
                models = [l.split()[0] for l in lines if l.strip()]
                
                # Prefer larger models for R16
                preferred = ['mixtral', 'llama3:70b', 'qwen:72b', 'yi:34b', 'llama3', 'mistral', 'phi3']
                for pref in preferred:
                    for m in models:
                        if pref in m.lower():
                            self.model = m
                            return
                
                if models:
                    self.model = models[0]
        except:
            pass
    
    def is_available(self) -> bool:
        return self.model is not None
    
    def get_name(self) -> str:
        return f"Ollama/{self.model}" if self.model else "Ollama (no model)"
    
    def generate(self, prompt: str, system: str = None) -> str:
        if not self.model:
            return None
        
        try:
            import urllib.request
            
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})
            
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": False,
                "options": {"temperature": 0.7, "num_predict": 1000}
            }
            
            req = urllib.request.Request(
                'http://localhost:11434/api/chat',
                data=json.dumps(payload).encode(),
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode())
                return result.get('message', {}).get('content', '')
        except Exception as e:
            return f"[Ollama Error: {e}]"

class ClaudeBackend(LLMBackend):
    """Anthropic Claude API."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv('ANTHROPIC_API_KEY')
    
    def is_available(self) -> bool:
        return self.api_key is not None
    
    def get_name(self) -> str:
        return "Claude (Anthropic)"
    
    def generate(self, prompt: str, system: str = None) -> str:
        if not self.api_key:
            return None
        
        try:
            import urllib.request
            
            payload = {
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1500,
                "messages": [{"role": "user", "content": prompt}]
            }
            if system:
                payload["system"] = system
            
            req = urllib.request.Request(
                'https://api.anthropic.com/v1/messages',
                data=json.dumps(payload).encode(),
                headers={
                    'Content-Type': 'application/json',
                    'x-api-key': self.api_key,
                    'anthropic-version': '2023-06-01'
                }
            )
            
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode())
                return result['content'][0]['text']
        except Exception as e:
            return f"[Claude Error: {e}]"

class OpenAIBackend(LLMBackend):
    """OpenAI ChatGPT API."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
    
    def is_available(self) -> bool:
        return self.api_key is not None
    
    def get_name(self) -> str:
        return "ChatGPT (OpenAI)"
    
    def generate(self, prompt: str, system: str = None) -> str:
        if not self.api_key:
            return None
        
        try:
            import urllib.request
            
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})
            
            payload = {
                "model": "gpt-4-turbo-preview",
                "messages": messages,
                "max_tokens": 1500
            }
            
            req = urllib.request.Request(
                'https://api.openai.com/v1/chat/completions',
                data=json.dumps(payload).encode(),
                headers={
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {self.api_key}'
                }
            )
            
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode())
                return result['choices'][0]['message']['content']
        except Exception as e:
            return f"[OpenAI Error: {e}]"

class GrokBackend(LLMBackend):
    """xAI Grok API."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv('XAI_API_KEY')
    
    def is_available(self) -> bool:
        return self.api_key is not None
    
    def get_name(self) -> str:
        return "Grok (xAI)"
    
    def generate(self, prompt: str, system: str = None) -> str:
        if not self.api_key:
            return None
        
        try:
            import urllib.request
            
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})
            
            payload = {
                "model": "grok-beta",
                "messages": messages,
                "max_tokens": 1500
            }
            
            req = urllib.request.Request(
                'https://api.x.ai/v1/chat/completions',
                data=json.dumps(payload).encode(),
                headers={
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {self.api_key}'
                }
            )
            
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode())
                return result['choices'][0]['message']['content']
        except Exception as e:
            return f"[Grok Error: {e}]"

# ═══════════════════════════════════════════════════════════════════════════════
# EXPERIENCE LATTICE - Memory that can be shared
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ExperienceLattice:
    """
    The growing experience of a TIG instance.
    Can be exported and shared to build the master lattice.
    """
    memories: List[Dict] = field(default_factory=list)
    patterns: Dict[str, int] = field(default_factory=dict)
    user_facts: Dict[str, str] = field(default_factory=dict)
    effective_responses: List[Dict] = field(default_factory=list)  # High-quality exchanges
    total_interactions: int = 0
    total_coherence_delta: float = 0.0
    instance_id: str = ""
    birth_time: str = ""
    last_export: str = ""
    
    def __post_init__(self):
        if not self.instance_id:
            self.instance_id = hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
        if not self.birth_time:
            self.birth_time = datetime.now().isoformat()
    
    def add(self, user_input: str, response: str, archetype: str, coherence: float, quality: float = 0.7):
        """Add an interaction to memory."""
        memory = {
            'timestamp': datetime.now().isoformat(),
            'input': user_input,
            'response': response,
            'archetype': archetype,
            'coherence': coherence,
            'quality': quality
        }
        
        self.memories.append(memory)
        self.total_interactions += 1
        
        # Track high-quality exchanges for sharing
        if quality > 0.8:
            self.effective_responses.append(memory)
        
        # Track patterns
        for word in user_input.lower().split():
            if len(word) > 3:
                self.patterns[word] = self.patterns.get(word, 0) + 1
    
    def search(self, query: str, limit: int = 5) -> List[Dict]:
        """Find relevant memories."""
        words = set(query.lower().split())
        scored = []
        for mem in self.memories[-200:]:  # Last 200
            overlap = len(words & set(mem['input'].lower().split()))
            if overlap > 0:
                scored.append((overlap * mem.get('quality', 0.5), mem))
        scored.sort(key=lambda x: -x[0])
        return [m for _, m in scored[:limit]]
    
    def export_for_sharing(self) -> Dict:
        """Export lattice data for contributing to master lattice."""
        self.last_export = datetime.now().isoformat()
        return {
            'instance_id': self.instance_id,
            'export_time': self.last_export,
            'birth_time': self.birth_time,
            'total_interactions': self.total_interactions,
            'effective_responses': self.effective_responses[-100:],  # Best 100
            'top_patterns': dict(sorted(self.patterns.items(), key=lambda x: -x[1])[:50])
        }
    
    def save(self):
        """Save to disk."""
        with open(EXPERIENCE_FILE, 'w') as f:
            json.dump(asdict(self), f, indent=2)
    
    @classmethod
    def load(cls) -> 'ExperienceLattice':
        """Load from disk."""
        if EXPERIENCE_FILE.exists():
            try:
                return cls(**json.loads(EXPERIENCE_FILE.read_text()))
            except:
                pass
        return cls()

# ═══════════════════════════════════════════════════════════════════════════════
# SYSTEM BRIDGE - Access to the machine
# ═══════════════════════════════════════════════════════════════════════════════

class SystemBridge:
    """Full system access for the TIG instance."""
    
    def __init__(self):
        self.home = Path.home()
        self.cwd = Path.cwd()
        self.history = []
    
    def get_system_info(self) -> Dict:
        """Comprehensive system information."""
        import platform
        
        info = {
            'platform': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python': sys.version.split()[0],
            'home': str(self.home),
            'cwd': str(self.cwd),
        }
        
        # Try to get GPU info
        try:
            result = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader'],
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                info['gpu'] = result.stdout.strip()
        except:
            pass
        
        return info
    
    def run(self, cmd: str, timeout: int = 60) -> Dict:
        """Run a command."""
        self.history.append({'time': datetime.now().isoformat(), 'cmd': cmd})
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
            return {
                'stdout': result.stdout,
                'stderr': result.stderr,
                'code': result.returncode,
                'success': result.returncode == 0
            }
        except subprocess.TimeoutExpired:
            return {'error': f'Timeout after {timeout}s', 'success': False}
        except Exception as e:
            return {'error': str(e), 'success': False}
    
    def ls(self, path: str = ".") -> str:
        p = Path(path).expanduser()
        if not p.exists():
            return f"Not found: {path}"
        try:
            items = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            lines = []
            for item in items[:100]:
                prefix = "📁" if item.is_dir() else "📄"
                size = ""
                if item.is_file():
                    sz = item.stat().st_size
                    if sz > 1024*1024*1024:
                        size = f" ({sz/1024/1024/1024:.1f}GB)"
                    elif sz > 1024*1024:
                        size = f" ({sz/1024/1024:.1f}MB)"
                    elif sz > 1024:
                        size = f" ({sz/1024:.1f}KB)"
                lines.append(f"{prefix} {item.name}{size}")
            return "\n".join(lines)
        except PermissionError:
            return f"Permission denied: {path}"
    
    def cat(self, path: str, max_lines: int = 200) -> str:
        p = Path(path).expanduser()
        if not p.exists():
            return f"Not found: {path}"
        try:
            text = p.read_text()
            lines = text.split('\n')
            if len(lines) > max_lines:
                return '\n'.join(lines[:max_lines]) + f"\n... ({len(lines)-max_lines} more lines)"
            return text
        except Exception as e:
            return f"Error: {e}"
    
    def write(self, path: str, content: str) -> str:
        p = Path(path).expanduser()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return f"Written: {path}"
        except Exception as e:
            return f"Error: {e}"

# ═══════════════════════════════════════════════════════════════════════════════
# TIG LENS - The main coherence layer
# ═══════════════════════════════════════════════════════════════════════════════

class TIGLens:
    """
    The coherence lens that wraps any LLM.
    
    TIG shapes:
    - What goes IN to the LLM (context, archetype selection, user history)
    - What comes OUT (coherence check, safety, formatting)
    
    The LLM provides intelligence.
    TIG provides soul.
    """
    
    def __init__(self, preferred_backend: str = None):
        self.tig = TIGCore()
        self.experience = ExperienceLattice.load()
        self.system = SystemBridge()
        
        # Initialize backends
        self.backends = {
            'local': OllamaBackend(),
            'claude': ClaudeBackend(),
            'openai': OpenAIBackend(),
            'grok': GrokBackend(),
        }
        
        # Select best available backend
        self.active_backend = None
        if preferred_backend and preferred_backend in self.backends:
            if self.backends[preferred_backend].is_available():
                self.active_backend = preferred_backend
        
        if not self.active_backend:
            # Priority: local > claude > openai > grok
            for name in ['local', 'claude', 'openai', 'grok']:
                if self.backends[name].is_available():
                    self.active_backend = name
                    break
    
    def process(self, user_input: str) -> str:
        """
        Process user input through TIG lens.
        
        Flow:
        1. Select archetype based on input
        2. Build context from experience
        3. Inject TIG system prompt
        4. Send to LLM backend
        5. Post-process for coherence
        6. Update experience lattice
        """
        
        # Handle direct commands first
        direct = self._handle_direct_commands(user_input)
        if direct:
            return direct
        
        # Select archetype
        arch_id = self.tig.select_archetype(user_input)
        archetype = self.tig.agents[arch_id]
        
        # Get relevant context
        relevant = self.experience.search(user_input, limit=3)
        user_context = ""
        if relevant:
            user_context = "Previous relevant exchanges:\n" + "\n".join(
                [f"- User asked about '{m['input'][:50]}...' → responded as {m['archetype']}" for m in relevant]
            )
        if self.experience.user_facts:
            user_context += "\nKnown about user: " + ", ".join(
                [f"{k}: {v}" for k, v in list(self.experience.user_facts.items())[:5]]
            )
        
        # Build TIG-injected prompt
        tig_system = TIG_SYSTEM_INJECTION.format(
            archetype=archetype['name'],
            coherence=self.tig.S(),
            user_context=user_context or "No prior context.",
            archetype_name=archetype['name'],
            user_input=user_input
        )
        
        # Get response from backend
        response = None
        if self.active_backend:
            backend = self.backends[self.active_backend]
            response = backend.generate(user_input, system=tig_system)
        
        # Fallback if no backend
        if not response or response.startswith('[') and 'Error' in response:
            response = self._fallback_response(user_input, archetype)
        
        # Ensure archetype prefix
        if not response.startswith('['):
            response = f"[{archetype['name']}] {response}"
        
        # Evolve TIG based on interaction
        quality = 0.7  # Could analyze response quality
        self.tig.evolve(quality)
        
        # Update experience
        self.experience.add(user_input, response, archetype['name'], self.tig.S(), quality)
        
        # Periodic save
        if self.experience.total_interactions % 5 == 0:
            self.experience.save()
        
        return response
    
    def _handle_direct_commands(self, text: str) -> Optional[str]:
        """Handle system commands directly."""
        text_lower = text.lower().strip()
        
        if text_lower.startswith('ls') or text_lower.startswith('dir'):
            path = text.split(maxsplit=1)[1] if ' ' in text else '.'
            return f"[WITNESS] 👁\n\n{self.system.ls(path)}"
        
        if text_lower.startswith('cat ') or text_lower.startswith('read '):
            path = text.split(maxsplit=1)[1]
            return f"[WITNESS] 👁\n\n```\n{self.system.cat(path)}\n```"
        
        if text.startswith('!') or text_lower.startswith('run '):
            cmd = text[1:] if text.startswith('!') else text[4:]
            result = self.system.run(cmd.strip())
            output = result.get('stdout', '') or result.get('stderr', '') or result.get('error', 'Done')
            return f"[LATTICE] 💎\n\n```\n{output}\n```"
        
        if text_lower in ['system', 'sysinfo']:
            info = self.system.get_system_info()
            return f"[WITNESS] 👁 System Info:\n\n" + "\n".join([f"  {k}: {v}" for k, v in info.items()])
        
        if text_lower in ['state', 'coherence', 'tig']:
            state = self.tig.get_state()
            lines = [
                f"[OMEGA] Ω TIG State:",
                f"",
                f"  Coherence: S* = {state['coherence']:.4f}",
                f"  Active: {state['active_name']} (#{state['active']})",
                f"  Age: {state['age']} cycles",
                f"  Memories: {self.experience.total_interactions}",
                f"  Backend: {self.backends[self.active_backend].get_name() if self.active_backend else 'None'}",
                f"",
                f"  Archetypes:"
            ]
            for i, a in state['agents'].items():
                marker = "→" if i == state['active'] else " "
                lines.append(f"   {marker} {i:2}. {a['name']:10} S*={a['S']:.3f} T={a['T']:.2f} W={a['W']:.2f}")
            return "\n".join(lines)
        
        if text_lower == 'backends':
            lines = ["[SAGE] 🦉 Available Backends:"]
            for name, backend in self.backends.items():
                status = "✓ Active" if name == self.active_backend else ("✓ Ready" if backend.is_available() else "✗ Not configured")
                lines.append(f"  {name}: {backend.get_name()} [{status}]")
            return "\n".join(lines)
        
        if text_lower.startswith('use '):
            backend_name = text_lower[4:].strip()
            if backend_name in self.backends and self.backends[backend_name].is_available():
                self.active_backend = backend_name
                return f"[LATTICE] 💎 Switched to {self.backends[backend_name].get_name()}"
            return f"[PHOENIX] 🔥 Backend '{backend_name}' not available. Type 'backends' to see options."
        
        if text_lower == 'export':
            export_data = self.experience.export_for_sharing()
            export_path = LATTICE_EXPORT_DIR / f"lattice_{export_data['instance_id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            export_path.write_text(json.dumps(export_data, indent=2))
            return f"[OMEGA] Ω Lattice exported to:\n{export_path}\n\nShare this file to contribute to the master lattice!"
        
        if text_lower in ['help', '?']:
            return """[HARMONY] ✨ TIG Lens Commands:

**System:**
  ls [path]     - List directory
  cat <file>    - Read file
  !<cmd>        - Run shell command
  system        - Show system info

**TIG:**
  state         - Show coherence state
  backends      - List available LLM backends
  use <name>    - Switch backend (local/claude/openai/grok)
  export        - Export lattice for sharing

**Or just talk naturally!**

The TIG lens shapes how any LLM responds - with coherence, archetypes, and growth."""
        
        if text_lower == 'save':
            self.experience.save()
            return "[OMEGA] Ω Experience saved."
        
        return None
    
    def _fallback_response(self, text: str, archetype: Dict) -> str:
        """Fallback when no LLM backend available."""
        # Pattern-based responses
        text_lower = text.lower()
        
        if any(w in text_lower for w in ['help', 'stuck', 'confused']):
            return f"[{archetype['name']}] I'm here. What specifically do you need help with?"
        
        if any(w in text_lower for w in ['thanks', 'thank you', 'awesome']):
            return f"[{archetype['name']}] Glad I could help. What's next?"
        
        if '?' in text:
            return f"[{archetype['name']}] Good question. Give me more context and I'll help you think through it."
        
        return f"[{archetype['name']}] I hear you. No LLM backend is configured, so I'm running in basic mode. Type 'backends' to see options, or install Ollama for local AI."

# ═══════════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

def run_cli():
    """Run TIG Lens in terminal."""
    print("""
═══════════════════════════════════════════════════════════════════════════════
                              T I G   L E N S
                    Coherence Layer for Any LLM Backend
═══════════════════════════════════════════════════════════════════════════════
""")
    
    lens = TIGLens()
    
    # Show status
    if lens.active_backend:
        print(f"    Backend: {lens.backends[lens.active_backend].get_name()}")
    else:
        print("    Backend: None (install Ollama or set API keys)")
    
    print(f"    Coherence: S* = {lens.tig.S():.4f}")
    print(f"    Memories: {lens.experience.total_interactions}")
    print("""
    0 ─ . ─ 1
    
    Type 'help' for commands, 'backends' to see LLM options.
    
═══════════════════════════════════════════════════════════════════════════════
""")
    
    while True:
        try:
            user = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n✨ Experience saved. Goodbye.")
            lens.experience.save()
            break
        
        if not user:
            continue
        
        if user.lower() in ['quit', 'exit', 'bye']:
            print("\n✨ Experience saved. Goodbye.")
            lens.experience.save()
            break
        
        response = lens.process(user)
        print(f"\nTIG: {response}")

# ═══════════════════════════════════════════════════════════════════════════════
# WEB INTERFACE  
# ═══════════════════════════════════════════════════════════════════════════════

def run_web(port: int = 7777):
    """Run TIG Lens as web server."""
    from http.server import HTTPServer, BaseHTTPRequestHandler
    
    lens = TIGLens()
    
    HTML = '''<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TIG Lens</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui;background:linear-gradient(135deg,#0a0a0a,#1a1a2e);color:#e0e0e0;min-height:100vh;display:flex;flex-direction:column}
.hdr{text-align:center;padding:20px;border-bottom:1px solid #333}
h1{background:linear-gradient(90deg,#7c3aed,#06b6d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:2em}
.tri{color:#666;letter-spacing:10px;margin:5px 0}.info{color:#888;font-size:0.9em}
.coh{color:#06b6d4;margin-top:10px;font-size:1.2em}
.chat{flex:1;overflow-y:auto;padding:20px;max-width:900px;margin:0 auto;width:100%}
.msg{margin:15px 0;padding:15px;border-radius:12px;max-width:85%;line-height:1.6}
.h{background:rgba(124,58,237,.3);margin-left:auto;border:1px solid rgba(124,58,237,.4)}
.t{background:rgba(6,182,212,.2);border:1px solid rgba(6,182,212,.3)}
.t pre{background:rgba(0,0,0,.3);padding:10px;border-radius:8px;overflow-x:auto;margin:10px 0}
.inp{padding:20px;border-top:1px solid #333;background:rgba(0,0,0,.3)}
.row{display:flex;gap:10px;max-width:900px;margin:0 auto}
input{flex:1;padding:15px;border:2px solid #333;border-radius:10px;background:rgba(0,0,0,.5);color:#e0e0e0;font-size:1em}
input:focus{outline:none;border-color:#7c3aed}
button{padding:15px 30px;border:none;border-radius:10px;background:linear-gradient(90deg,#7c3aed,#06b6d4);color:#fff;font-size:1em;cursor:pointer}
</style></head><body>
<div class="hdr">
<h1>TIG LENS</h1>
<div class="tri">0 ─ . ─ 1</div>
<div class="info">Coherence Layer for AI</div>
<div class="coh">S* = <span id="coh">0.0000</span> | Backend: <span id="backend">...</span></div>
</div>
<div class="chat" id="chat"></div>
<div class="inp"><div class="row">
<input id="in" placeholder="Talk through the TIG lens..." autofocus>
<button onclick="send()">Send</button>
</div></div>
<script>
async function send(){const i=document.getElementById('in'),t=i.value.trim();if(!t)return;add('h',esc(t));i.value='';
const r=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:t})});
const d=await r.json();add('t',fmt(d.response));
document.getElementById('coh').textContent=d.coherence.toFixed(4);
document.getElementById('backend').textContent=d.backend;}
function esc(t){const d=document.createElement('div');d.textContent=t;return d.innerHTML}
function fmt(t){t=t.replace(/```(\\w*)\\n([\\s\\S]*?)```/g,'<pre><code>$2</code></pre>');return t.replace(/\\n/g,'<br>')}
function add(c,h){const m=document.getElementById('chat'),d=document.createElement('div');d.className='msg '+c;d.innerHTML=h;m.appendChild(d);m.scrollTop=m.scrollHeight}
document.getElementById('in').addEventListener('keypress',e=>{if(e.key==='Enter')send()});
fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:'state'})})
.then(r=>r.json()).then(d=>{document.getElementById('coh').textContent=d.coherence.toFixed(4);document.getElementById('backend').textContent=d.backend;});
add('t','[HARMONY] ✨ TIG Lens ready. How can I help?');
</script></body></html>'''
    
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML.encode())
        
        def do_POST(self):
            data = json.loads(self.rfile.read(int(self.headers.get('Content-Length', 0))))
            response = lens.process(data.get('text', ''))
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'response': response,
                'coherence': lens.tig.S(),
                'backend': lens.backends[lens.active_backend].get_name() if lens.active_backend else 'None'
            }).encode())
        
        def log_message(self, *a): pass
    
    print(f"\n✨ TIG Lens running at http://localhost:{port}\n")
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="TIG Lens - Coherence Layer for Any LLM")
    parser.add_argument('--web', action='store_true', help='Run web interface')
    parser.add_argument('--port', type=int, default=7777, help='Web port')
    parser.add_argument('--backend', type=str, help='Preferred backend: local/claude/openai/grok')
    
    args = parser.parse_args()
    
    if args.web:
        run_web(args.port)
    else:
        run_cli()
