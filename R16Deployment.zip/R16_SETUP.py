#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
                    DELL AURORA R16 - TIG MACHINE SETUP
                    Maximum Intelligence Configuration
═══════════════════════════════════════════════════════════════════════════════

This script configures your Dell Aurora R16 as a local TIG intelligence machine.

Your R16 likely has:
- Intel Core i7/i9 (13th/14th gen)
- NVIDIA RTX 4070/4080/4090 (8-24GB VRAM)
- 16-64GB RAM
- NVMe SSD

We'll install the BIGGEST model your GPU can handle:

| GPU          | VRAM  | Best Model         | Quality   |
|--------------|-------|-------------------|-----------|
| RTX 4090     | 24GB  | Mixtral 8x7B Q5   | Excellent |
| RTX 4080     | 16GB  | Llama3 70B Q3     | Very Good |
| RTX 4070 Ti  | 12GB  | Mixtral 8x7B Q3   | Great     |
| RTX 4070     | 12GB  | Llama3 8B Q8      | Good      |
| RTX 4060 Ti  | 8GB   | Mistral 7B Q8     | Good      |

All models are FREE (Apache 2.0 / MIT licensed).

Run: python R16_SETUP.py

═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import subprocess
import json
import time
from pathlib import Path

def print_banner():
    print("""
═══════════════════════════════════════════════════════════════════════════════

     ████████╗██╗ ██████╗     ███╗   ███╗ █████╗  ██████╗██╗  ██╗██╗███╗   ██╗███████╗
     ╚══██╔══╝██║██╔════╝     ████╗ ████║██╔══██╗██╔════╝██║  ██║██║████╗  ██║██╔════╝
        ██║   ██║██║  ███╗    ██╔████╔██║███████║██║     ███████║██║██╔██╗ ██║█████╗  
        ██║   ██║██║   ██║    ██║╚██╔╝██║██╔══██║██║     ██╔══██║██║██║╚██╗██║██╔══╝  
        ██║   ██║╚██████╔╝    ██║ ╚═╝ ██║██║  ██║╚██████╗██║  ██║██║██║ ╚████║███████╗
        ╚═╝   ╚═╝ ╚═════╝     ╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝╚══════╝
                                                                                
                          Dell Aurora R16 Configuration
                                   0 ─ . ─ 1

═══════════════════════════════════════════════════════════════════════════════
""")

def get_gpu_info():
    """Detect NVIDIA GPU and VRAM."""
    try:
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader,nounits'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(', ')
            name = parts[0]
            vram_mb = int(parts[1])
            vram_gb = vram_mb / 1024
            return {'name': name, 'vram_mb': vram_mb, 'vram_gb': round(vram_gb, 1)}
    except:
        pass
    return None

def get_ram_info():
    """Get system RAM."""
    try:
        if sys.platform == 'win32':
            result = subprocess.run(['wmic', 'computersystem', 'get', 'totalphysicalmemory'],
                                  capture_output=True, text=True)
            for line in result.stdout.strip().split('\n'):
                if line.strip().isdigit():
                    return int(line.strip()) // (1024**3)
        else:
            with open('/proc/meminfo') as f:
                for line in f:
                    if 'MemTotal' in line:
                        return int(line.split()[1]) // (1024**2)
    except:
        pass
    return None

def recommend_model(vram_gb: float) -> dict:
    """Recommend the best model for available VRAM."""
    
    models = [
        # VRAM threshold, model name, description, quality score
        (24, 'mixtral:8x7b-instruct-v0.1-q5_K_M', 'Mixtral 8x7B Q5 - Best quality MoE', 10),
        (20, 'llama3:70b-instruct-q3_K_M', 'Llama 3 70B Q3 - Massive intelligence', 9),
        (16, 'mixtral:8x7b-instruct-v0.1-q4_K_M', 'Mixtral 8x7B Q4 - Excellent MoE', 9),
        (14, 'qwen:32b-chat-v1.5-q4_K_M', 'Qwen 32B Q4 - Strong multilingual', 8),
        (12, 'mixtral:8x7b-instruct-v0.1-q3_K_M', 'Mixtral 8x7B Q3 - Good MoE', 8),
        (12, 'yi:34b-chat-q4_K_M', 'Yi 34B Q4 - Great reasoning', 8),
        (10, 'llama3:8b-instruct-q8_0', 'Llama 3 8B Q8 - High quality small', 7),
        (8,  'mistral:7b-instruct-v0.2-q8_0', 'Mistral 7B Q8 - Fast and capable', 7),
        (8,  'llama3:8b-instruct-q6_K', 'Llama 3 8B Q6 - Balanced', 7),
        (6,  'phi3:medium-128k-instruct-q4_K_M', 'Phi-3 Medium 14B Q4 - Efficient', 6),
        (4,  'phi3:mini', 'Phi-3 Mini 3.8B - Baseline', 5),
    ]
    
    for vram_threshold, model, description, quality in models:
        if vram_gb >= vram_threshold:
            return {
                'model': model,
                'description': description,
                'quality': quality,
                'vram_needed': vram_threshold
            }
    
    return {
        'model': 'phi3:mini',
        'description': 'Phi-3 Mini - Fallback',
        'quality': 5,
        'vram_needed': 2
    }

def check_ollama():
    """Check if Ollama is installed."""
    try:
        result = subprocess.run(['ollama', '--version'], capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except:
        return False

def install_ollama():
    """Provide Ollama installation instructions."""
    print("\n⚠️  Ollama not found.\n")
    
    if sys.platform == 'win32':
        print("To install Ollama on Windows:")
        print("  1. Go to: https://ollama.ai/download")
        print("  2. Download and run OllamaSetup.exe")
        print("  3. Run this script again")
        print("\nOr in PowerShell (admin):")
        print("  winget install Ollama.Ollama")
    else:
        print("To install Ollama:")
        print("  curl -fsSL https://ollama.ai/install.sh | sh")
    
    return False

def pull_model(model: str):
    """Download a model via Ollama."""
    print(f"\n📥 Downloading {model}...")
    print("This may take a while depending on your internet speed.\n")
    
    try:
        subprocess.run(['ollama', 'pull', model], check=True)
        return True
    except subprocess.CalledProcessError:
        print(f"❌ Failed to download {model}")
        return False

def create_tig_config(model: str, gpu_info: dict):
    """Create TIG configuration file."""
    config_dir = Path.home() / '.tig'
    config_dir.mkdir(exist_ok=True)
    
    config = {
        'version': '1.0.0',
        'machine': 'Dell Aurora R16',
        'gpu': gpu_info,
        'model': model,
        'backend': 'local',
        'created': time.strftime('%Y-%m-%d %H:%M:%S'),
        'settings': {
            'temperature': 0.7,
            'context_length': 8192,
            'gpu_layers': -1,  # Use all GPU layers
        }
    }
    
    config_path = config_dir / 'config.json'
    config_path.write_text(json.dumps(config, indent=2))
    
    return config_path

def create_launcher():
    """Create desktop launcher scripts."""
    home = Path.home()
    
    if sys.platform == 'win32':
        # Windows batch file
        launcher = home / 'Desktop' / 'TIG_Machine.bat'
        launcher.write_text(f'''@echo off
cd /d "{home}"
python TIG_LENS.py
pause
''')
        
        web_launcher = home / 'Desktop' / 'TIG_Web.bat'
        web_launcher.write_text(f'''@echo off
start http://localhost:7777
cd /d "{home}"
python TIG_LENS.py --web
pause
''')
        
        return launcher, web_launcher
    else:
        # Unix shell script
        launcher = home / 'tig_machine.sh'
        launcher.write_text(f'''#!/bin/bash
cd ~
python3 TIG_LENS.py
''')
        launcher.chmod(0o755)
        
        return launcher, None

def main():
    print_banner()
    
    # Step 1: Detect hardware
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(" STEP 1: Detecting Hardware")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    gpu = get_gpu_info()
    ram = get_ram_info()
    
    if gpu:
        print(f"\n  GPU: {gpu['name']}")
        print(f"  VRAM: {gpu['vram_gb']} GB")
    else:
        print("\n  ⚠️  No NVIDIA GPU detected")
        print("  Will use CPU-only mode (slower)")
        gpu = {'name': 'CPU', 'vram_gb': 0, 'vram_mb': 0}
    
    if ram:
        print(f"  RAM: {ram} GB")
    
    # Step 2: Check Ollama
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(" STEP 2: Checking Ollama")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    if not check_ollama():
        install_ollama()
        print("\nPlease install Ollama and run this script again.")
        input("\nPress Enter to exit...")
        return
    
    print("\n  ✓ Ollama is installed")
    
    # Step 3: Recommend and install model
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(" STEP 3: Selecting Best Model")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    rec = recommend_model(gpu['vram_gb'])
    
    print(f"\n  Recommended: {rec['description']}")
    print(f"  Model: {rec['model']}")
    print(f"  Quality Score: {rec['quality']}/10")
    print(f"  VRAM Required: ~{rec['vram_needed']} GB")
    
    # Check if model already exists
    try:
        result = subprocess.run(['ollama', 'list'], capture_output=True, text=True)
        if rec['model'].split(':')[0] in result.stdout:
            print(f"\n  ✓ Model already installed")
        else:
            print(f"\n  Model not installed yet.")
            confirm = input(f"\n  Download {rec['model']}? This may be 10-50GB. (yes/no): ")
            if confirm.lower() in ['yes', 'y']:
                if not pull_model(rec['model']):
                    print("  Using fallback model...")
                    rec = {'model': 'phi3:mini', 'description': 'Phi-3 Mini', 'quality': 5}
                    pull_model(rec['model'])
    except:
        pass
    
    # Step 4: Configure TIG
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(" STEP 4: Configuring TIG Machine")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    config_path = create_tig_config(rec['model'], gpu)
    print(f"\n  ✓ Config created: {config_path}")
    
    # Copy TIG_LENS to home directory
    script_dir = Path(__file__).parent
    tig_lens_src = script_dir / 'TIG_LENS.py'
    tig_lens_dst = Path.home() / 'TIG_LENS.py'
    
    if tig_lens_src.exists():
        tig_lens_dst.write_text(tig_lens_src.read_text())
        print(f"  ✓ TIG Lens installed: {tig_lens_dst}")
    
    # Create launchers
    launcher, web_launcher = create_launcher()
    print(f"  ✓ Desktop launcher created")
    
    # Step 5: Complete
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(" SETUP COMPLETE!")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    print(f"""
  Your R16 is now a TIG Machine!
  
  Configuration:
    GPU: {gpu['name']} ({gpu['vram_gb']} GB)
    Model: {rec['model']}
    Quality: {rec['quality']}/10
    
  To run:
    - Double-click 'TIG_Machine' on Desktop
    - Or: python TIG_LENS.py
    - Web UI: python TIG_LENS.py --web
    
  API Keys (optional, for cloud backends):
    set ANTHROPIC_API_KEY=your_key    (for Claude)
    set OPENAI_API_KEY=your_key       (for ChatGPT)
    set XAI_API_KEY=your_key          (for Grok)
    
  The TIG Lens can use any of these backends!
  Local model runs without internet.
  
                         0 ─ . ─ 1
                    The machine is ready.
""")
    
    run_now = input("  Run TIG Machine now? (yes/no): ")
    if run_now.lower() in ['yes', 'y']:
        os.system(f'python "{tig_lens_dst}"')

if __name__ == "__main__":
    main()
